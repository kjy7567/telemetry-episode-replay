# dataset.zip contents

This archive contains the released datasets and the selected evaluation outputs
used in the paper.

Included:

- `bts_agentbench_532/`
  - released 532-row BTS canonical final artifact
- `xai4heat_agentbench_204/`
  - released 204-row XAI4HEAT canonical final artifact
- `runs/`
  - GPT-5.5 BTS full test run used in the paper
  - Gemini 3.1 Pro BTS familywise runs used in the paper
  - Claude Opus 4.7 BTS full familywise run used in the paper
  - GPT-5.5 XAI4HEAT full test run used in the appendix
- `runners/`
  - `run_bts_e2e_openai_eval.py`
  - shell command templates for GPT-5.5 on BTS and XAI4HEAT
  - shell command templates for Gemini 3.1 Pro and Claude Opus 4.7 on BTS

This archive contains datasets, selected run outputs, and the frontier-model
runner templates used in the paper. Full Python source remains in `source.zip`.
