PYTHONPATH=/workspace/BTS-AgentBench/src python /workspace/BTS-AgentBench/scripts/run_bts_e2e_openai_eval.py \
  --provider openai \
  --base-url https://openrouter.ai/api/v1 \
  --api-key-env OPENROUTER_API_KEY \
  --model google/gemini-3.1-pro-preview \
  --benchmark-dir /workspace/BTS-AgentBench/data/bts_e2e_agentic_canonical_paper_final_history \
  --tool-store-db /workspace/BTS-AgentBench/data/bts/tool_store/tool_store.duckdb \
  --split test
