This directory contains the frontier-model runner used for the paper and the
exact command templates for the reported runs.

Included run targets:
- GPT-5.5 on BTS test split
- GPT-5.5 on XAI4HEAT test split
- Gemini 3.1 Pro on BTS via OpenRouter
- Claude Opus 4.7 on BTS via OpenRouter
