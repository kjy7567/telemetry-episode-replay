# source.zip contents

This archive contains the Python source files used to build and evaluate the
released benchmark artifacts in the paper.

Included:

- `scripts/*.py`
  - raw preprocessing
  - static scenario generation
  - E2E contract lifting
  - agentic surface generation
  - canonical final build
  - contract audit
  - stronger controller audit
  - paid frontier-model evaluation runner
  - XAI4HEAT conversion scripts
- `src/bts_agentbench/*.py`
  - shared runtime
  - tool abstractions
  - preprocessing logic
  - static scenario builders
  - E2E builder
  - evaluator
  - XAI4HEAT-specific corpus logic

This archive is source-only. Released datasets and selected run outputs are in
`dataset.zip`.
