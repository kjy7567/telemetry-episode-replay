#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def build_report(witness_dir: Path) -> dict[str, Any]:
    split_reports: dict[str, Any] = {}
    family_counts: dict[str, Counter[str]] = defaultdict(Counter)
    global_issues: Counter[str] = Counter()
    total = 0
    total_accomplished = 0

    for split in ("train", "dev", "test"):
        report_path = witness_dir / split / "explicit_controller_report.json"
        payload = load_json(report_path)
        report = payload["reports"]["phase_complete_stronger_controller"]
        split_reports[split] = report
        total += int(report["scenario_count"])
        total_accomplished += int(report["label_counts"].get("accomplished", 0))
        for family, counts in report["by_family"].items():
            for label, count in counts.items():
                family_counts[family][label] += int(count)
        for issue, count in report["top_issues"]:
            global_issues[str(issue)] += int(count)

    return {
        "report_version": "explicit-controller-round-v3",
        "audit_round": "explicit_controller_validation_round",
        "controller": "phase_complete_stronger_controller",
        "witness_dir": str(witness_dir),
        "rationale": [
            "validate whether the final replayable artifact is still solvable by representative explicit non-agent controllers",
            "treat explicit-controller success as a benchmark-validity failure rather than a model-tuning signal",
            "summarize controller outcomes globally instead of attaching free-form per-row rationale",
        ],
        "dataset_repair_policy": {
            "row_level_repair_trigger": "controller_witness_only",
            "row_level_repairs_applied_in_this_round": 0,
            "reason": "this report is a post-build validation artifact; row-level repair is handled by the rebuild pipeline itself",
        },
        "totals": {
            "scenario_count": total,
            "accomplished_count": total_accomplished,
            "accomplished_rate": round(total_accomplished / total, 4) if total else 0.0,
        },
        "by_split": {
            split: {
                "scenario_count": int(report["scenario_count"]),
                "label_counts": report["label_counts"],
                "contradiction_count": int(report["contradiction_count"]),
                "top_issues": report["top_issues"][:10],
            }
            for split, report in split_reports.items()
        },
        "by_family": {family: dict(sorted(counter.items())) for family, counter in sorted(family_counts.items())},
        "global_top_issues": global_issues.most_common(20),
        "conclusion": {
            "controller_witness_rows_remaining": total_accomplished,
            "needs_additional_dataset_repair": total_accomplished > 0,
            "summary": (
                "Additional dataset repair is required only if the representative explicit controller still "
                "accomplishes one or more rows."
            ),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--witness-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    report = build_report(args.witness_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
