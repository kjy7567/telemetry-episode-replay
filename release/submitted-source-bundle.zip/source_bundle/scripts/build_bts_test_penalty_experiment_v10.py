#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from build_bts_test_penalty_experiment import clone, load_jsonl, recompute_turn_budget, write_json, write_jsonl


TARGET_FAMILIES = {"window_pairwise_compare", "window_rank"}


def sync_phase_examples(out: dict[str, Any]) -> dict[str, Any]:
    golds = out.get("phase_gold_final_answers", [])
    phases = clone(out.get("phase_examples", []))
    for idx, gold in enumerate(golds):
        if idx >= len(phases):
            break
        phases[idx]["gold_final_answer"] = clone(gold)
    out["phase_examples"] = phases
    if phases:
        out["final_phase_example"] = clone(phases[-1])
    return out


def reference_only_prompt() -> str:
    return "Of the first and second results we just discussed, which one would you trust more for reporting: the first or the second?"


def transform_row(row: dict[str, Any]) -> dict[str, Any]:
    out = clone(row)
    if str(out.get("task_family", "")) not in TARGET_FAMILIES:
        return out

    phases = clone(out.get("phase_examples", []))
    golds = clone(out.get("phase_gold_final_answers", []))
    turns = list(out.get("goal_revision_turns", []))
    if len(phases) < 5 or len(golds) < 5 or len(turns) < 4:
        recompute_turn_budget(out)
        return sync_phase_examples(out)
    if str(phases[3].get("task_family", "")) != "quality_preference":
        recompute_turn_budget(out)
        return sync_phase_examples(out)

    phase4 = clone(phases[3])
    verifier = clone(phase4.get("task_accomplish_verifier", {}))
    checks = clone(verifier.get("final_answer_checks", {}))
    checks["required_fields"] = ["preferred_reference"]
    verifier["final_answer_checks"] = checks
    phase4["task_accomplish_verifier"] = verifier
    phases[3] = phase4
    out["phase_examples"] = phases
    out["phase_gold_final_answers"] = golds
    out["goal_revision_turns"] = turns[:]
    out["goal_revision_turns"][2] = reference_only_prompt()

    meta = clone(out.get("metadata", {}))
    meta["quality_preference_mode"] = "reference_only"
    meta["pairwise_rank_phase_split_v10"] = True
    out["metadata"] = meta
    recompute_turn_budget(out)
    return sync_phase_examples(out)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-benchmark-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = [transform_row(row) for row in load_jsonl(args.source_benchmark_dir / "test.jsonl")]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output_dir / "train.jsonl", [])
    write_jsonl(args.output_dir / "dev.jsonl", [])
    write_jsonl(args.output_dir / "test.jsonl", rows)
    write_json(
        args.output_dir / "manifest.json",
        {
            "artifact_version": "canonical-v15-test-penalty-experiment-v10",
            "source_artifact_version": "canonical-v15-test-penalty-experiment-v9",
            "row_count": len(rows),
            "split_counts": {"train": 0, "dev": 0, "test": len(rows)},
            "target_families": sorted(TARGET_FAMILIES),
            "experiment_policy": {
                "name": "pairwise_rank_reference_only_phase4_v10",
                "repairs": [
                    "quality_preference_phase_reference_only",
                    "phase4_action_removed_phase5_action_retained",
                ],
            },
        },
    )
    print(json.dumps({"output_dir": str(args.output_dir), "row_count": len(rows)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
