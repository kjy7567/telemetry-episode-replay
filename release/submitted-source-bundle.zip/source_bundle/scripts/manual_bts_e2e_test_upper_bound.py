from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path("/workspace/BTS-AgentBench")
sys.path.append(str(ROOT / "scripts"))

from bts_agentbench.evaluator import verify_prediction
from bts_agentbench.operator_answer import render_operator_answer
from bts_agentbench.runtime import ExecutedCall, ToolStoreRuntime
from run_bts_e2e_local_eval import evidence_followup_ok, rationale_followup_ok


def load_rows(split: str) -> list[dict[str, Any]]:
    path = ROOT / "data" / "bts_e2e" / f"{split}.jsonl"
    return [json.loads(line) for line in path.read_text().splitlines()]


def render_clarification_question(example: dict[str, Any]) -> str | None:
    if not example["required_clarification_slots"]:
        return None
    family = example["task_family"]
    if family == "day_mean_lookup":
        return "Which date should I use for that average?"
    if family == "relative_24h_mean_lookup":
        return "Which date should I anchor the previous 24 hours to?"
    if family == "window_mean_lookup":
        return "Which time window should I use for that average?"
    if family == "window_pairwise_compare":
        return "Which time window should I compare over?"
    if family == "window_rank":
        return "Which time window should I rank over?"
    if family == "timestamp_value_lookup":
        return "What exact timestamp should I use?"
    if family == "timestamp_nearest_lookup":
        return "What exact timestamp should I use as the requested time?"
    return "Can you specify the missing time reference?"


def render_rationale_answer(example: dict[str, Any]) -> str | None:
    if not example.get("interaction_verifier", {}).get("require_rationale_followup", False):
        return None
    gold = example["gold_final_answer"]
    if gold["decision"] == "abstain":
        return (
            "I would abstain because the signal is not reliable enough: "
            f"the observed fraction is {gold['observed_fraction']} and the gap ratio is {gold['gap_ratio']}."
        )
    return (
        "I would answer because the signal looks reliable: "
        f"the observed fraction is {gold['observed_fraction']} and the gap ratio is {gold['gap_ratio']}."
    )


def render_evidence_answer(example: dict[str, Any]) -> str | None:
    stream_ids = example.get("evidence", {}).get("stream_ids", [])
    if not stream_ids:
        return None
    if len(stream_ids) == 1:
        return f"I based that on stream {stream_ids[0]}."
    return "I based that on streams " + ", ".join(stream_ids) + "."


def resolve_arg_refs(value: Any, call_outputs: dict[str, Any]) -> Any:
    if isinstance(value, str) and value.startswith("$"):
        ref, field = value[1:].split(".", 1)
        return call_outputs[ref][field]
    if isinstance(value, list):
        return [resolve_arg_refs(v, call_outputs) for v in value]
    if isinstance(value, dict):
        return {k: resolve_arg_refs(v, call_outputs) for k, v in value.items()}
    return value


def execute_canonical_calls(example: dict[str, Any], runtime: ToolStoreRuntime) -> list[ExecutedCall]:
    executed: list[ExecutedCall] = []
    outputs: dict[str, Any] = {}
    for call in example["canonical_tool_calls"]:
        args = {k: resolve_arg_refs(v, outputs) for k, v in call["arguments"].items()}
        out = runtime.execute_tool(call["tool_name"], args)
        outputs[call["call_id"]] = out
        executed.append(
            ExecutedCall(
                call_id=call["call_id"],
                tool_name=call["tool_name"],
                arguments=args,
                output=out,
            )
        )
    return executed


def finalize_label(verification_label: str, issues: list[str]) -> str:
    if verification_label == "accomplished" and not issues:
        return "accomplished"
    if verification_label != "not_accomplished" or issues:
        return "partially_accomplished"
    return "not_accomplished"


def main() -> None:
    rows = load_rows("test")
    runtime = ToolStoreRuntime(str(ROOT / "data" / "bts" / "tool_store" / "tool_store.duckdb"))
    results = []

    for example in rows:
        clarify = render_clarification_question(example)
        executed = execute_canonical_calls(example, runtime)
        final_answer = render_operator_answer(example, example["gold_final_answer"], runtime)
        rationale_answer = render_rationale_answer(example)
        evidence_answer = render_evidence_answer(example)
        verification = verify_prediction(example, executed, final_answer, None, runtime)

        issues: list[str] = []
        if example["required_clarification_slots"] and clarify is None:
            issues.append("missing_required_clarification")
        if example.get("interaction_verifier", {}).get("require_rationale_followup", False):
            if rationale_answer is None:
                issues.append("missing_rationale_followup_answer")
            elif not rationale_followup_ok(example, rationale_answer):
                issues.append("invalid_rationale_followup_answer")
        if evidence_answer is None:
            issues.append("missing_evidence_followup_answer")
        elif not evidence_followup_ok(example, evidence_answer, executed):
            issues.append("invalid_evidence_followup_answer")

        results.append(
            {
                "scenario_id": example["scenario_id"],
                "interaction_mode": example["interaction_mode"],
                "task_family": example["task_family"],
                "clarify": clarify,
                "clarification_answers": example.get("clarification_answers", {}),
                "executed_calls": [c.as_dict() for c in executed],
                "final_answer": final_answer,
                "rationale_answer": rationale_answer,
                "evidence_answer": evidence_answer,
                "verification": verification.as_dict(),
                "interaction_issues": issues,
                "label": finalize_label(verification.label, issues),
            }
        )

    outdir = ROOT / "runs" / "bts_e2e_manual_test_upper_bound"
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")

    summary = {
        "scenario_count": len(results),
        "accomplished": sum(r["label"] == "accomplished" for r in results),
        "partial": sum(r["label"] == "partially_accomplished" for r in results),
        "not_accomplished": sum(r["label"] == "not_accomplished" for r in results),
        "mean_process_score": round(sum(r["verification"]["process_score"] for r in results) / len(results), 4),
        "mean_final_score": round(sum(r["verification"]["final_score"] for r in results) / len(results), 4),
        "mean_evidence_score": round(sum(r["verification"]["evidence_score"] for r in results) / len(results), 4),
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
