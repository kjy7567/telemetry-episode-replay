#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.prob_accomplishment import (
    compact_record,
    load_jsonl,
    rollout_utility,
    save_bundle,
    summarize_rollouts,
    train_prob_model,
)
from bts_agentbench.runtime import ToolStoreRuntime
from run_local_agent_eval import LocalChatModel, run_agent_on_example, select_subset


PROJECT_ROOT = Path("/workspace/BTS-AgentBench")

MODEL_PATH = str(
    PROJECT_ROOT / "adapters" / "current_surface" / "qwen3_8b_multicorpus_iterative_anchor_operator_lora_fix_e0p15"
)

TRAIN_ROLLOUTS = {
    "bts": PROJECT_ROOT / "runs" / "current_surface" / "trainwide_repair_protocol" / "bts_train_rollouts.jsonl",
    "xai4heat": PROJECT_ROOT / "runs" / "current_surface" / "trainwide_repair_protocol" / "xai4heat_train_rollouts.jsonl",
    "pleia": PROJECT_ROOT / "runs" / "current_surface" / "trainwide_repair_protocol" / "pleia_train_rollouts.jsonl",
}

BENCHMARKS = {
    "bts": {
        "benchmark_dir": PROJECT_ROOT / "data" / "scenario_benchmark",
        "tool_store": PROJECT_ROOT / "data" / "bts" / "tool_store" / "tool_store.duckdb",
    },
    "xai4heat": {
        "benchmark_dir": PROJECT_ROOT / "data" / "xai4heat" / "scenario_benchmark",
        "tool_store": PROJECT_ROOT / "data" / "xai4heat" / "tool_store" / "tool_store.duckdb",
    },
    "pleia": {
        "benchmark_dir": PROJECT_ROOT / "data" / "pleia" / "scenario_benchmark",
        "tool_store": PROJECT_ROOT / "data" / "pleia" / "tool_store" / "tool_store.duckdb",
    },
}


def site_runtime_map(train_rows: list[dict], runtimes_by_corpus: dict[str, ToolStoreRuntime]) -> dict[str, ToolStoreRuntime]:
    mapping: dict[str, ToolStoreRuntime] = {}
    for row in train_rows:
        site_id = row["site_id"]
        if site_id.startswith("BTS_"):
            mapping[site_id] = runtimes_by_corpus["bts"]
        elif site_id.startswith("XAI4HEAT_"):
            mapping[site_id] = runtimes_by_corpus["xai4heat"]
        elif site_id.startswith("PLEIA_"):
            mapping[site_id] = runtimes_by_corpus["pleia"]
        else:
            raise KeyError(f"Unknown site_id {site_id}")
    return mapping


def choose_best(candidates: list[dict]) -> tuple[dict, dict]:
    ranked = sorted(
        candidates,
        key=lambda item: (float(item["predicted_accomplishment_prob"]), item["candidate_index"] == 0),
        reverse=True,
    )
    chosen = ranked[0]
    oracle = max(candidates, key=rollout_utility)
    return chosen, oracle


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-corpus", choices=["all", "bts", "xai4heat", "pleia"], default="all")
    parser.add_argument("--eval-corpus", choices=["same", "all", "bts", "xai4heat", "pleia"], default="same")
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--run-tag", default="pilot")
    parser.add_argument("--generator-model", default=MODEL_PATH)
    parser.add_argument("--train-rollouts-jsonl", type=Path, default=None)
    parser.add_argument("--max-scenarios", type=int, default=12)
    parser.add_argument("--family-limit", type=int, default=1)
    parser.add_argument("--sampled-candidates", type=int, default=2)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--max-steps", type=int, default=4)
    parser.add_argument("--max-new-tokens", type=int, default=192)
    args = parser.parse_args()

    eval_corpus = args.train_corpus if args.eval_corpus == "same" else args.eval_corpus
    run_name = f"prob_accomplishment_{args.train_corpus}_e{args.epochs}_{args.run_tag}"
    run_root = PROJECT_ROOT / "runs" / "current_surface" / run_name

    run_root.mkdir(parents=True, exist_ok=True)

    runtimes_by_corpus = {name: ToolStoreRuntime(cfg["tool_store"]) for name, cfg in BENCHMARKS.items()}
    try:
        train_rows: list[dict] = []
        if args.train_rollouts_jsonl is not None:
            train_rows.extend(load_jsonl(str(args.train_rollouts_jsonl)))
        else:
            train_rollouts = TRAIN_ROLLOUTS.items() if args.train_corpus == "all" else [(args.train_corpus, TRAIN_ROLLOUTS[args.train_corpus])]
            for _, path in train_rollouts:
                train_rows.extend(load_jsonl(str(path)))

        runtime_map = site_runtime_map(train_rows, runtimes_by_corpus)
        bundle, train_metrics = train_prob_model(train_rows, runtime_map, epochs=args.epochs, batch_size=64, learning_rate=1e-3)
        model_path = run_root / "prob_accomplishment_bundle.pt"
        save_bundle(bundle, str(model_path))

        results_summary = {
            "prob_model": {
                "bundle_path": str(model_path),
                "train_example_count": len(train_rows),
                "train_metrics": train_metrics,
                "generator_model": args.generator_model,
                "train_corpus": args.train_corpus,
                "eval_corpus": eval_corpus,
                "train_rollouts_jsonl": str(args.train_rollouts_jsonl) if args.train_rollouts_jsonl else None,
                "candidate_policy": {
                    "greedy": 1,
                    "sampled": args.sampled_candidates,
                    "temperature": args.temperature,
                    "top_p": args.top_p,
                    "max_steps": args.max_steps,
                    "max_new_tokens": args.max_new_tokens,
                    "max_scenarios": args.max_scenarios,
                    "family_limit": args.family_limit,
                },
            }
        }

        eval_benchmarks = BENCHMARKS.items() if eval_corpus == "all" else [(eval_corpus, BENCHMARKS[eval_corpus])]
        chat_model = LocalChatModel(args.generator_model, max_new_tokens=args.max_new_tokens)
        for corpus, cfg in eval_benchmarks:
            runtime = runtimes_by_corpus[corpus]
            for split in ["dev", "test"]:
                rows = load_jsonl(str(cfg["benchmark_dir"] / f"{split}.jsonl"))
                subset = select_subset(rows, max_scenarios=args.max_scenarios, family_limit=args.family_limit)

                greedy_rows: list[dict] = []
                reranked_rows: list[dict] = []
                oracle_rows: list[dict] = []
                trace_rows: list[dict] = []

                for ex_idx, example in enumerate(subset, start=1):
                    candidates: list[dict] = []

                    greedy = run_agent_on_example(
                        chat_model,
                        runtime,
                        example,
                        max_steps=args.max_steps,
                        generation_kwargs={"do_sample": False},
                    )
                    greedy["candidate_index"] = 0
                    candidates.append(greedy)

                    for sample_idx in range(args.sampled_candidates):
                        seed = 1200 + ex_idx * 10 + sample_idx
                        sampled = run_agent_on_example(
                            chat_model,
                            runtime,
                            example,
                            max_steps=args.max_steps,
                            generation_kwargs={
                                "do_sample": True,
                                "temperature": args.temperature,
                                "top_p": args.top_p,
                                "seed": seed,
                            },
                        )
                        sampled["candidate_index"] = sample_idx + 1
                        candidates.append(sampled)

                    probs = bundle.predict_proba(candidates, site_runtime_map(candidates, runtimes_by_corpus)).tolist()
                    for candidate, prob in zip(candidates, probs):
                        candidate["predicted_accomplishment_prob"] = round(float(prob), 6)

                    chosen, oracle = choose_best(candidates)
                    greedy_rows.append(greedy)
                    reranked_rows.append(chosen)
                    oracle_rows.append(oracle)
                    trace_rows.append(
                        {
                            "scenario_id": example["scenario_id"],
                            "task_family": example["task_family"],
                            "query": example["query"],
                            "chosen_candidate_index": chosen["candidate_index"],
                            "oracle_candidate_index": oracle["candidate_index"],
                            "candidates": [compact_record(candidate) | {"candidate_index": candidate["candidate_index"], "predicted_accomplishment_prob": candidate["predicted_accomplishment_prob"]} for candidate in candidates],
                        }
                    )
                    print(
                        f"[progress] {corpus}/{split} {ex_idx}/{len(subset)} {example['scenario_id']} "
                        f"greedy={greedy['verification']['label']} reranked={chosen['verification']['label']}",
                        flush=True,
                    )

                summary = {
                    "greedy": summarize_rollouts(greedy_rows),
                    "reranked": summarize_rollouts(reranked_rows),
                    f"oracle_best_of_{1 + args.sampled_candidates}": summarize_rollouts(oracle_rows),
                    "split": split,
                    "corpus": corpus,
                }
                results_summary[f"{corpus}_{split}"] = summary

                out_dir = run_root / f"{corpus}_{split}"
                write_jsonl(out_dir / "greedy.jsonl", greedy_rows)
                write_jsonl(out_dir / "reranked.jsonl", reranked_rows)
                write_jsonl(out_dir / "oracle.jsonl", oracle_rows)
                write_jsonl(out_dir / "candidate_traces.jsonl", trace_rows)
                (out_dir / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

        (run_root / "combined_summary.json").write_text(json.dumps(results_summary, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps(results_summary, indent=2, ensure_ascii=False))
    finally:
        for runtime in runtimes_by_corpus.values():
            runtime.close()


if __name__ == "__main__":
    main()
