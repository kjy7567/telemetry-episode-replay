#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def build_report(filter_audit: dict, static_manifest: dict, e2e_manifest: dict) -> dict:
    family_funnel = {}
    static_families = static_manifest.get("task_families", {})
    for family, final_count in static_families.items():
        family_entry = dict(filter_audit.get("family_candidate_funnel", {}).get(family, {}))
        family_entry["final_static_scenarios"] = final_count
        family_entry["final_e2e_scenarios"] = e2e_manifest.get("task_families", {}).get(family, 0)
        family_funnel[family] = family_entry

    return {
        "source_dataset": "BTS",
        "benchmark_pipeline": [
            "public BTS metadata",
            "tool-ready grounded points",
            "family-specific compatible candidates",
            "data-derived validity filters",
            "deterministic split assignment",
            "static executable scenarios",
            "deterministic BTS-E2E scenarios",
        ],
        "global_funnel": {
            **filter_audit.get("global_funnel", {}),
            "final_static_scenarios": sum(static_families.values()),
            "final_e2e_scenarios": sum(e2e_manifest.get("task_families", {}).values()),
        },
        "derived_cutoffs": filter_audit.get("derived_cutoffs", {}),
        "distribution_stats": filter_audit.get("distribution_stats", {}),
        "family_candidate_funnel": family_funnel,
        "static_split_sizes": static_manifest.get("splits", {}),
        "e2e_split_sizes": e2e_manifest.get("splits", {}),
        "heldout_site_ids": static_manifest.get("heldout_site_ids", []),
        "e2e_track_version": e2e_manifest.get("e2e_track_version"),
    }


def markdown_table(rows: list[tuple[str, int | float | str]]) -> str:
    lines = ["| Stage | Count |", "| --- | ---: |"]
    for key, value in rows:
        lines.append(f"| {key} | {value} |")
    return "\n".join(lines)


def build_markdown(report: dict) -> str:
    global_funnel = report["global_funnel"]
    global_rows = [
        ("metadata_streams", global_funnel["metadata_streams"]),
        ("tool_ready_points", global_funnel["tool_ready_points"]),
        ("metadata_only_streams", global_funnel["metadata_only_streams"]),
        ("generic_point_class", global_funnel["generic_point_class"]),
        ("missing_equipment_label", global_funnel["missing_equipment_label"]),
        ("final_static_scenarios", global_funnel["final_static_scenarios"]),
        ("final_e2e_scenarios", global_funnel["final_e2e_scenarios"]),
    ]
    lines = [
        "# BTS Candidate Funnel",
        "",
        "This artifact summarizes the deterministic pipeline from public BTS metadata to the final static and E2E benchmark scenarios.",
        "",
        "## Global funnel",
        "",
        markdown_table(global_rows),
        "",
        "## Family-level funnel",
        "",
        "| Family | Key candidate count | Final static | Final E2E |",
        "| --- | ---: | ---: | ---: |",
    ]

    for family, info in report["family_candidate_funnel"].items():
        candidate_keys = [key for key in info.keys() if key not in {"final_static_scenarios", "final_e2e_scenarios"}]
        key = candidate_keys[-1] if candidate_keys else "candidate_count"
        lines.append(
            f"| {family} | {info.get(key, 'n/a')} | {info['final_static_scenarios']} | {info['final_e2e_scenarios']} |"
        )

    lines.extend(
        [
            "",
            "## Split sizes",
            "",
            f"- static: `{report['static_split_sizes']}`",
            f"- e2e: `{report['e2e_split_sizes']}`",
            "",
            "## Reviewer-facing interpretation",
            "",
            "- The benchmark is curated from a much larger BTS telemetry pool.",
            "- Exclusion is deterministic and data-derived rather than model-performance-driven.",
            "- The E2E track is a deterministic interactive extension of the same retained static scenarios, not a separately curated task pool.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--filter-audit", type=Path, required=True)
    parser.add_argument("--static-manifest", type=Path, required=True)
    parser.add_argument("--e2e-manifest", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    parser.add_argument("--out-md", type=Path, required=True)
    args = parser.parse_args()

    report = build_report(
        load_json(args.filter_audit),
        load_json(args.static_manifest),
        load_json(args.e2e_manifest),
    )
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    args.out_md.parent.mkdir(parents=True, exist_ok=True)
    args.out_md.write_text(build_markdown(report), encoding="utf-8")


if __name__ == "__main__":
    main()
