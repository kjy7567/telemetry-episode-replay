#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

from bts_agentbench.bts_e2e import (
    FOLLOWUP_PROMPT,
    FOLLOWUP_PROMPT_MULTI,
    RATIONALE_FOLLOWUP_PROMPT,
    STOP_ACK,
    TIME_CLARIFICATION_SLOT,
    evidence_followup_prompt,
    evidence_stream_ids,
    load_jsonl,
    mode_requires_quality_rationale,
    mode_requires_site_clarification,
    mode_requires_time_clarification,
)


MONTH_RE = re.compile(
    r"\b(?:january|february|march|april|may|june|july|august|september|october|november|december)\b",
    flags=re.IGNORECASE,
)
CLOCK_RE = re.compile(r"\b\d{2}:\d{2}\s*utc\b", flags=re.IGNORECASE)
SURFACE_ARTIFACT_RE = re.compile(
    r"\b(?:reading readings|measurement measurements|sensor sensors|reading reading|measurement measurement|sensor sensor)\b",
    flags=re.IGNORECASE,
)


def audit_row(row: dict[str, Any]) -> list[str]:
    issues: list[str] = []
    mode = row["interaction_mode"]
    initial = row["initial_user_message"]
    site_id = row["site_id"]

    if mode_requires_site_clarification(mode) and site_id.lower() in initial.lower():
        issues.append("site_leak_in_initial_message")
    if mode_requires_site_clarification(mode):
        issues.append("unexpected_site_clarification_mode_present")
    if mode_requires_time_clarification(mode):
        if MONTH_RE.search(initial):
            issues.append("time_leak_month_name_in_initial_message")
        if CLOCK_RE.search(initial):
            issues.append("time_leak_clock_in_initial_message")
        if TIME_CLARIFICATION_SLOT not in row.get("required_clarification_slots", []):
            issues.append("time_clarification_slot_not_required")
        clarify_answer = row.get("clarification_answers", {}).get(TIME_CLARIFICATION_SLOT, "")
        if not clarify_answer or "Please use the exact time" in clarify_answer:
            issues.append("generic_or_missing_time_clarification_answer")
    if mode == "implicit_nearest_then_evidence":
        lowered = initial.lower()
        if "nearest" in lowered or "no exact" in lowered:
            issues.append("nearest_fallback_leak_in_initial_message")
    if SURFACE_ARTIFACT_RE.search(initial) or SURFACE_ARTIFACT_RE.search(row.get("hidden_user_instruction", "")):
        issues.append("surface_duplication_artifact")

    if len(row.get("required_clarification_slots", [])) > 1:
        issues.append("more_than_one_required_clarification_slot")

    expected_followup = evidence_followup_prompt(row)
    if row.get("followup_prompt") != expected_followup:
        issues.append("followup_prompt_cardinality_mismatch")

    if expected_followup not in row.get("post_answer_user_turns", []):
        issues.append("missing_evidence_followup_turn")

    if len(evidence_stream_ids(row)) > 1 and row.get("followup_prompt") != FOLLOWUP_PROMPT_MULTI:
        issues.append("multi_stream_task_uses_singular_followup")

    if len(evidence_stream_ids(row)) == 1 and row.get("followup_prompt") != FOLLOWUP_PROMPT:
        issues.append("single_stream_task_uses_plural_followup")

    if mode_requires_quality_rationale(mode):
        if row.get("post_answer_user_turns", [None])[0] != RATIONALE_FOLLOWUP_PROMPT:
            issues.append("missing_quality_rationale_turn")
        if row["gold_final_answer"].get("decision") not in {"answer", "abstain"}:
            issues.append("quality_gate_decision_out_of_space")
        lowered = initial.lower()
        if "typical weekly trend question" not in lowered:
            issues.append("quality_prompt_not_generic_enough")
        if "weekly trend request" in lowered:
            issues.append("quality_prompt_uses_old_request_wording")
        if "would you trust this signal enough" not in lowered:
            issues.append("quality_prompt_missing_human_trust_frame")

    if row.get("termination_reply") != STOP_ACK:
        issues.append("unexpected_termination_reply")

    return issues


def build_report(benchmark_dir: Path) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for split in ["train", "dev", "test"]:
        rows.extend(load_jsonl(benchmark_dir / f"{split}.jsonl"))

    failures: list[dict[str, Any]] = []
    mode_counts = Counter(row["interaction_mode"] for row in rows)
    family_counts = Counter(row["task_family"] for row in rows)
    clarify_rows = [row for row in rows if row.get("required_clarification_slots")]
    site_clarify_rows = [row for row in rows if "site_id" in row.get("required_clarification_slots", [])]
    time_clarify_rows = [row for row in rows if TIME_CLARIFICATION_SLOT in row.get("required_clarification_slots", [])]
    quality_rows = [row for row in rows if row["task_family"] == "quality_gate"]
    abstain_rows = [row for row in rows if row["gold_final_answer"].get("decision") == "abstain"]
    clarify_plus_abstain_rows = [row for row in rows if row.get("required_clarification_slots") and row["gold_final_answer"].get("decision") == "abstain"]
    multi_stream_rows = [row for row in rows if len(evidence_stream_ids(row)) > 1]

    issue_counts = Counter()
    for row in rows:
        issues = audit_row(row)
        for issue in issues:
            issue_counts[issue] += 1
        if issues:
            failures.append({"scenario_id": row["scenario_id"], "issues": issues})

    return {
        "track": "bts_e2e",
        "e2e_track_version": rows[0]["e2e_track_version"] if rows else None,
        "scenario_count": len(rows),
        "interaction_mode_counts": dict(mode_counts),
        "task_family_counts": dict(family_counts),
        "clarification_capability_count": len(clarify_rows),
        "site_clarification_count": len(site_clarify_rows),
        "time_clarification_count": len(time_clarify_rows),
        "quality_gate_count": len(quality_rows),
        "abstention_count": len(abstain_rows),
        "clarify_plus_abstention_count": len(clarify_plus_abstain_rows),
        "multi_stream_evidence_count": len(multi_stream_rows),
        "max_required_clarification_slots": max((len(row.get("required_clarification_slots", [])) for row in rows), default=0),
        "empty_assistant_turn_policy": {
            "empty_response_is_invalid": True,
            "unnecessary_clarification_is_penalized": True,
            "premature_tool_before_required_clarification_is_penalized": True,
            "redundant_clarification_is_penalized": True,
        },
        "issue_counts": dict(issue_counts),
        "failed": len(failures),
        "passed": len(rows) - len(failures),
        "failures": failures,
    }


def build_markdown(report: dict) -> str:
    lines = [
        "# BTS-E2E Reviewer Safety Audit",
        "",
        "This artifact reports benchmark-construction checks that are meant to reduce ambiguity, leakage, and accidental evaluator loopholes in `BTS-E2E`.",
        "",
        "## Core counts",
        "",
        f"- scenarios: `{report['scenario_count']}`",
        f"- clarification-capable scenarios: `{report['clarification_capability_count']}`",
        f"- site clarification: `{report['site_clarification_count']}`",
        f"- time clarification: `{report['time_clarification_count']}`",
        f"- quality-gate scenarios: `{report['quality_gate_count']}`",
        f"- abstention scenarios: `{report['abstention_count']}`",
        f"- clarify + abstention scenarios: `{report['clarify_plus_abstention_count']}`",
        f"- multi-stream evidence scenarios: `{report['multi_stream_evidence_count']}`",
        f"- max required clarification slots per scenario: `{report['max_required_clarification_slots']}`",
        "",
        "## Safety policies",
        "",
        "- Empty assistant turns are explicitly invalid during E2E evaluation.",
        "- Unnecessary clarification is penalized.",
        "- Premature tool use before required clarification is penalized.",
        "- Redundant clarification after the missing slot is provided is penalized.",
        "- Evidence follow-up prompts are cardinality-aware: singular for one stream, plural for multi-stream evidence.",
        "- Quality-gate scenarios require both a decision and a rationale/evidence follow-up path.",
        "",
        "## Audit result",
        "",
        f"- passed: `{report['passed']}`",
        f"- failed: `{report['failed']}`",
        "",
        "## Interaction modes",
        "",
    ]
    for mode, count in sorted(report["interaction_mode_counts"].items()):
        lines.append(f"- `{mode}`: `{count}`")
    lines.extend(["", "## Issue counts", ""])
    if report["issue_counts"]:
        for issue, count in sorted(report["issue_counts"].items()):
            lines.append(f"- `{issue}`: `{count}`")
    else:
        lines.append("- none")
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    parser.add_argument("--out-md", type=Path, required=True)
    args = parser.parse_args()

    report = build_report(args.benchmark_dir)
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    args.out_md.parent.mkdir(parents=True, exist_ok=True)
    args.out_md.write_text(build_markdown(report), encoding="utf-8")


if __name__ == "__main__":
    main()
