#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def with_site_weights(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, float]]:
    site_counts = Counter(row["site_id"] for row in rows)
    if not site_counts:
        return rows, {}
    target = sum(site_counts.values()) / len(site_counts)
    site_weights = {site: target / count for site, count in site_counts.items()}
    weighted_rows: list[dict[str, Any]] = []
    for row in rows:
        updated = dict(row)
        updated["sample_weight"] = round(site_weights[row["site_id"]], 6)
        weighted_rows.append(updated)
    return weighted_rows, site_weights


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    train_rows = load_jsonl(args.input_dir / "train.jsonl")
    dev_rows = load_jsonl(args.input_dir / "dev.jsonl")

    weighted_train_rows, site_weights = with_site_weights(train_rows)
    weighted_dev_rows = [dict(row, sample_weight=1.0) for row in dev_rows]

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.out_dir / "train.jsonl", weighted_train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", weighted_dev_rows)

    base_manifest_path = args.input_dir / "manifest.json"
    base_manifest = json.loads(base_manifest_path.read_text(encoding="utf-8")) if base_manifest_path.exists() else {}
    manifest = {
        **base_manifest,
        "source": f"{base_manifest.get('source', 'unknown')}_site_balanced_weighted",
        "input_dir": str(args.input_dir),
        "train_examples": len(weighted_train_rows),
        "dev_examples": len(weighted_dev_rows),
        "site_row_counts_train": dict(Counter(row["site_id"] for row in train_rows)),
        "site_weights_train": site_weights,
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
