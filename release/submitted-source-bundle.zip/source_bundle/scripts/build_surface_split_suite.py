#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


DEFAULT_CORPORA = {
    "bts": Path("/workspace/BTS-AgentBench/data/scenario_benchmark"),
    "xai4heat": Path("/workspace/BTS-AgentBench/data/xai4heat/scenario_benchmark"),
    "pleia": Path("/workspace/BTS-AgentBench/data/pleia/scenario_benchmark"),
}


def run_render(benchmark_dir: Path, out_root: Path, corpus: str) -> dict:
    script = Path("/workspace/BTS-AgentBench/scripts/render_surface_splits.py")
    proc = subprocess.run(
        [
            sys.executable,
            str(script),
            "--benchmark-dir",
            str(benchmark_dir),
            "--out-root",
            str(out_root),
            "--corpus",
            corpus,
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(proc.stdout)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--out-root",
        type=Path,
        default=Path("/workspace/BTS-AgentBench/data/surface_splits"),
    )
    parser.add_argument("--corpus", action="append", choices=sorted(DEFAULT_CORPORA.keys()))
    args = parser.parse_args()

    corpora = args.corpus or list(DEFAULT_CORPORA.keys())
    summaries = []
    for corpus in corpora:
        summaries.append(run_render(DEFAULT_CORPORA[corpus], args.out_root, corpus))

    suite_summary = {
        "surface_suite_version": "v1",
        "canonical_query_surface_version": "canonical-v1",
        "robust_query_surface_version": "operator-robust-v1",
        "corpora": summaries,
    }
    args.out_root.mkdir(parents=True, exist_ok=True)
    (args.out_root / "manifest.json").write_text(json.dumps(suite_summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(suite_summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
