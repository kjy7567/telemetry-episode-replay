#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import mean

from run_local_agent_eval import LocalChatModel, ToolStoreRuntime, load_jsonl, run_agent_on_example, select_subset


def evaluate_split(
    model: LocalChatModel,
    runtime: ToolStoreRuntime,
    benchmark_dir: Path,
    split: str,
    max_scenarios: int,
    family_limit: int | None,
) -> dict:
    rows = load_jsonl(benchmark_dir / f"{split}.jsonl")
    subset = select_subset(rows, max_scenarios=max_scenarios, family_limit=family_limit)
    results = [run_agent_on_example(model, runtime, row, max_steps=4) for row in subset]
    label_counts: dict[str, int] = {}
    for result in results:
        label = result["verification"]["label"]
        label_counts[label] = label_counts.get(label, 0) + 1
    summary = {
        "scenario_count": len(results),
        "label_counts": label_counts,
        "mean_process_score": round(mean(r["verification"]["process_score"] for r in results), 4) if results else 0.0,
        "mean_final_score": round(mean(r["verification"]["final_score"] for r in results), 4) if results else 0.0,
        "mean_evidence_score": round(mean(r["verification"]["evidence_score"] for r in results), 4) if results else 0.0,
        "model": model.model_id,
        "split": split,
    }
    return {"results": results, "summary": summary}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-scenarios", type=int, default=20)
    parser.add_argument("--family-limit", type=int, default=1)
    parser.add_argument(
        "--corpus",
        action="append",
        nargs=3,
        metavar=("NAME", "TOOL_STORE_DB", "BENCHMARK_DIR"),
        required=True,
        help="Repeatable corpus spec: NAME TOOL_STORE_DB BENCHMARK_DIR",
    )
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    model = LocalChatModel(args.model, max_new_tokens=256)

    combined: dict[str, dict] = {}
    for name, tool_store_db, benchmark_dir in args.corpus:
        runtime = ToolStoreRuntime(Path(tool_store_db))
        for split in ("dev", "test"):
            payload = evaluate_split(
                model=model,
                runtime=runtime,
                benchmark_dir=Path(benchmark_dir),
                split=split,
                max_scenarios=args.max_scenarios,
                family_limit=args.family_limit,
            )
            stem = f"{name}_{split}"
            (args.out_dir / f"{stem}.jsonl").write_text(
                "\n".join(json.dumps(row, ensure_ascii=False) for row in payload["results"]) + "\n",
                encoding="utf-8",
            )
            (args.out_dir / f"{stem}_summary.json").write_text(
                json.dumps(payload["summary"], indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            combined[stem] = payload["summary"]

    (args.out_dir / "combined_summary.json").write_text(
        json.dumps(combined, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
