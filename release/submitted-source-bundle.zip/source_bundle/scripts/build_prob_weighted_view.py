#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from build_prob_distillation_view import benchmark_index, compact_observation, scenario_messages


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def scenario_relative_weight(candidates: list[dict[str, Any]], floor: float) -> list[float]:
    scores = [float(item["predicted_accomplishment_prob"]) for item in candidates]
    low = min(scores)
    high = max(scores)
    if high - low < 1e-6:
        return [0.5] * len(scores)
    weights = []
    for score in scores:
        normalized = (score - low) / (high - low)
        weights.append(floor + (1.0 - floor) * normalized)
    return weights


def stepwise_rows_from_candidate(example: dict[str, Any], candidate: dict[str, Any], sample_weight: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    observations: list[str] = []
    for idx, call in enumerate(candidate["executed_calls"], start=1):
        rows.append(
            {
                "scenario_id": example["scenario_id"],
                "split": example["split"],
                "task_family": example["task_family"],
                "site_id": example["site_id"],
                "source": "prob_weighted",
                "stage": "tool_call",
                "step_index": idx,
                "sample_weight": round(float(sample_weight), 6),
                "messages": scenario_messages(example["query"], list(observations))
                + [
                    {
                        "role": "assistant",
                        "content": json.dumps(
                            {"tool_name": call["tool_name"], "arguments": call["arguments"]},
                            ensure_ascii=False,
                        ),
                    }
                ],
                "query": example["query"],
            }
        )
        observations.append(compact_observation(call))

    final_answer = candidate.get("final_answer")
    if isinstance(final_answer, str) and final_answer.strip():
        rows.append(
            {
                "scenario_id": example["scenario_id"],
                "split": example["split"],
                "task_family": example["task_family"],
                "site_id": example["site_id"],
                "source": "prob_weighted",
                "stage": "final_answer",
                "step_index": len(candidate["executed_calls"]) + 1,
                "sample_weight": round(float(sample_weight), 6),
                "messages": scenario_messages(example["query"], list(observations))
                + [{"role": "assistant", "content": final_answer}],
                "query": example["query"],
            }
        )
    return rows


def build_rows(traces: list[dict[str, Any]], benchmark: dict[str, dict[str, Any]], floor: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for trace in traces:
        example = benchmark[trace["scenario_id"]]
        weights = scenario_relative_weight(trace["candidates"], floor=floor)
        for candidate, sample_weight in zip(trace["candidates"], weights):
            if not candidate.get("executed_calls"):
                continue
            rows.extend(stepwise_rows_from_candidate(example, candidate, sample_weight))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--train-traces", type=Path, required=True)
    parser.add_argument("--dev-traces", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--weight-floor", type=float, default=0.2)
    args = parser.parse_args()

    benchmark = benchmark_index(args.benchmark_dir)
    train_traces = load_jsonl(args.train_traces)
    dev_traces = load_jsonl(args.dev_traces)
    train_rows = build_rows(train_traces, benchmark, floor=args.weight_floor)
    dev_rows = build_rows(dev_traces, benchmark, floor=args.weight_floor)

    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)

    summary = {
        "train_trace_count": len(train_traces),
        "dev_trace_count": len(dev_traces),
        "train_rows": len(train_rows),
        "dev_rows": len(dev_rows),
        "weight_floor": args.weight_floor,
        "mean_train_weight": round(sum(row["sample_weight"] for row in train_rows) / len(train_rows), 6) if train_rows else 0.0,
        "mean_dev_weight": round(sum(row["sample_weight"] for row in dev_rows) / len(dev_rows), 6) if dev_rows else 0.0,
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
