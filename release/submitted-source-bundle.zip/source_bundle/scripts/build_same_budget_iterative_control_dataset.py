#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def load_jsonl(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def infer_corpus(site_id: str) -> str:
    if site_id.startswith("XAI4HEAT"):
        return "xai4heat"
    if site_id.startswith("PLEIA"):
        return "pleia"
    return "bts"


def add_control_fields(rows: list[dict]) -> list[dict]:
    out = []
    for row in rows:
        clone = dict(row)
        clone["source"] = "anchor_control"
        clone["corpus"] = infer_corpus(row["site_id"])
        out.append(clone)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--anchor-train-jsonl", type=Path, required=True)
    parser.add_argument("--anchor-dev-jsonl", type=Path, required=True)
    parser.add_argument("--target-count", type=int, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    train_rows = add_control_fields(load_jsonl(args.anchor_train_jsonl))
    dev_rows = add_control_fields(load_jsonl(args.anchor_dev_jsonl))

    buckets: dict[tuple[str, str, str, str], list[dict]] = defaultdict(list)
    for row in train_rows:
        key = (row["corpus"], row["task_family"], row["site_id"], row["stage"])
        buckets[key].append(row)

    ordered_keys = sorted(buckets)
    cursor = {key: 0 for key in ordered_keys}
    sampled: list[dict] = []
    while len(sampled) < args.target_count:
        for key in ordered_keys:
            if len(sampled) >= args.target_count:
                break
            bucket = buckets[key]
            row = dict(bucket[cursor[key] % len(bucket)])
            row["control_repeat_index"] = cursor[key]
            cursor[key] += 1
            sampled.append(row)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "train.jsonl").open("w", encoding="utf-8") as handle:
        for row in sampled:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    with (args.out_dir / "dev.jsonl").open("w", encoding="utf-8") as handle:
        for row in dev_rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")

    manifest = {
        "anchor_train_jsonl": str(args.anchor_train_jsonl),
        "anchor_dev_jsonl": str(args.anchor_dev_jsonl),
        "target_count": args.target_count,
        "actual_count": len(sampled),
        "bucket_count": len(ordered_keys),
        "source_counts": dict(Counter(row["source"] for row in sampled)),
        "stage_counts": dict(Counter(row["stage"] for row in sampled)),
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
