#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path


AGGREGATION_COMPATIBILITY_REGEX = re.compile(
    r"^(?!Time_)(?!Duration_Sensor$)(?!.*_Energy_Sensor$)(?!Chilled_Water_Supply_Flow_Sensor$)"
    r"(?!.*_Parameter$).*(?:_Sensor|_Setpoint|_Limit)$"
)
TIMESTAMP_COMPATIBILITY_REGEX = re.compile(r"^(?!.*_Parameter$).*(?:_Sensor|_Setpoint|_Limit)$")
QUALITY_COMPATIBILITY_REGEX = re.compile(
    r"^(?!Time_)(?!Duration_Sensor$)(?!.*_Energy_Sensor$)(?!.*_Parameter$)"
    r"(?!Min_Limit$)(?!Max_Limit$).*(?:_Sensor|_Setpoint|_Limit)$"
)
HEXISH_LABEL_REGEX = re.compile(r"[A-F0-9]{8,}", re.IGNORECASE)


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def scenario_rows(benchmark_dir: Path) -> list[dict]:
    rows = []
    for split in ["train", "dev", "test"]:
        rows.extend(load_jsonl(benchmark_dir / f"{split}.jsonl"))
    return rows


def judge_row(row: dict) -> dict:
    issues = []
    family = row["task_family"]
    query = row["query"]
    metadata = row.get("metadata", {})
    point_class = metadata.get("point_class")
    equipment_label = metadata.get("equipment_label") or ""

    if not query.endswith("?"):
        issues.append({"severity": "medium", "category": "query_style", "message": "Query is not phrased as a question."})
    for token in ["None", "nan", "NaN"]:
        if token in query:
            issues.append({"severity": "high", "category": "query_text", "message": f"Query contains placeholder token {token}."})

    if family in {
        "day_mean_lookup",
        "relative_24h_mean_lookup",
        "window_mean_lookup",
        "window_pairwise_compare",
        "window_rank",
    }:
        if not AGGREGATION_COMPATIBILITY_REGEX.match(point_class or ""):
            issues.append({"severity": "high", "category": "semantic_compatibility", "message": f"{point_class} is not semantically suitable for aggregate/rank tasks."})
    elif family in {"timestamp_value_lookup", "timestamp_nearest_lookup"}:
        if not TIMESTAMP_COMPATIBILITY_REGEX.match(point_class or ""):
            issues.append({"severity": "high", "category": "semantic_compatibility", "message": f"{point_class} is not semantically suitable for timestamp lookup tasks."})
    elif family == "quality_gate":
        if not QUALITY_COMPATIBILITY_REGEX.match(point_class or ""):
            issues.append({"severity": "high", "category": "semantic_compatibility", "message": f"{point_class} is not semantically suitable for quality-gate scenarios."})

    if family == "timestamp_nearest_lookup":
        if "nearest available observation" not in query.lower():
            issues.append({"severity": "medium", "category": "fallback_specification", "message": "Nearest-observation fallback is not explicit in the query."})
        if not row["gold_final_answer"].get("fallback_reason"):
            issues.append({"severity": "high", "category": "fallback_specification", "message": "Missing fallback_reason in gold answer."})

    if family == "quality_gate":
        decision = row["gold_final_answer"].get("decision")
        if decision not in {"answer", "abstain"}:
            issues.append({"severity": "high", "category": "quality_decision", "message": "Quality-gate decision is invalid."})

    if HEXISH_LABEL_REGEX.search(equipment_label) and len(equipment_label.split()) >= 5:
        issues.append({"severity": "medium", "category": "readability", "message": "Equipment label appears machine-generated or low-readability."})

    if any(issue["severity"] == "high" for issue in issues):
        decision = "drop"
    elif issues:
        decision = "revise"
    else:
        decision = "keep"

    return {
        "scenario_id": row["scenario_id"],
        "split": row["split"],
        "task_family": family,
        "site_id": row["site_id"],
        "decision": decision,
        "issues": issues,
        "rationale": "Author-side semantic audit over query naturalness, semantic compatibility, fallback clarity, and readability.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-summary", type=Path, required=True)
    args = parser.parse_args()

    rows = scenario_rows(args.benchmark_dir)
    judgments = [judge_row(row) for row in rows]

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.out_jsonl.open("w", encoding="utf-8") as handle:
        for row in judgments:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")

    decision_counts = Counter(row["decision"] for row in judgments)
    issue_counts = Counter(
        f"{issue['category']}::{issue['severity']}"
        for row in judgments
        for issue in row["issues"]
    )
    summary = {
        "scenario_count": len(judgments),
        "decision_counts": dict(decision_counts),
        "issue_counts": dict(issue_counts),
    }
    args.out_summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
