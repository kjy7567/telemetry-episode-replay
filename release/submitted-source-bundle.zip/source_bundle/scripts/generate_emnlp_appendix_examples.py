from __future__ import annotations

import json
from pathlib import Path
from typing import Any


FINAL_ARTIFACT = Path(
    "/workspace/BTS-AgentBench/data/bts_e2e_agentic_canonical_paper_final_history"
)
SNAPSHOT_PATH = FINAL_ARTIFACT / "paper_final_family_snapshot.json"
TEST_ROWS_PATH = FINAL_ARTIFACT / "test.jsonl"
OUT_PATH = Path("/workspace/emnlp2026_bts_paper/appendix_examples_generated.tex")


def latex_escape(text: str) -> str:
    text = ascii_clean(text)
    repl = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    out = []
    for ch in text:
        out.append(repl.get(ch, ch))
    return "".join(out)


def compact_json(obj: Any) -> str:
    return ascii_clean(json.dumps(obj, ensure_ascii=False, sort_keys=False))


def ascii_clean(text: str) -> str:
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\u2026": "...",
        "\u00a0": " ",
        "\u2264": "<=",
        "\u2265": ">=",
        "\u00d7": "x",
        "\u00b1": "+/-",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    return text.encode("ascii", "replace").decode()


def limit(text: str, n: int = 140) -> str:
    text = text.replace("\n", " ").strip()
    return text if len(text) <= n else text[: n - 3] + "..."


def inline_list(items: list[str]) -> str:
    if not items:
        return "None"
    return r"\newline ".join(latex_escape(x) for x in items)


def format_interaction_mode(mode: str) -> str:
    parts = [chunk.strip() for chunk in mode.split("_then_") if chunk.strip()]
    humanized = []
    for part in parts:
        humanized.append(part.replace("_", " "))
    return r" $\rightarrow$ ".join(latex_escape(part) for part in humanized)


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open() as f:
        return [json.loads(line) for line in f]


def summarize_output(tool_name: str, output: dict[str, Any]) -> str:
    if tool_name == "list_points":
        count = output.get("count")
        return f"{count} streams"
    if tool_name == "resolve_point":
        stream_id = output.get("stream_id")
        return f"stream_id={stream_id}"
    if tool_name == "aggregate_window":
        return f"mean_value={output.get('mean_value')}"
    if tool_name == "rank_window":
        ranked = output.get("ranked_streams") or []
        if ranked:
            top = ranked[0]
            return f"top={top.get('stream_id')}, mean={top.get('mean_value')}"
        stream_id = output.get("stream_id")
        mean_value = output.get("mean_value")
        if stream_id is not None or mean_value is not None:
            return f"top={stream_id}, mean={mean_value}"
        return "rank result"
    if tool_name == "lookup_observation":
        ts = output.get("observed_timestamp")
        value = output.get("value")
        exact = output.get("exact_match_found")
        return f"timestamp={ts}, value={value}, exact={exact}"
    if tool_name == "inspect_quality_window":
        q = output.get("quality_reference", output)
        return (
            f"decision={q.get('decision')}, observed_fraction={q.get('observed_fraction')}, "
            f"gap_ratio={q.get('gap_ratio')}"
        )
    if tool_name == "inspect_quality":
        return f"observed_fraction={output.get('observed_fraction')}, gap_ratio={output.get('gap_ratio')}"
    return limit(compact_json(output), 120)


def summarize_arguments(tool_name: str, arguments: dict[str, Any]) -> str:
    if tool_name == "list_points":
        return (
            f"site_id={arguments.get('site_id')}, "
            f"point_class={arguments.get('point_class')}, "
            f"location_type={arguments.get('location_type')}"
        )
    if tool_name == "resolve_point":
        return (
            f"site_id={arguments.get('site_id')}, "
            f"point_class={arguments.get('point_class')}, "
            f"equipment_label={arguments.get('equipment_label')}"
        )
    if tool_name == "aggregate_window":
        return (
            f"stream_id={arguments.get('stream_id')}, "
            f"metric={arguments.get('metric')}, "
            f"window_start={arguments.get('window_start')}, "
            f"window_end={arguments.get('window_end')}, "
            f"period={arguments.get('period')}"
        )
    if tool_name == "rank_window":
        stream_ids = arguments.get("stream_ids")
        if isinstance(stream_ids, list):
            sid_repr = f"{len(stream_ids)} streams"
        else:
            sid_repr = str(stream_ids)
        return (
            f"stream_ids={sid_repr}, metric={arguments.get('metric')}, "
            f"window_start={arguments.get('window_start')}, "
            f"window_end={arguments.get('window_end')}, period={arguments.get('period')}, "
            f"topk={arguments.get('topk')}"
        )
    if tool_name == "lookup_observation":
        return (
            f"stream_id={arguments.get('stream_id')}, "
            f"timestamp={arguments.get('timestamp')}, mode={arguments.get('mode')}"
        )
    if tool_name == "inspect_quality_window":
        return (
            f"stream_id={arguments.get('stream_id')}, "
            f"window_start={arguments.get('window_start')}, "
            f"window_end={arguments.get('window_end')}, period={arguments.get('period')}"
        )
    return limit(compact_json(arguments), 120)


def summarize_call(call: dict[str, Any], with_output: bool) -> str:
    tool_name = str(call.get("tool_name") or "")
    arguments = call.get("arguments") or {}
    arg_text = summarize_arguments(tool_name, arguments)
    line = f"{tool_name}({arg_text})"
    if with_output:
        output = call.get("output") or {}
        line += f" -> {summarize_output(tool_name, output)}"
    return line


def listing_block(title: str, body: str) -> str:
    return (
        f"\\begin{{lstlisting}}[style=papertrace,caption={{{latex_escape(title)}}}]\n"
        f"{ascii_clean(body)}\n"
        "\\end{lstlisting}\n"
    )


def gold_trace_text(row: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("Canonical tool calls:")
    for idx, call in enumerate(row.get("canonical_tool_calls", []), 1):
        lines.append(f"{idx}. {summarize_call(call, with_output=False)}")
    lines.append("")
    lines.append("Phase targets:")
    for idx, gold in enumerate(row.get("phase_gold_final_answers", []), 1):
        lines.append(f"P{idx}. {compact_json(gold)}")
    lines.append("")
    lines.append(f"Gold final answer: {compact_json(row.get('gold_final_answer'))}")
    return "\n".join(lines)


def gpt_trace_text(raw: dict[str, Any]) -> str:
    lines: list[str] = []
    phase_texts = raw.get("phase_answer_texts") or []
    if phase_texts:
        lines.append("Phase answers:")
        for idx, text in enumerate(phase_texts, 1):
            lines.append(f"P{idx}. {text}")
        lines.append("")
    executed_calls = raw.get("executed_calls") or []
    lines.append("Executed calls:")
    for idx, call in enumerate(executed_calls, 1):
        lines.append(f"{idx}. {summarize_call(call, with_output=True)}")
    lines.append("")
    lines.append(f"Final answer: {raw.get('final_answer_text') or ''}")
    if raw.get("rationale_answer_text"):
        lines.append(f"Rationale follow-up: {raw['rationale_answer_text']}")
    if raw.get("evidence_answer_text"):
        lines.append(f"Evidence follow-up: {raw['evidence_answer_text']}")
    return "\n".join(lines)


def example_table(row: dict[str, Any]) -> str:
    clar_answers = [
        f"{slot}: {answer}"
        for slot, answer in (row.get("clarification_answers") or {}).items()
    ]
    goal_revisions = row.get("goal_revision_turns") or []
    final_answer = row.get("gold_final_answer") or {}
    values = {
        "Scenario ID": f"\\texttt{{{latex_escape(row['scenario_id'])}}}",
        "Interaction Flow": format_interaction_mode(str(row["interaction_mode"])),
        "Gold Initial Query": latex_escape(row.get("initial_user_message", "")),
        "Clarification Answers": inline_list(clar_answers),
        "Goal Revisions": inline_list(goal_revisions),
        "Evidence Follow-up": latex_escape(row.get("followup_prompt", "")),
        "Gold Final Action": latex_escape(str(final_answer.get("commitment_action") or "")),
        "Gold Final Reason": latex_escape(str(final_answer.get("reason") or "")),
    }
    lines = [
        "\\begin{center}",
        "\\small",
        "\\begin{tabularx}{\\linewidth}{>{\\raggedright\\arraybackslash}p{0.2\\linewidth}X}",
        "\\toprule",
        "Field & Value \\\\",
        "\\midrule",
    ]
    for key, value in values.items():
        lines.append(f"{latex_escape(key)} & {value} \\\\")
    lines.extend(
        [
            "\\bottomrule",
            "\\end{tabularx}",
            "\\end{center}",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    snapshot = json.loads(SNAPSHOT_PATH.read_text())
    test_rows = {row["scenario_id"]: row for row in load_jsonl(TEST_ROWS_PATH)}

    out_lines = [
        "% Auto-generated by generate_emnlp_appendix_examples.py",
        "\\section{Family-wise Reference Examples}",
        "Each subsection below shows one paper-final test example per family: the gold interaction contract, the canonical gold trace, and one accomplished GPT-5.5 trace from the checked-in paid runs.",
    ]

    for family, info in snapshot["families"].items():
        gpt_source = Path(info["gpt_source"])
        raw_rows = load_jsonl(gpt_source)
        raw_example = next(
            row
            for row in raw_rows
            if row.get("task_family") == family
            and row.get("static_verification", {}).get("label") == "accomplished"
        )
        scenario_id = raw_example["scenario_id"]
        row = test_rows[scenario_id]

        title = family.replace("_", " ").title()
        out_lines.append(f"\\subsection{{{latex_escape(title)}}}")
        out_lines.append(example_table(row))
        out_lines.append(
            listing_block(
                f"Gold trace for {scenario_id}",
                gold_trace_text(row),
            )
        )
        out_lines.append(
            listing_block(
                f"Accomplished GPT-5.5 trace for {scenario_id}",
                gpt_trace_text(raw_example),
            )
        )

    OUT_PATH.write_text("\n".join(out_lines))


if __name__ == "__main__":
    main()
