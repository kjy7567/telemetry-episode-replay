#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any

from bts_agentbench.taskbench_export import convert_example, load_jsonl


def _freeze(value: Any) -> Any:
    if isinstance(value, dict):
        return tuple(sorted((key, _freeze(val)) for key, val in value.items()))
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    return value


def _normalize_arguments(arguments: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in arguments.items()
        if value is not None
    }


def _normalize_tool_calls(tool_calls: list[dict[str, Any]]) -> list[dict[str, Any]]:
    normalized = []
    for idx, call in enumerate(tool_calls, start=1):
        normalized.append(
            {
                "call_id": call.get("call_id", f"c{idx}"),
                "tool_name": call["tool_name"],
                "arguments": _normalize_arguments(call["arguments"]),
            }
        )
    return normalized


def _normalize_message_row(row: dict[str, Any], source: str) -> dict[str, Any]:
    messages = row["messages"]
    assistant_payload = json.loads(messages[-1]["content"])
    tool_calls = _normalize_tool_calls(assistant_payload["tool_calls"])
    final_answer = assistant_payload["final_answer"]
    evidence = assistant_payload.get("evidence", {})
    return {
        "scenario_id": row["scenario_id"],
        "split": row.get("split", "train"),
        "task_family": row["task_family"],
        "site_id": row["site_id"],
        "source": source,
        "messages": [
            messages[0],
            messages[1],
            {
                "role": "assistant",
                "content": json.dumps(
                    {
                        "tool_calls": tool_calls,
                        "final_answer": final_answer,
                        "evidence": evidence,
                    },
                    ensure_ascii=False,
                ),
            },
        ],
        "query": row["query"],
    }


def _record_signature(row: dict[str, Any]) -> tuple[Any, ...]:
    assistant_payload = json.loads(row["messages"][-1]["content"])
    return (
        row["scenario_id"],
        _freeze(assistant_payload["tool_calls"]),
        _freeze(assistant_payload["final_answer"]),
        _freeze(assistant_payload.get("evidence", {})),
    )


def build_anchor_rows(benchmark_dirs: list[Path], split: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for benchmark_dir in benchmark_dirs:
        for example in load_jsonl(benchmark_dir / f"{split}.jsonl"):
            converted = convert_example(example, "full_agent")
            converted["source"] = "anchor"
            rows.append(converted)
    return rows


def build_source_rows(
    adaptation_paths: list[Path],
    source: str,
    repeat_default: int,
    repair_with_gold_repeat: int,
    prefix_repair_repeat: int,
    retain_teacher_repeat: int,
) -> tuple[list[dict[str, Any]], Counter]:
    rows: list[dict[str, Any]] = []
    stats: Counter = Counter()
    for path in adaptation_paths:
        for raw_row in load_jsonl(path):
            normalized = _normalize_message_row(raw_row, source)
            mode = raw_row.get("adaptation_mode", "retain_teacher")
            repeat = repeat_default
            if mode == "repair_with_gold":
                repeat = repair_with_gold_repeat
            elif mode == "prefix_repair_with_gold":
                repeat = prefix_repair_repeat
            elif mode == "retain_teacher":
                repeat = retain_teacher_repeat
            for _ in range(max(repeat, 0)):
                rows.append(normalized)
            stats[f"{source}:{mode}"] += 1
    return rows, stats


def deduplicate_oracle_rows(
    anchor_rows: list[dict[str, Any]],
    oracle_rows: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], int]:
    anchor_signatures = {_record_signature(row) for row in anchor_rows}
    kept: list[dict[str, Any]] = []
    dropped = 0
    for row in oracle_rows:
        signature = _record_signature(row)
        if signature in anchor_signatures:
            dropped += 1
            continue
        kept.append(row)
    return kept, dropped


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, action="append", required=True)
    parser.add_argument("--repair-jsonl", type=Path, action="append", default=[])
    parser.add_argument("--oracle-jsonl", type=Path, action="append", default=[])
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--repair-default-repeat", type=int, default=4)
    parser.add_argument("--repair-with-gold-repeat", type=int, default=6)
    parser.add_argument("--prefix-repair-repeat", type=int, default=5)
    parser.add_argument("--retain-teacher-repeat", type=int, default=3)
    parser.add_argument("--oracle-repeat", type=int, default=1)
    args = parser.parse_args()

    train_anchor_rows = build_anchor_rows(args.benchmark_dir, "train")
    dev_anchor_rows = build_anchor_rows(args.benchmark_dir, "dev")

    repair_rows, repair_stats = build_source_rows(
        args.repair_jsonl,
        source="repair",
        repeat_default=args.repair_default_repeat,
        repair_with_gold_repeat=args.repair_with_gold_repeat,
        prefix_repair_repeat=args.prefix_repair_repeat,
        retain_teacher_repeat=args.retain_teacher_repeat,
    )
    oracle_rows, oracle_stats = build_source_rows(
        args.oracle_jsonl,
        source="oracle",
        repeat_default=args.oracle_repeat,
        repair_with_gold_repeat=args.oracle_repeat,
        prefix_repair_repeat=args.oracle_repeat,
        retain_teacher_repeat=args.oracle_repeat,
    )
    oracle_rows, oracle_duplicates_dropped = deduplicate_oracle_rows(train_anchor_rows, oracle_rows)

    train_rows = train_anchor_rows + oracle_rows + repair_rows
    dev_rows = dev_anchor_rows

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)

    summary = {
        "train_examples": len(train_rows),
        "dev_examples": len(dev_rows),
        "source_counts": dict(Counter(row["source"] for row in train_rows)),
        "repair_stats": dict(repair_stats),
        "oracle_stats": dict(oracle_stats),
        "oracle_duplicates_dropped": oracle_duplicates_dropped,
        "benchmark_dirs": [str(path) for path in args.benchmark_dir],
        "repair_jsonl": [str(path) for path in args.repair_jsonl],
        "oracle_jsonl": [str(path) for path in args.oracle_jsonl],
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
