#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path
from typing import Any

import torch

from bts_agentbench.runtime import ToolStoreRuntime
from train_qwen_messages_contract_residual_rl import (
    STAGE_ANCHOR_WEIGHTS,
    answer_reward,
    batch_gold_ce_loss,
    batch_sample_response_ids,
    batch_sequence_stats,
    build_prompt_and_gold_ids,
    clarification_reward,
    detect_decision_type,
    followup_bonus,
    load_jsonl,
    load_reference_model,
    load_train_model,
    normalize_text,
    set_valued_tool_reward,
    tokenizer_path_for_model,
    try_parse_json,
)
from peft import PeftConfig
from transformers import AutoTokenizer


TOOL_RESULT_PREFIX = "Tool result:"
RISKY_STAGES = {"tool_call", "evidence_followup_answer", "rationale_followup_answer"}
STREAM_ID_KEYS = ("stream_id", "stream_ids", "left_stream_id", "right_stream_id", "winning_stream_id")

STAGE_REWARD_WEIGHTS = {
    "tool_call": 1.25,
    "clarification_question": 1.0,
    "final_answer": 1.0,
    "evidence_followup_answer": 1.85,
    "rationale_followup_answer": 1.75,
}

EXECUTION_SCORE_KEYS = {
    "aggregate_window": ("mean_value",),
    "compare_window": ("winning_stream_id", "left_mean_value", "right_mean_value"),
    "rank_window": ("ranked_streams",),
    "inspect_quality": ("observed_fraction", "gap_ratio"),
    "inspect_quality_window": ("observed_fraction", "gap_ratio"),
    "lookup_observation": ("value", "exact_match_found"),
}


def _normalize_value(value: Any) -> Any:
    if isinstance(value, str):
        return normalize_text(value)
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, list):
        return [_normalize_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalize_value(item) for key, item in value.items()}
    return str(value)


def parse_tool_result_payload(text: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if not stripped.startswith(TOOL_RESULT_PREFIX):
        return None
    return try_parse_json(stripped[len(TOOL_RESULT_PREFIX) :].strip())


def prior_executed_calls(messages: list[dict[str, str]]) -> list[dict[str, Any]]:
    executed: list[dict[str, Any]] = []
    pending_tool: dict[str, Any] | None = None
    for message in messages:
        role = message.get("role")
        content = message.get("content", "")
        if role == "assistant":
            payload = try_parse_json(content)
            if payload is not None and "tool_name" in payload:
                pending_tool = payload
        elif role == "user":
            payload = parse_tool_result_payload(content)
            if pending_tool is None or payload is None:
                continue
            executed.append(
                {
                    "tool_name": pending_tool.get("tool_name"),
                    "arguments": pending_tool.get("arguments", {}),
                    "call_id": payload.get("call_id"),
                    "output": payload.get("output", {}),
                }
            )
            pending_tool = None
    return executed


def reward_stream_mentions(pred_text: str, gold_text: str) -> float:
    pred_norm = normalize_text(pred_text)
    gold_payload = try_parse_json(gold_text)
    if gold_payload is not None:
        return 0.0
    reward = 0.0
    for token in gold_text.replace(",", " ").split():
        token_norm = normalize_text(token)
        if len(token_norm) >= 12 and "_" in token_norm and token_norm in pred_norm:
            reward += 0.1
    return min(0.3, reward)


def contract_answer_bonus(row: dict[str, Any], pred_text: str) -> float:
    stage = row["stage"]
    pred_norm = normalize_text(pred_text)
    gold_text = row["messages"][-1]["content"]
    bonus = followup_bonus(row, pred_text)

    if stage == "evidence_followup_answer":
        if "i used stream" in pred_norm or pred_norm.startswith("i used "):
            bonus += 0.15
        else:
            bonus -= 0.15
        bonus += reward_stream_mentions(pred_text, gold_text)
    elif stage == "rationale_followup_answer":
        for cue in ("observed coverage", "gap ratio", "answer because", "abstain because"):
            if cue in pred_norm:
                bonus += 0.06
        if "observed coverage" not in pred_norm and "gap ratio" not in pred_norm:
            bonus -= 0.1
    elif stage == "final_answer" and row.get("task_family") == "quality_gate":
        if "abstain" in pred_norm or "answer" in pred_norm:
            bonus += 0.1
        else:
            bonus -= 0.1
    return bonus


def execution_reward(
    row: dict[str, Any],
    pred_text: str,
    runtime: ToolStoreRuntime,
    args: argparse.Namespace,
) -> float:
    payload = try_parse_json(pred_text)
    if payload is None or "tool_name" not in payload or not isinstance(payload.get("arguments", {}), dict):
        return -args.invalid_tool_penalty

    messages = row["messages"][:-1]
    prior_calls = prior_executed_calls(messages)
    reward = 0.0

    if prior_calls:
        last_call = prior_calls[-1]
        if (
            last_call.get("tool_name") == payload.get("tool_name")
            and _normalize_value(last_call.get("arguments", {})) == _normalize_value(payload.get("arguments", {}))
            and isinstance(last_call.get("output"), dict)
            and last_call["output"].get("match_count") == 0
        ):
            reward -= args.repeat_failed_tool_penalty

    call_outputs = {
        call["call_id"]: call["output"]
        for call in prior_calls
        if call.get("call_id") and isinstance(call.get("output"), dict)
    }
    try:
        resolved_arguments = runtime._replace_refs(payload.get("arguments", {}), call_outputs)
        output = runtime.execute_tool(payload["tool_name"], resolved_arguments)
    except Exception:
        return reward - args.execution_error_penalty

    reward += args.execution_success_bonus

    tool_name = payload["tool_name"]
    if tool_name in {"resolve_point", "list_points"}:
        match_count = output.get("match_count")
        if isinstance(match_count, int):
            if match_count <= 0:
                reward -= args.zero_match_penalty
            else:
                reward += min(args.positive_match_bonus, 0.08 * match_count)
        else:
            reward -= args.missing_key_penalty
    else:
        expected_keys = EXECUTION_SCORE_KEYS.get(tool_name)
        if expected_keys is None:
            reward += 0.0
        elif all(key in output for key in expected_keys):
            reward += args.execution_success_bonus
        else:
            reward -= args.missing_key_penalty

    if tool_name == "lookup_observation" and output.get("exact_match_found") is False:
        reward -= 0.05

    return reward


def legality_bonus(row: dict[str, Any], pred_text: str) -> float:
    expected = row.get("decision_type")
    predicted = detect_decision_type(pred_text)
    bonus = 0.3 if predicted == expected else -0.3

    response_format = row.get("response_format")
    parsed = try_parse_json(pred_text)
    if response_format == "compact_json_tool_action":
        bonus += 0.1 if parsed is not None else -0.1
    elif response_format == "natural_language_question":
        bonus += 0.1 if "?" in pred_text else -0.1
    elif response_format == "natural_language_answer":
        bonus += 0.1 if (parsed is None and "?" not in pred_text) else -0.1
    return bonus


def base_reward(
    row: dict[str, Any],
    pred_text: str,
    runtime: ToolStoreRuntime,
    args: argparse.Namespace,
) -> float:
    gold_text = row["messages"][-1]["content"]
    stage = row["stage"]
    if stage == "tool_call":
        reward = set_valued_tool_reward(row, pred_text)
        reward += args.execution_reward_coef * execution_reward(row, pred_text, runtime, args)
    elif stage == "clarification_question":
        reward = clarification_reward(pred_text, gold_text)
    else:
        reward = answer_reward(pred_text, gold_text, stage)
        reward += args.followup_coef * contract_answer_bonus(row, pred_text)

    reward += args.legality_coef * legality_bonus(row, pred_text)

    weighted = reward * STAGE_REWARD_WEIGHTS.get(stage, 1.0) * float(row.get("sample_weight", 1.0))
    if stage in RISKY_STAGES and weighted < args.tail_reward_threshold:
        weighted *= args.tail_reward_scale
    return weighted


def run_epoch(
    model,
    reference_model,
    tokenizer: AutoTokenizer,
    rows: list[dict[str, Any]],
    optimizer: torch.optim.Optimizer,
    runtime: ToolStoreRuntime,
    args: argparse.Namespace,
) -> dict[str, Any]:
    random.shuffle(rows)
    model.train()
    reference_model.eval()

    prompt_batch_rows: list[dict[str, Any]] = []
    reward_sum = 0.0
    reward_count = 0
    step_metrics: list[dict[str, float]] = []
    optimizer.zero_grad(set_to_none=True)

    for row_idx, row in enumerate(rows, start=1):
        prompt_batch_rows.append(row)
        if len(prompt_batch_rows) < args.prompt_batch_size and row_idx != len(rows):
            continue

        prompt_ids_batch: list[torch.Tensor] = []
        gold_response_ids_batch: list[torch.Tensor] = []
        gold_weights: list[float] = []
        stages: list[str] = []
        sampled_prompt_ids_batch: list[torch.Tensor] = []
        sampled_stages: list[str] = []
        group_ids: list[int] = []

        for group_idx, batch_row in enumerate(prompt_batch_rows):
            prompt_ids, gold_response_ids = build_prompt_and_gold_ids(batch_row, tokenizer, args.max_length)
            prompt_ids_batch.append(prompt_ids)
            gold_response_ids_batch.append(gold_response_ids)
            gold_weights.append(float(batch_row.get("sample_weight", 1.0)) * STAGE_ANCHOR_WEIGHTS.get(batch_row["stage"], 1.0))
            stages.append(batch_row["stage"])
            for _ in range(args.samples_per_prompt):
                sampled_prompt_ids_batch.append(prompt_ids)
                sampled_stages.append(batch_row["stage"])
                group_ids.append(group_idx)

        model.eval()
        response_ids_batch = batch_sample_response_ids(
            model,
            sampled_prompt_ids_batch,
            sampled_stages,
            tokenizer,
            temperature=args.temperature,
            top_p=args.top_p,
        )
        model.train()

        rewards_list: list[float] = []
        group_rewards: list[list[float]] = [[] for _ in prompt_batch_rows]
        legal_count = 0
        for batch_row, response_ids, group_idx in zip(
            [prompt_batch_rows[group_id] for group_id in group_ids],
            response_ids_batch,
            group_ids,
            strict=True,
        ):
            pred_text = tokenizer.decode(response_ids, skip_special_tokens=True).strip()
            if detect_decision_type(pred_text) == batch_row.get("decision_type"):
                legal_count += 1
            reward = base_reward(batch_row, pred_text, runtime, args)
            rewards_list.append(reward)
            group_rewards[group_idx].append(reward)
            reward_sum += reward
            reward_count += 1

        rewards = torch.tensor(rewards_list, dtype=torch.float32)
        batch_mean_reward = sum(rewards_list) / max(len(rewards_list), 1)
        batch_std_reward = (
            sum((item - batch_mean_reward) ** 2 for item in rewards_list) / max(len(rewards_list), 1)
        ) ** 0.5
        advantages_list: list[float] = []
        for group_idx, reward in zip(group_ids, rewards_list, strict=True):
            group = group_rewards[group_idx]
            if len(group) > 1:
                mean_reward = sum(group) / len(group)
                std_reward = (sum((item - mean_reward) ** 2 for item in group) / len(group)) ** 0.5
                if std_reward >= args.min_group_std:
                    advantage = (reward - mean_reward) / max(std_reward, 0.1)
                else:
                    advantage = (reward - batch_mean_reward) / max(batch_std_reward, args.min_batch_std)
            else:
                advantage = (reward - batch_mean_reward) / max(batch_std_reward, args.min_batch_std)
            advantages_list.append(advantage)
        advantages = torch.tensor(advantages_list, dtype=torch.float32, device=next(model.parameters()).device)

        current_logprob, _ = batch_sequence_stats(model, sampled_prompt_ids_batch, response_ids_batch, tokenizer)
        with torch.no_grad():
            ref_logprob, _ = batch_sequence_stats(reference_model, sampled_prompt_ids_batch, response_ids_batch, tokenizer)

        pg_loss = -(advantages * current_logprob).mean()
        kl_loss = (current_logprob - ref_logprob).mean()
        anchor_loss = batch_gold_ce_loss(
            model,
            prompt_ids_batch,
            gold_response_ids_batch,
            gold_weights,
            tokenizer,
        )
        total_loss = pg_loss + args.kl_coef * kl_loss + args.anchor_coef * anchor_loss
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)

        step_metrics.append(
            {
                "step": len(step_metrics) + 1,
                "row_idx": row_idx,
                "prompt_batch_size": len(prompt_batch_rows),
                "samples_per_prompt": args.samples_per_prompt,
                "batch_reward_mean": float(rewards.mean().item()),
                "batch_reward_max": float(rewards.max().item()),
                "batch_reward_min": float(rewards.min().item()),
                "batch_reward_std": float(rewards.std(unbiased=False).item()),
                "legal_action_rate": float(legal_count / max(len(rewards_list), 1)),
                "adv_mean": float(advantages.detach().mean().cpu()),
                "adv_abs_mean": float(advantages.detach().abs().mean().cpu()),
                "pg_loss": float(pg_loss.detach().cpu()),
                "kl_loss": float(kl_loss.detach().cpu()),
                "anchor_loss": float(anchor_loss.detach().cpu()),
                "total_loss": float(total_loss.detach().cpu()),
            }
        )
        if args.logging_steps > 0 and len(step_metrics) % args.logging_steps == 0:
            print(json.dumps(step_metrics[-1], ensure_ascii=False))

        prompt_batch_rows = []

    return {
        "mean_reward": reward_sum / max(reward_count, 1),
        "num_samples": reward_count,
        "optimizer_steps": len(step_metrics),
        "last_step": step_metrics[-1] if step_metrics else None,
        "step_metrics_tail": step_metrics[-10:],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--init-model", type=Path, required=True)
    parser.add_argument("--reference-model", type=Path, default=None)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--train-jsonl", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-length", type=int, default=1024)
    parser.add_argument("--num-train-epochs", type=int, default=1)
    parser.add_argument("--learning-rate", type=float, default=5e-6)
    parser.add_argument("--prompt-batch-size", type=int, default=4)
    parser.add_argument("--samples-per-prompt", type=int, default=1)
    parser.add_argument("--temperature", type=float, default=0.55)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--kl-coef", type=float, default=0.15)
    parser.add_argument("--anchor-coef", type=float, default=1.25)
    parser.add_argument("--legality-coef", type=float, default=0.3)
    parser.add_argument("--followup-coef", type=float, default=0.25)
    parser.add_argument("--execution-reward-coef", type=float, default=0.55)
    parser.add_argument("--invalid-tool-penalty", type=float, default=0.7)
    parser.add_argument("--execution-error-penalty", type=float, default=0.55)
    parser.add_argument("--repeat-failed-tool-penalty", type=float, default=0.6)
    parser.add_argument("--zero-match-penalty", type=float, default=0.5)
    parser.add_argument("--positive-match-bonus", type=float, default=0.22)
    parser.add_argument("--execution-success-bonus", type=float, default=0.14)
    parser.add_argument("--missing-key-penalty", type=float, default=0.2)
    parser.add_argument("--tail-reward-threshold", type=float, default=0.0)
    parser.add_argument("--tail-reward-scale", type=float, default=1.25)
    parser.add_argument("--min-group-std", type=float, default=0.05)
    parser.add_argument("--min-batch-std", type=float, default=0.1)
    parser.add_argument("--max-grad-norm", type=float, default=1.0)
    parser.add_argument("--gradient-checkpointing", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--logging-steps", type=int, default=10)
    args = parser.parse_args()

    if args.reference_model is None:
        args.reference_model = args.init_model

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    args.out_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path_for_model(args.init_model))
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_rows = load_jsonl(args.train_jsonl)

    model = load_train_model(args.init_model)
    reference_model = load_reference_model(args.reference_model)
    model.config.use_cache = not args.gradient_checkpointing
    reference_model.config.use_cache = True
    if args.gradient_checkpointing and hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    reference_model.to(device)
    for param in reference_model.parameters():
        param.requires_grad = False
    reference_model.eval()

    if hasattr(model, "print_trainable_parameters"):
        model.print_trainable_parameters()

    optimizer = torch.optim.AdamW((param for param in model.parameters() if param.requires_grad), lr=args.learning_rate)

    training_manifest = {
        "init_model": str(args.init_model),
        "reference_model": str(args.reference_model),
        "tool_store_db": str(args.tool_store_db),
        "train_jsonl": str(args.train_jsonl),
        "train_rows": len(train_rows),
        "max_length": args.max_length,
        "num_train_epochs": args.num_train_epochs,
        "learning_rate": args.learning_rate,
        "prompt_batch_size": args.prompt_batch_size,
        "samples_per_prompt": args.samples_per_prompt,
        "temperature": args.temperature,
        "top_p": args.top_p,
        "kl_coef": args.kl_coef,
        "anchor_coef": args.anchor_coef,
        "legality_coef": args.legality_coef,
        "followup_coef": args.followup_coef,
        "execution_reward_coef": args.execution_reward_coef,
        "gradient_checkpointing": args.gradient_checkpointing,
        "seed": args.seed,
        "algorithm": "execution_grounded_contract_residual_reinforce",
        "initial_policy": "warm_start_adapter",
        "stage_reward_weights": STAGE_REWARD_WEIGHTS,
        "stage_anchor_weights": STAGE_ANCHOR_WEIGHTS,
        "reward_design": {
            "tool_reward": "set_valued_admissible_trace_reward_plus_runtime_execution_bonus",
            "contract_reward": "decision_legality_plus_followup_obligation_bonus",
            "risk_transform": "tail_scaled_negative_contract_outcomes_on_risky_stages",
        },
    }
    (args.out_dir / "training_manifest.json").write_text(json.dumps(training_manifest, indent=2), encoding="utf-8")

    runtime = ToolStoreRuntime(args.tool_store_db)
    try:
        epoch_summaries = []
        for epoch in range(args.num_train_epochs):
            summary = run_epoch(model, reference_model, tokenizer, train_rows, optimizer, runtime, args)
            summary["epoch"] = epoch + 1
            epoch_summaries.append(summary)
            print(json.dumps({"epoch_summary": summary}, ensure_ascii=False))
    finally:
        runtime.close()

    model.save_pretrained(args.out_dir)
    tokenizer.save_pretrained(args.out_dir)
    (args.out_dir / "rl_train_metrics.json").write_text(json.dumps(epoch_summaries, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
