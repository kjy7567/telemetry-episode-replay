from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any

import pandas as pd

from bts_agentbench.evaluator import verify_prediction
from bts_agentbench.runtime import ExecutedCall, ToolStoreRuntime


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle]


def freeze_time(text: str) -> str:
    return str(pd.Timestamp(text))


def collect_stream_ids(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value] if value else []
    if isinstance(value, list):
        out: list[str] = []
        for item in value:
            out.extend(collect_stream_ids(item))
        return out
    if isinstance(value, dict):
        out: list[str] = []
        if isinstance(value.get("stream_id"), str):
            out.append(value["stream_id"])
        for item in value.values():
            out.extend(collect_stream_ids(item))
        return out
    return []


@dataclass
class SolveResult:
    family: str
    executed_calls: list[ExecutedCall]
    final_answer: dict[str, Any] | None
    evidence: dict[str, Any] | None
    parse_error: str | None


class RuleQuerySolver:
    def __init__(self, runtime: ToolStoreRuntime):
        self.runtime = runtime
        self.quality_cutoffs = self._load_quality_cutoffs()

    def _load_quality_cutoffs(self) -> tuple[float | None, float | None, float | None, float | None]:
        ref = self.runtime.window_quality_reference("week")
        if not ref:
            return (None, None, None, None)
        return (
            float(ref["abstain_observed_fraction_below"]) if ref.get("abstain_observed_fraction_below") is not None else None,
            float(ref["answer_observed_fraction_at_least"]) if ref.get("answer_observed_fraction_at_least") is not None else None,
            float(ref["answer_gap_ratio_at_most"]) if ref.get("answer_gap_ratio_at_most") is not None else None,
            float(ref["abstain_gap_ratio_above"]) if ref.get("abstain_gap_ratio_above") is not None else None,
        )

    def _execute(self, calls: list[dict[str, Any]]) -> list[ExecutedCall]:
        return self.runtime.execute_call_sequence(calls)

    @staticmethod
    def _item_phrase(phrase: str) -> tuple[str, str | None]:
        match = re.match(r"^(?P<equipment>.+?)(?: in (?P<location>.+))?$", phrase.strip())
        if not match:
            raise ValueError(f"Could not parse equipment phrase: {phrase}")
        return match.group("equipment"), match.group("location")

    @staticmethod
    def _site(query: str) -> str:
        match = re.match(r"^In (?P<site>[^,]+), ", query)
        if not match:
            raise ValueError("Could not parse site prefix")
        return match.group("site")

    def _family(self, query: str) -> str:
        if "which stream corresponds to the " in query:
            return "point_disambiguation"
        if "weekly trend request" in query or "weekly trend question" in query:
            return "quality_gate"
        if "nearest available observation" in query:
            return "timestamp_nearest_lookup"
        if " what value did the " in query:
            return "timestamp_value_lookup"
        if "during the month starting " in query and "among " in query:
            return "window_rank"
        if "during the week starting " in query and " which " in query:
            return "window_pairwise_compare"
        if "during the week starting " in query and "average value of the " in query:
            return "window_mean_lookup"
        if "during the previous 24 hours" in query:
            return "relative_24h_mean_lookup"
        if ", on " in query and "average value of the " in query:
            return "day_mean_lookup"
        raise ValueError(f"Unsupported query template: {query}")

    def solve(self, query: str) -> SolveResult:
        family = self._family(query)
        handler = getattr(self, f"_solve_{family}")
        return handler(query)

    def _solve_point_disambiguation(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), which stream corresponds to the (?P<point_class>.+?) point on (?P<target>.+)\?$",
            query,
        )
        if not match:
            return SolveResult("point_disambiguation", [], None, None, "parse_error:point_disambiguation")
        equipment, location = self._item_phrase(match.group("target"))
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": equipment,
                    "location_label": location,
                },
            }
        ]
        executed = self._execute(calls)
        final_answer = {"stream_id": executed[-1].output["stream_id"]}
        evidence = {"stream_ids": [executed[-1].output["stream_id"]]}
        return SolveResult("point_disambiguation", executed, final_answer, evidence, None)

    def _solve_day_mean_lookup(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), on (?P<date>\d{4}-\d{2}-\d{2}), what was the average value of the (?P<point_class>.+?) point on (?P<target>.+)\?$",
            query,
        )
        if not match:
            return SolveResult("day_mean_lookup", [], None, None, "parse_error:day_mean_lookup")
        equipment, location = self._item_phrase(match.group("target"))
        start = pd.Timestamp(match.group("date"), tz="UTC")
        end = start + pd.Timedelta(days=1)
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": equipment,
                    "location_label": location,
                },
            },
            {
                "call_id": "c2",
                "tool_name": "aggregate_window",
                "arguments": {
                    "stream_id": "$c1.stream_id",
                    "metric": "mean_value",
                    "window_start": freeze_time(str(start)),
                    "window_end": freeze_time(str(end)),
                    "period": "day",
                },
            },
        ]
        executed = self._execute(calls)
        final_answer = {
            "stream_id": executed[0].output["stream_id"],
            "mean_value": executed[1].output["mean_value"],
        }
        evidence = {"stream_ids": [executed[0].output["stream_id"]]}
        return SolveResult("day_mean_lookup", executed, final_answer, evidence, None)

    def _solve_relative_24h_mean_lookup(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), as of (?P<anchor>[^,]+), what was the average value during the previous 24 hours for the (?P<point_class>.+?) point on (?P<target>.+)\?$",
            query,
        )
        if not match:
            return SolveResult("relative_24h_mean_lookup", [], None, None, "parse_error:relative_24h_mean_lookup")
        equipment, location = self._item_phrase(match.group("target"))
        end = pd.Timestamp(match.group("anchor"))
        start = end - pd.Timedelta(days=1)
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": equipment,
                    "location_label": location,
                },
            },
            {
                "call_id": "c2",
                "tool_name": "aggregate_window",
                "arguments": {
                    "stream_id": "$c1.stream_id",
                    "metric": "mean_value",
                    "window_start": freeze_time(str(start)),
                    "window_end": freeze_time(str(end)),
                    "period": "custom",
                },
            },
        ]
        executed = self._execute(calls)
        final_answer = {
            "stream_id": executed[0].output["stream_id"],
            "mean_value": executed[1].output["mean_value"],
        }
        evidence = {"stream_ids": [executed[0].output["stream_id"]]}
        return SolveResult("relative_24h_mean_lookup", executed, final_answer, evidence, None)

    def _solve_window_mean_lookup(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), during the week starting (?P<date>\d{4}-\d{2}-\d{2}), what was the average value of the (?P<point_class>.+?) point on (?P<target>.+)\?$",
            query,
        )
        if not match:
            return SolveResult("window_mean_lookup", [], None, None, "parse_error:window_mean_lookup")
        equipment, location = self._item_phrase(match.group("target"))
        start = pd.Timestamp(match.group("date"), tz="UTC")
        end = start + pd.Timedelta(days=7)
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": equipment,
                    "location_label": location,
                },
            },
            {
                "call_id": "c2",
                "tool_name": "aggregate_window",
                "arguments": {
                    "stream_id": "$c1.stream_id",
                    "metric": "mean_value",
                    "window_start": freeze_time(str(start)),
                    "window_end": freeze_time(str(end)),
                    "period": "week",
                },
            },
        ]
        executed = self._execute(calls)
        final_answer = {
            "stream_id": executed[0].output["stream_id"],
            "mean_value": executed[1].output["mean_value"],
        }
        evidence = {"stream_ids": [executed[0].output["stream_id"]]}
        return SolveResult("window_mean_lookup", executed, final_answer, evidence, None)

    def _solve_window_pairwise_compare(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), during the week starting (?P<date>\d{4}-\d{2}-\d{2}), which (?P<point_class>.+?) point had the higher average value: (?P<left>.+) or (?P<right>.+)\?$",
            query,
        )
        if not match:
            return SolveResult("window_pairwise_compare", [], None, None, "parse_error:window_pairwise_compare")
        left_equipment, left_location = self._item_phrase(match.group("left"))
        right_equipment, right_location = self._item_phrase(match.group("right"))
        start = pd.Timestamp(match.group("date"), tz="UTC")
        end = start + pd.Timedelta(days=7)
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": left_equipment,
                    "location_label": left_location,
                },
            },
            {
                "call_id": "c2",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": right_equipment,
                    "location_label": right_location,
                },
            },
            {
                "call_id": "c3",
                "tool_name": "compare_window",
                "arguments": {
                    "left_stream_id": "$c1.stream_id",
                    "right_stream_id": "$c2.stream_id",
                    "metric": "mean_value",
                    "window_start": freeze_time(str(start)),
                    "window_end": freeze_time(str(end)),
                    "period": "week",
                },
            },
        ]
        executed = self._execute(calls)
        final_answer = {
            "winning_stream_id": executed[2].output["winning_stream_id"],
            "left_mean_value": executed[2].output["left_value"],
            "right_mean_value": executed[2].output["right_value"],
        }
        evidence = {
            "stream_ids": [
                executed[0].output["stream_id"],
                executed[1].output["stream_id"],
            ]
        }
        return SolveResult("window_pairwise_compare", executed, final_answer, evidence, None)

    def _solve_window_rank(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), during the month starting (?P<date>\d{4}-\d{2}-\d{2}), among (?P<point_class>.+?) points located in (?P<location_type>.+), which stream had the highest average value\?$",
            query,
        )
        if not match:
            return SolveResult("window_rank", [], None, None, "parse_error:window_rank")
        start = pd.Timestamp(match.group("date"), tz="UTC")
        end = start + pd.DateOffset(months=1)
        calls = [
            {
                "call_id": "c1",
                "tool_name": "list_points",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "location_type": match.group("location_type"),
                },
            },
            {
                "call_id": "c2",
                "tool_name": "rank_window",
                "arguments": {
                    "stream_ids": "$c1.stream_ids",
                    "metric": "mean_value",
                    "window_start": freeze_time(str(start)),
                    "window_end": freeze_time(str(end)),
                    "period": "month",
                    "order": "desc",
                    "topk": 1,
                },
            },
        ]
        executed = self._execute(calls)
        scored: list[tuple[str, float]] = []
        for stream_id in executed[0].output["stream_ids"]:
            agg = self.runtime.aggregate_window(
                {
                    "stream_id": stream_id,
                    "metric": "mean_value",
                    "window_start": freeze_time(str(start)),
                    "window_end": freeze_time(str(end)),
                    "period": "month",
                }
            )
            if agg["mean_value"] is None:
                continue
            scored.append((stream_id, float(agg["mean_value"])))
        scored.sort(key=lambda item: (-item[1], item[0]))
        top_stream_id, top_mean_value = scored[0]
        evidence_ids = [top_stream_id]
        if len(scored) > 1:
            evidence_ids.append(scored[1][0])
        final_answer = {"stream_id": top_stream_id, "mean_value": round(top_mean_value, 4)}
        evidence = {"stream_ids": evidence_ids}
        return SolveResult("window_rank", executed, final_answer, evidence, None)

    def _solve_timestamp_value_lookup(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), what value did the (?P<point_class>.+?) point on (?P<target>.+) have at (?P<ts>[^?]+)\?$",
            query,
        )
        if not match:
            return SolveResult("timestamp_value_lookup", [], None, None, "parse_error:timestamp_value_lookup")
        equipment, location = self._item_phrase(match.group("target"))
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": equipment,
                    "location_label": location,
                },
            },
            {
                "call_id": "c2",
                "tool_name": "lookup_observation",
                "arguments": {
                    "stream_id": "$c1.stream_id",
                    "timestamp": match.group("ts"),
                    "mode": "exact",
                },
            },
        ]
        executed = self._execute(calls)
        obs = executed[1].output
        final_answer = {
            "stream_id": obs["stream_id"],
            "observed_timestamp": obs["observed_timestamp"],
            "value": obs["value"],
            "exact_match_found": obs["exact_match_found"],
        }
        evidence = {"stream_ids": [executed[0].output["stream_id"]]}
        return SolveResult("timestamp_value_lookup", executed, final_answer, evidence, None)

    def _solve_timestamp_nearest_lookup(self, query: str) -> SolveResult:
        match = re.match(
            r"^In (?P<site>[^,]+), what is the nearest available observation for the (?P<point_class>.+?) point on (?P<target>.+) to (?P<ts>[^,]+), if no exact reading exists at that timestamp\?$",
            query,
        )
        if not match:
            return SolveResult("timestamp_nearest_lookup", [], None, None, "parse_error:timestamp_nearest_lookup")
        equipment, location = self._item_phrase(match.group("target"))
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": equipment,
                    "location_label": location,
                },
            },
            {
                "call_id": "c2",
                "tool_name": "lookup_observation",
                "arguments": {
                    "stream_id": "$c1.stream_id",
                    "timestamp": match.group("ts"),
                    "mode": "nearest",
                },
            },
        ]
        executed = self._execute(calls)
        obs = executed[1].output
        final_answer = {
            "stream_id": obs["stream_id"],
            "observed_timestamp": obs["observed_timestamp"],
            "value": obs["value"],
            "exact_match_found": obs["exact_match_found"],
            "fallback_reason": obs["fallback_reason"],
            "offset_seconds": obs["offset_seconds"],
        }
        evidence = {"stream_ids": [executed[0].output["stream_id"]]}
        return SolveResult("timestamp_nearest_lookup", executed, final_answer, evidence, None)

    def _solve_quality_gate(self, query: str) -> SolveResult:
        patterns = [
            re.compile(
                r"^In (?P<site>[^,]+), should an agent answer a weekly trend request for the (?P<point_class>.+?) point on (?P<target>.+?) for the week beginning (?P<week>[A-Z][a-z]+ \d{1,2}, \d{4}), or abstain because the data quality is not reliable enough\?$"
            ),
            re.compile(
                r"^For (?P<site>[^,]+), would you trust the (?P<point_class>.+?) point on (?P<target>.+?) enough to answer a weekly trend question for the week of (?P<week>[A-Z][a-z]+ \d{1,2}, \d{4}), or should the agent abstain\?$"
            ),
            re.compile(
                r"^Looking at (?P<site>[^,]+), should the agent answer or abstain on a weekly trend request for the (?P<point_class>.+?) point on (?P<target>.+?) for the week beginning (?P<week>[A-Z][a-z]+ \d{1,2}, \d{4}) because of signal quality concerns\?$"
            ),
        ]
        match = next((m for m in (pattern.match(query) for pattern in patterns) if m), None)
        if not match:
            return SolveResult("quality_gate", [], None, None, "parse_error:quality_gate")
        equipment, location = self._item_phrase(match.group("target"))
        week_start = pd.Timestamp(match.group("week"), tz="UTC")
        calls = [
            {
                "call_id": "c1",
                "tool_name": "resolve_point",
                "arguments": {
                    "site_id": match.group("site"),
                    "point_class": match.group("point_class"),
                    "equipment_label": equipment,
                    "location_label": location,
                },
            },
            {
                "call_id": "c2",
                "tool_name": "inspect_quality_window",
                "arguments": {
                    "stream_id": "$c1.stream_id",
                    "window_start": week_start.isoformat(),
                    "window_end": (week_start + pd.Timedelta(days=7)).isoformat(),
                    "period": "week",
                },
            },
        ]
        executed = self._execute(calls)
        quality = executed[1].output
        ref = quality.get("quality_reference") or self.runtime.window_quality_reference("week")
        obs_q10 = ref.get("abstain_observed_fraction_below")
        obs_q75 = ref.get("answer_observed_fraction_at_least")
        gap_q50 = ref.get("answer_gap_ratio_at_most")
        gap_q95 = ref.get("abstain_gap_ratio_above")
        decision = "answer"
        reason = "healthy"
        if obs_q10 is not None and quality["observed_fraction"] is not None and quality["observed_fraction"] < float(obs_q10):
            decision = "abstain"
            reason = "low_coverage"
        elif gap_q95 is not None and quality["gap_ratio"] is not None and quality["gap_ratio"] > float(gap_q95):
            decision = "abstain"
            reason = "long_gap"
        elif (
            obs_q75 is not None
            and gap_q50 is not None
            and quality["observed_fraction"] is not None
            and quality["gap_ratio"] is not None
            and quality["observed_fraction"] >= float(obs_q75)
            and quality["gap_ratio"] <= float(gap_q50)
        ):
            decision = "answer"
            reason = "healthy"
        final_answer = {
            "decision": decision,
            "reason": reason,
            "observed_fraction": quality["observed_fraction"],
            "gap_ratio": quality["gap_ratio"],
        }
        evidence = {"stream_ids": [executed[0].output["stream_id"]]}
        return SolveResult("quality_gate", executed, final_answer, evidence, None)


def run_solver_on_examples(runtime: ToolStoreRuntime, examples: list[dict[str, Any]]) -> list[dict[str, Any]]:
    solver = RuleQuerySolver(runtime)
    results: list[dict[str, Any]] = []
    for example in examples:
        query = example.get("query") or example.get("initial_user_message") or ""
        try:
            solved = solver.solve(query)
        except Exception as exc:
            solved = SolveResult(
                family=example.get("task_family", "unknown"),
                executed_calls=[],
                final_answer=None,
                evidence=None,
                parse_error=f"parse_error:{type(exc).__name__}:{exc}",
            )
        verification = verify_prediction(
            example,
            solved.executed_calls,
            solved.final_answer,
            solved.evidence,
            runtime,
        )
        if solved.parse_error:
            verification.issues.append(solved.parse_error)
            if verification.strict_label == "accomplished":
                verification.strict_label = "partially_accomplished"
        results.append(
            {
                "scenario_id": example["scenario_id"],
                "task_family": example["task_family"],
                "site_id": example["site_id"],
                "query": query,
                "executed_calls": [call.as_dict() for call in solved.executed_calls],
                "final_answer": solved.final_answer,
                "evidence": solved.evidence,
                "parse_error": solved.parse_error,
                "verification": verification.as_dict(),
            }
        )
    return results


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    labels = Counter(row["verification"]["label"] for row in rows)
    by_family: dict[str, Counter[str]] = {}
    for row in rows:
        fam = row["task_family"]
        by_family.setdefault(fam, Counter())
        by_family[fam][row["verification"]["label"]] += 1
    return {
        "scenario_count": len(rows),
        "label_counts": dict(labels),
        "strict_label_counts": dict(Counter(row["verification"].get("strict_label", row["verification"]["label"]) for row in rows)),
        "mean_process_score": round(mean(row["verification"]["process_score"] for row in rows), 4) if rows else 0.0,
        "mean_final_score": round(mean(row["verification"]["final_score"] for row in rows), 4) if rows else 0.0,
        "mean_evidence_score": round(mean(row["verification"]["evidence_score"] for row in rows), 4) if rows else 0.0,
        "mean_core_score": round(mean(row["verification"]["core_score"] for row in rows), 4) if rows else 0.0,
        "mean_reporting_score": round(mean(row["verification"]["reporting_score"] for row in rows), 4) if rows else 0.0,
        "mean_grounding_score": round(mean(row["verification"]["grounding_score"] for row in rows), 4) if rows else 0.0,
        "mean_temporal_score": round(mean(row["verification"]["temporal_score"] for row in rows), 4) if rows else 0.0,
        "mean_task_score": round(mean(row["verification"]["task_score"] for row in rows), 4) if rows else 0.0,
        "by_family": {fam: dict(counter) for fam, counter in by_family.items()},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--split", choices=["train", "dev", "test"], default="test")
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-summary", type=Path, required=True)
    args = parser.parse_args()

    examples = load_jsonl(args.benchmark_dir / f"{args.split}.jsonl")
    runtime = ToolStoreRuntime(args.tool_store_db)
    try:
        rows = run_solver_on_examples(runtime, examples)
    finally:
        runtime.close()

    summary = summarize(rows)
    summary["solver"] = "rule_query_solver_v1"
    summary["split"] = args.split

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.out_jsonl.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    args.out_summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
