#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from statistics import mean
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = REPO_ROOT.parent
SRC_ROOT = REPO_ROOT / "src"
TAU_ROOT = WORKSPACE_ROOT / "external" / "tau-bench"
SCRIPTS_ROOT = REPO_ROOT / "scripts"
for path in (SRC_ROOT, TAU_ROOT, SCRIPTS_ROOT):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from run_local_agent_eval import LocalChatModel, extract_json_payload
from tau_bench.envs.retail.env import MockRetailDomainEnv
from tau_bench.types import Action, RESPOND_ACTION_NAME, RESPOND_ACTION_FIELD_NAME


SYSTEM_PROMPT = """You are a retail customer-support agent in an interactive task.

At each assistant turn, do exactly one of the following:
1. Return exactly one compact JSON tool action and nothing else:
   {"tool_name":"...", "arguments":{...}}
2. Answer the customer in concise natural language when the task is complete.

Rules:
- Use only the available tools.
- Do not wrap the final answer in JSON.
- Do not invent order ids, item ids, addresses, emails, or payment methods.
"""


class DeterministicTauUser:
    def reset(self, instruction: str) -> str:
        return instruction

    def step(self, content: str) -> str:
        return "###STOP###"

    def get_total_cost(self) -> float:
        return 0.0


def load_task_count(split: str) -> int:
    env = MockRetailDomainEnv(task_split=split, user_strategy="human")
    env.user = DeterministicTauUser()
    return len(env.tasks)


def tool_summary(env: MockRetailDomainEnv) -> str:
    names = [tool["function"]["name"] for tool in env.tools_info]
    return ", ".join(sorted(names))


def scenario_messages(instruction: str, tools_text: str, turns: list[dict[str, str]]) -> list[dict[str, str]]:
    tool_system = SYSTEM_PROMPT + f"\nAvailable tools: {tools_text}"
    return [{"role": "system", "content": tool_system}, {"role": "user", "content": instruction}] + turns


def run_single_task(
    model: LocalChatModel,
    split: str,
    task_index: int,
    max_steps: int,
) -> dict[str, Any]:
    env = MockRetailDomainEnv(task_split=split, task_index=task_index, user_strategy="human")
    env.user = DeterministicTauUser()
    reset = env.reset(task_index=task_index)
    instruction = reset.observation
    tools_text = tool_summary(env)
    turns: list[dict[str, str]] = []
    raw_responses: list[str] = []
    parse_error: str | None = None
    reward = 0.0
    reward_info: dict[str, Any] | None = None
    done = False

    for _ in range(max_steps):
        text = model.generate(scenario_messages(instruction, tools_text, turns))
        raw_responses.append(text)
        try:
            payload = extract_json_payload(text)
        except Exception:
            payload = None

        if isinstance(payload, dict) and "tool_name" in payload:
            action = Action(name=payload["tool_name"], kwargs=payload.get("arguments", {}))
            response = env.step(action)
            turns.append({"role": "assistant", "content": json.dumps(payload, ensure_ascii=False)})
            turns.append({"role": "user", "content": f"Tool result: {response.observation}"})
        else:
            content = text.strip()
            if not content:
                parse_error = "empty_final_answer"
                break
            response = env.step(Action(name=RESPOND_ACTION_NAME, kwargs={RESPOND_ACTION_FIELD_NAME: content}))
            turns.append({"role": "assistant", "content": content})
        reward = response.reward
        reward_info = response.info.reward_info.model_dump() if response.info.reward_info is not None else None
        done = response.done
        if done:
            break

    return {
        "task_index": task_index,
        "instruction": instruction,
        "done": done,
        "reward": reward,
        "reward_info": reward_info,
        "raw_responses": raw_responses,
        "parse_error": parse_error,
        "messages": turns,
    }


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    accomplished = sum(1 for row in rows if float(row["reward"]) >= 1.0)
    mean_reward = mean(float(row["reward"]) for row in rows) if rows else 0.0
    parse_errors = sum(1 for row in rows if row.get("parse_error"))
    return {
        "scenario_count": len(rows),
        "accomplished": accomplished,
        "pass_rate": accomplished / len(rows) if rows else 0.0,
        "mean_reward": mean_reward,
        "parse_errors": parse_errors,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--split", type=str, choices=["dev", "test"], required=True)
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--max-scenarios", type=int, default=20)
    parser.add_argument("--max-steps", type=int, default=8)
    args = parser.parse_args()

    model = LocalChatModel(args.model)
    total = load_task_count(args.split)
    end = min(total, args.start_index + args.max_scenarios)
    rows = [
        run_single_task(model, args.split, task_index, args.max_steps)
        for task_index in range(args.start_index, end)
    ]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    jsonl_path = args.out_dir / f"{args.split}.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    summary = summarize(rows)
    summary.update(
        {
            "model": args.model,
            "split": args.split,
            "start_index": args.start_index,
            "max_scenarios": args.max_scenarios,
            "jsonl_path": str(jsonl_path),
        }
    )
    (args.out_dir / f"{args.split}_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
