#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import random
import re
from collections import Counter
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from peft import AutoPeftModelForCausalLM, PeftConfig
from transformers import AutoModelForCausalLM, AutoTokenizer


STREAM_ID_RE = re.compile(r"[0-9a-f]{8}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{12}", re.IGNORECASE)
TOKEN_RE = re.compile(r"[a-z0-9_:.+-]+")
EPS = 1e-6

STAGE_REWARD_WEIGHTS = {
    "tool_call": 1.0,
    "clarification_question": 1.0,
    "final_answer": 1.0,
    "evidence_followup_answer": 1.6,
    "rationale_followup_answer": 1.4,
}

STAGE_ANCHOR_WEIGHTS = {
    "tool_call": 1.2,
    "clarification_question": 1.0,
    "final_answer": 1.0,
    "evidence_followup_answer": 1.35,
    "rationale_followup_answer": 1.35,
}


def build_stage_weights(args: argparse.Namespace) -> tuple[dict[str, float], dict[str, float]]:
    reward_weights = {
        "tool_call": args.tool_reward_weight,
        "clarification_question": args.clarification_reward_weight,
        "final_answer": args.final_reward_weight,
        "evidence_followup_answer": args.evidence_reward_weight,
        "rationale_followup_answer": args.rationale_reward_weight,
    }
    anchor_weights = {
        "tool_call": args.tool_anchor_weight,
        "clarification_question": args.clarification_anchor_weight,
        "final_answer": args.final_anchor_weight,
        "evidence_followup_answer": args.evidence_anchor_weight,
        "rationale_followup_answer": args.rationale_anchor_weight,
    }
    return reward_weights, anchor_weights


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def normalize_text(text: str) -> str:
    return " ".join(text.lower().strip().split())


def tokenize_text(text: str) -> list[str]:
    return TOKEN_RE.findall(normalize_text(text))


def token_f1(pred: str, gold: str) -> float:
    pred_tokens = tokenize_text(pred)
    gold_tokens = tokenize_text(gold)
    if not pred_tokens or not gold_tokens:
        return 0.0
    pred_counts = Counter(pred_tokens)
    gold_counts = Counter(gold_tokens)
    overlap = sum(min(pred_counts[token], gold_counts[token]) for token in pred_counts.keys() & gold_counts.keys())
    if overlap == 0:
        return 0.0
    precision = overlap / len(pred_tokens)
    recall = overlap / len(gold_tokens)
    return 2 * precision * recall / max(precision + recall, EPS)


def try_parse_json(text: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?\s*|\s*```$", "", stripped, flags=re.DOTALL)
    try:
        parsed = json.loads(stripped)
        return parsed if isinstance(parsed, dict) else None
    except Exception:
        pass

    start = stripped.find("{")
    if start == -1:
        return None
    depth = 0
    in_string = False
    escape = False
    for idx, char in enumerate(stripped[start:], start=start):
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == "\"":
                in_string = False
            continue
        if char == "\"":
            in_string = True
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                try:
                    parsed = json.loads(stripped[start : idx + 1])
                    return parsed if isinstance(parsed, dict) else None
                except Exception:
                    return None
    return None


def _normalize_value(value: Any) -> Any:
    if isinstance(value, str):
        return normalize_text(value)
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, list):
        return [_normalize_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalize_value(item) for key, item in value.items()}
    return str(value)


def structured_tool_reward(pred_text: str, gold_text: str) -> float:
    pred = try_parse_json(pred_text)
    gold = try_parse_json(gold_text)
    if pred is None or gold is None:
        return -0.2

    pred_tool = normalize_text(str(pred.get("tool_name", "")))
    gold_tool = normalize_text(str(gold.get("tool_name", "")))
    pred_args = _normalize_value(pred.get("arguments", {}))
    gold_args = _normalize_value(gold.get("arguments", {}))
    if not isinstance(pred_args, dict) or not isinstance(gold_args, dict):
        return -0.2

    if pred_tool == gold_tool and pred_args == gold_args:
        return 1.0

    reward = 0.0
    if pred_tool == gold_tool:
        reward += 0.45

    if gold_args:
        match_count = 0.0
        for key, gold_value in gold_args.items():
            if key not in pred_args:
                continue
            pred_value = pred_args[key]
            if pred_value == gold_value:
                match_count += 1.0
            elif isinstance(pred_value, str) and isinstance(gold_value, str):
                match_count += token_f1(pred_value, gold_value)
        reward += 0.55 * (match_count / len(gold_args))

    extra_keys = set(pred_args) - set(gold_args)
    reward -= 0.08 * len(extra_keys)
    return max(-0.2, min(1.0, reward))


def clarification_reward(pred_text: str, gold_text: str) -> float:
    pred_norm = normalize_text(pred_text)
    gold_norm = normalize_text(gold_text)
    if pred_norm == gold_norm:
        return 1.0

    reward = 0.55 * token_f1(pred_text, gold_text)
    if "?" in pred_text:
        reward += 0.1
    else:
        reward -= 0.05

    gold_tokens = set(tokenize_text(gold_text))
    pred_tokens = set(tokenize_text(pred_text))
    for keyword in ["date", "day", "week", "month", "window", "timestamp", "time", "average", "seconds"]:
        if keyword in gold_tokens and keyword in pred_tokens:
            reward += 0.08
    return max(-0.1, min(1.0, reward))


def answer_reward(pred_text: str, gold_text: str, stage: str) -> float:
    pred_norm = normalize_text(pred_text)
    gold_norm = normalize_text(gold_text)
    if pred_norm == gold_norm:
        return 1.0

    reward = 0.55 * token_f1(pred_text, gold_text)

    gold_stream_ids = STREAM_ID_RE.findall(gold_text)
    if gold_stream_ids:
        hits = sum(1 for stream_id in gold_stream_ids if normalize_text(stream_id) in pred_norm)
        reward += 0.45 * (hits / len(gold_stream_ids))
    else:
        numbers = re.findall(r"\d+(?:\.\d+)?", gold_text)
        if numbers:
            hits = sum(1 for number in numbers if number in pred_text)
            reward += 0.3 * (hits / len(numbers))

    if stage == "rationale_followup_answer":
        for cue in ["answer", "abstain", "healthy", "reliable", "coverage", "gap", "insufficient"]:
            if cue in gold_norm and cue in pred_norm:
                reward += 0.05

    if stage != "tool_call" and try_parse_json(pred_text) is not None:
        reward -= 0.1
    return max(-0.15, min(1.0, reward))


def base_reward(row: dict[str, Any], pred_text: str, stage_reward_weights: dict[str, float]) -> float:
    gold_text = row["messages"][-1]["content"]
    stage = row["stage"]
    if stage == "tool_call":
        reward = structured_tool_reward(pred_text, gold_text)
    elif stage == "clarification_question":
        reward = clarification_reward(pred_text, gold_text)
    else:
        reward = answer_reward(pred_text, gold_text, stage)

    token_count = len(tokenize_text(pred_text))
    if stage == "tool_call" and token_count > 40:
        reward -= 0.05
    if stage == "clarification_question" and token_count > 24:
        reward -= 0.05
    return reward * stage_reward_weights.get(stage, 1.0)


def stage_max_new_tokens(stage: str) -> int:
    if stage == "tool_call":
        return 96
    if stage == "clarification_question":
        return 48
    return 80


def build_prompt_and_gold_ids(
    row: dict[str, Any],
    tokenizer: AutoTokenizer,
    max_length: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    prompt_text = tokenizer.apply_chat_template(
        row["messages"][:-1],
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    full_text = tokenizer.apply_chat_template(
        row["messages"],
        tokenize=False,
        add_generation_prompt=False,
        enable_thinking=False,
    )
    prompt_ids = tokenizer(prompt_text, add_special_tokens=False).input_ids
    full_ids = tokenizer(full_text, add_special_tokens=False).input_ids
    if len(full_ids) >= len(prompt_ids) and full_ids[: len(prompt_ids)] == prompt_ids:
        response_ids = full_ids[len(prompt_ids) :]
    else:
        response_ids = tokenizer(row["messages"][-1]["content"], add_special_tokens=False).input_ids
    prompt_ids = prompt_ids[-max(1, max_length - max(1, len(response_ids))):]
    full_len = min(max_length, len(prompt_ids) + len(response_ids))
    prompt_keep = min(len(prompt_ids), max(full_len - len(response_ids), 0))
    prompt_ids = prompt_ids[-prompt_keep:] if prompt_keep > 0 else []
    response_keep = max_length - len(prompt_ids)
    response_ids = response_ids[:response_keep]
    return torch.tensor(prompt_ids, dtype=torch.long), torch.tensor(response_ids, dtype=torch.long)


def _left_pad_batch(sequences: list[torch.Tensor], pad_id: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    max_len = max(seq.numel() for seq in sequences)
    input_ids = []
    attention_masks = []
    for seq in sequences:
        pad_len = max_len - seq.numel()
        input_ids.append(torch.cat([torch.full((pad_len,), pad_id, dtype=torch.long), seq], dim=0))
        attention_masks.append(torch.cat([torch.zeros(pad_len, dtype=torch.long), torch.ones(seq.numel(), dtype=torch.long)], dim=0))
    return torch.stack(input_ids).to(device), torch.stack(attention_masks).to(device)


def _right_pad_batch(sequences: list[torch.Tensor], pad_id: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    max_len = max(seq.numel() for seq in sequences)
    input_ids = []
    attention_masks = []
    for seq in sequences:
        pad_len = max_len - seq.numel()
        input_ids.append(torch.cat([seq, torch.full((pad_len,), pad_id, dtype=torch.long)], dim=0))
        attention_masks.append(torch.cat([torch.ones(seq.numel(), dtype=torch.long), torch.zeros(pad_len, dtype=torch.long)], dim=0))
    return torch.stack(input_ids).to(device), torch.stack(attention_masks).to(device)


@torch.no_grad()
def batch_sample_response_ids(
    model,
    prompt_ids_batch: list[torch.Tensor],
    stages: list[str],
    tokenizer: AutoTokenizer,
    temperature: float,
    top_p: float,
) -> list[torch.Tensor]:
    device = next(model.parameters()).device
    input_ids, attention_mask = _left_pad_batch(prompt_ids_batch, tokenizer.pad_token_id, device)
    prompt_batch_len = input_ids.shape[1]
    outputs = model.generate(
        input_ids=input_ids,
        attention_mask=attention_mask,
        max_new_tokens=max(stage_max_new_tokens(stage) for stage in stages),
        do_sample=True,
        temperature=temperature,
        top_p=top_p,
        pad_token_id=tokenizer.pad_token_id,
        eos_token_id=tokenizer.eos_token_id,
    )
    response_batch: list[torch.Tensor] = []
    for row in outputs:
        response_ids = row[prompt_batch_len:].detach().cpu()
        while response_ids.numel() > 0 and response_ids[-1].item() == tokenizer.pad_token_id:
            response_ids = response_ids[:-1]
        response_batch.append(response_ids)
    return response_batch


def batch_sequence_stats(
    model,
    prompt_ids_batch: list[torch.Tensor],
    response_ids_batch: list[torch.Tensor],
    tokenizer: AutoTokenizer,
) -> tuple[torch.Tensor, torch.Tensor]:
    device = next(model.parameters()).device
    full_sequences = [torch.cat([prompt_ids, response_ids], dim=0) for prompt_ids, response_ids in zip(prompt_ids_batch, response_ids_batch)]
    input_ids, attention_mask = _right_pad_batch(full_sequences, tokenizer.pad_token_id, device)
    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    shift_logits = outputs.logits[:, :-1, :]
    shift_targets = input_ids[:, 1:]
    log_probs = F.log_softmax(shift_logits.float(), dim=-1)
    selected = log_probs.gather(2, shift_targets.unsqueeze(-1)).squeeze(-1)

    loss_mask = torch.zeros_like(shift_targets, dtype=torch.float32, device=device)
    token_counts = torch.zeros(shift_targets.size(0), dtype=torch.float32, device=device)
    for idx, (prompt_ids, response_ids) in enumerate(zip(prompt_ids_batch, response_ids_batch)):
        prompt_len = prompt_ids.numel()
        response_len = response_ids.numel()
        if response_len == 0:
            continue
        start = max(prompt_len - 1, 0)
        end = start + response_len
        loss_mask[idx, start:end] = 1.0
        token_counts[idx] = float(response_len)

    seq_logprob = (selected * loss_mask).sum(dim=1)
    mean_logprob = seq_logprob / token_counts.clamp(min=1.0)
    return mean_logprob, token_counts


def batch_gold_ce_loss(
    model,
    prompt_ids_batch: list[torch.Tensor],
    gold_response_ids_batch: list[torch.Tensor],
    row_weights: list[float],
    tokenizer: AutoTokenizer,
) -> torch.Tensor:
    device = next(model.parameters()).device
    full_sequences = [torch.cat([prompt_ids, response_ids], dim=0) for prompt_ids, response_ids in zip(prompt_ids_batch, gold_response_ids_batch)]
    input_ids, attention_mask = _right_pad_batch(full_sequences, tokenizer.pad_token_id, device)
    labels = input_ids.clone()
    for idx, (prompt_ids, response_ids) in enumerate(zip(prompt_ids_batch, gold_response_ids_batch)):
        prompt_len = prompt_ids.numel()
        response_len = response_ids.numel()
        if response_len == 0:
            labels[idx] = -100
            continue
        labels[idx, :prompt_len] = -100
        labels[idx, prompt_len + response_len :] = -100

    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    shift_logits = outputs.logits[:, :-1, :]
    shift_labels = labels[:, 1:]
    token_loss = F.cross_entropy(
        shift_logits.reshape(-1, shift_logits.size(-1)),
        shift_labels.reshape(-1),
        reduction="none",
        ignore_index=-100,
    ).reshape(shift_labels.size())
    valid_mask = (shift_labels != -100).float()
    per_example_den = valid_mask.sum(dim=1).clamp(min=1.0)
    per_example_loss = (token_loss * valid_mask).sum(dim=1) / per_example_den
    weights = torch.tensor(row_weights, dtype=torch.float32, device=device)
    return (per_example_loss * weights).sum() / weights.sum().clamp(min=EPS)


def load_train_model(model_path: Path):
    if (model_path / "adapter_config.json").exists():
        return AutoPeftModelForCausalLM.from_pretrained(
            str(model_path),
            is_trainable=True,
            torch_dtype=torch.bfloat16,
        )
    return AutoModelForCausalLM.from_pretrained(str(model_path), torch_dtype=torch.bfloat16)


def load_reference_model(model_path: Path):
    if (model_path / "adapter_config.json").exists():
        return AutoPeftModelForCausalLM.from_pretrained(
            str(model_path),
            is_trainable=False,
            torch_dtype=torch.bfloat16,
        )
    return AutoModelForCausalLM.from_pretrained(str(model_path), torch_dtype=torch.bfloat16)


def tokenizer_path_for_model(model_path: Path) -> str:
    if (model_path / "adapter_config.json").exists():
        cfg = PeftConfig.from_pretrained(str(model_path))
        return cfg.base_model_name_or_path
    return str(model_path)


def run_epoch(
    model,
    reference_model,
    tokenizer: AutoTokenizer,
    rows: list[dict[str, Any]],
    optimizer: torch.optim.Optimizer,
    args: argparse.Namespace,
    stage_reward_weights: dict[str, float],
    stage_anchor_weights: dict[str, float],
) -> dict[str, Any]:
    random.shuffle(rows)
    model.train()
    reference_model.eval()

    prompt_batch_rows: list[dict[str, Any]] = []
    reward_sum = 0.0
    reward_count = 0
    step_metrics: list[dict[str, float]] = []
    optimizer.zero_grad(set_to_none=True)

    for row_idx, row in enumerate(rows, start=1):
        prompt_batch_rows.append(row)
        if len(prompt_batch_rows) < args.prompt_batch_size and row_idx != len(rows):
            continue

        prompt_ids_batch: list[torch.Tensor] = []
        gold_response_ids_batch: list[torch.Tensor] = []
        gold_weights: list[float] = []
        stages: list[str] = []
        sampled_prompt_ids_batch: list[torch.Tensor] = []
        sampled_stages: list[str] = []
        group_ids: list[int] = []

        for group_idx, batch_row in enumerate(prompt_batch_rows):
            prompt_ids, gold_response_ids = build_prompt_and_gold_ids(batch_row, tokenizer, args.max_length)
            prompt_ids_batch.append(prompt_ids)
            gold_response_ids_batch.append(gold_response_ids)
            gold_weights.append(float(batch_row.get("sample_weight", 1.0)) * stage_anchor_weights.get(batch_row["stage"], 1.0))
            stages.append(batch_row["stage"])
            for _ in range(args.samples_per_prompt):
                sampled_prompt_ids_batch.append(prompt_ids)
                sampled_stages.append(batch_row["stage"])
                group_ids.append(group_idx)

        model.eval()
        response_ids_batch = batch_sample_response_ids(
            model,
            sampled_prompt_ids_batch,
            sampled_stages,
            tokenizer,
            temperature=args.temperature,
            top_p=args.top_p,
        )
        model.train()

        rewards_list: list[float] = []
        pred_texts: list[str] = []
        group_rewards: list[list[float]] = [[] for _ in prompt_batch_rows]
        for batch_row, response_ids, group_idx in zip(
            [prompt_batch_rows[group_id] for group_id in group_ids],
            response_ids_batch,
            group_ids,
            strict=True,
        ):
            pred_text = tokenizer.decode(response_ids, skip_special_tokens=True).strip()
            pred_texts.append(pred_text)
            reward = base_reward(batch_row, pred_text, stage_reward_weights) * float(batch_row.get("sample_weight", 1.0))
            rewards_list.append(reward)
            group_rewards[group_idx].append(reward)
            reward_sum += reward
            reward_count += 1

        rewards = torch.tensor(rewards_list, dtype=torch.float32)
        batch_mean_reward = sum(rewards_list) / max(len(rewards_list), 1)
        batch_std_reward = (
            sum((item - batch_mean_reward) ** 2 for item in rewards_list) / max(len(rewards_list), 1)
        ) ** 0.5
        advantages_list: list[float] = []
        for group_idx, reward in zip(group_ids, rewards_list, strict=True):
            group = group_rewards[group_idx]
            if len(group) > 1:
                mean_reward = sum(group) / len(group)
                std_reward = (sum((item - mean_reward) ** 2 for item in group) / len(group)) ** 0.5
                if std_reward >= args.min_group_std:
                    advantage = (reward - mean_reward) / max(std_reward, 0.1)
                else:
                    advantage = (reward - batch_mean_reward) / max(batch_std_reward, args.min_batch_std)
            else:
                advantage = (reward - batch_mean_reward) / max(batch_std_reward, args.min_batch_std)
            advantages_list.append(advantage)
        advantages = torch.tensor(advantages_list, dtype=torch.float32, device=next(model.parameters()).device)

        current_logprob, _ = batch_sequence_stats(model, sampled_prompt_ids_batch, response_ids_batch, tokenizer)
        with torch.no_grad():
            ref_logprob, _ = batch_sequence_stats(reference_model, sampled_prompt_ids_batch, response_ids_batch, tokenizer)

        pg_loss = -(advantages * current_logprob).mean()
        kl_loss = (current_logprob - ref_logprob).mean()
        anchor_loss = batch_gold_ce_loss(
            model,
            prompt_ids_batch,
            gold_response_ids_batch,
            gold_weights,
            tokenizer,
        )
        total_loss = pg_loss + args.kl_coef * kl_loss + args.anchor_coef * anchor_loss
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)

        step_metrics.append(
            {
                "step": len(step_metrics) + 1,
                "row_idx": row_idx,
                "prompt_batch_size": len(prompt_batch_rows),
                "samples_per_prompt": args.samples_per_prompt,
                "batch_reward_mean": float(rewards.mean().item()),
                "batch_reward_max": float(rewards.max().item()),
                "batch_reward_min": float(rewards.min().item()),
                "batch_reward_std": float(rewards.std(unbiased=False).item()),
                "adv_mean": float(advantages.detach().mean().cpu()),
                "adv_abs_mean": float(advantages.detach().abs().mean().cpu()),
                "pg_loss": float(pg_loss.detach().cpu()),
                "kl_loss": float(kl_loss.detach().cpu()),
                "anchor_loss": float(anchor_loss.detach().cpu()),
                "total_loss": float(total_loss.detach().cpu()),
                "current_logprob_mean": float(current_logprob.detach().mean().cpu()),
                "ref_logprob_mean": float(ref_logprob.detach().mean().cpu()),
            }
        )
        if args.logging_steps > 0 and len(step_metrics) % args.logging_steps == 0:
            print(json.dumps(step_metrics[-1], ensure_ascii=False))

        prompt_batch_rows = []

    return {
        "mean_reward": reward_sum / max(reward_count, 1),
        "num_samples": reward_count,
        "optimizer_steps": len(step_metrics),
        "last_step": step_metrics[-1] if step_metrics else None,
        "step_metrics_tail": step_metrics[-10:],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--init-model", type=Path, required=True)
    parser.add_argument("--reference-model", type=Path, default=None)
    parser.add_argument("--train-jsonl", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-length", type=int, default=1536)
    parser.add_argument("--num-train-epochs", type=int, default=1)
    parser.add_argument("--learning-rate", type=float, default=5e-5)
    parser.add_argument("--prompt-batch-size", type=int, default=2)
    parser.add_argument("--samples-per-prompt", type=int, default=2)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--kl-coef", type=float, default=0.05)
    parser.add_argument("--anchor-coef", type=float, default=0.5)
    parser.add_argument("--min-group-std", type=float, default=0.05)
    parser.add_argument("--min-batch-std", type=float, default=0.1)
    parser.add_argument("--max-grad-norm", type=float, default=1.0)
    parser.add_argument("--gradient-checkpointing", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--logging-steps", type=int, default=10)
    parser.add_argument("--tool-reward-weight", type=float, default=STAGE_REWARD_WEIGHTS["tool_call"])
    parser.add_argument("--clarification-reward-weight", type=float, default=STAGE_REWARD_WEIGHTS["clarification_question"])
    parser.add_argument("--final-reward-weight", type=float, default=STAGE_REWARD_WEIGHTS["final_answer"])
    parser.add_argument("--evidence-reward-weight", type=float, default=STAGE_REWARD_WEIGHTS["evidence_followup_answer"])
    parser.add_argument("--rationale-reward-weight", type=float, default=STAGE_REWARD_WEIGHTS["rationale_followup_answer"])
    parser.add_argument("--tool-anchor-weight", type=float, default=STAGE_ANCHOR_WEIGHTS["tool_call"])
    parser.add_argument("--clarification-anchor-weight", type=float, default=STAGE_ANCHOR_WEIGHTS["clarification_question"])
    parser.add_argument("--final-anchor-weight", type=float, default=STAGE_ANCHOR_WEIGHTS["final_answer"])
    parser.add_argument("--evidence-anchor-weight", type=float, default=STAGE_ANCHOR_WEIGHTS["evidence_followup_answer"])
    parser.add_argument("--rationale-anchor-weight", type=float, default=STAGE_ANCHOR_WEIGHTS["rationale_followup_answer"])
    args = parser.parse_args()

    if args.reference_model is None:
        args.reference_model = args.init_model

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    args.out_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path_for_model(args.init_model))
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_rows = load_jsonl(args.train_jsonl)
    stage_reward_weights, stage_anchor_weights = build_stage_weights(args)

    model = load_train_model(args.init_model)
    reference_model = load_reference_model(args.reference_model)
    model.config.use_cache = not args.gradient_checkpointing
    reference_model.config.use_cache = True
    if args.gradient_checkpointing and hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    reference_model.to(device)
    for param in reference_model.parameters():
        param.requires_grad = False
    reference_model.eval()

    if hasattr(model, "print_trainable_parameters"):
        model.print_trainable_parameters()

    optimizer = torch.optim.AdamW((param for param in model.parameters() if param.requires_grad), lr=args.learning_rate)

    training_manifest = {
        "init_model": str(args.init_model),
        "reference_model": str(args.reference_model),
        "train_jsonl": str(args.train_jsonl),
        "train_rows": len(train_rows),
        "max_length": args.max_length,
        "num_train_epochs": args.num_train_epochs,
        "learning_rate": args.learning_rate,
        "prompt_batch_size": args.prompt_batch_size,
        "samples_per_prompt": args.samples_per_prompt,
        "temperature": args.temperature,
        "top_p": args.top_p,
        "kl_coef": args.kl_coef,
        "anchor_coef": args.anchor_coef,
        "min_group_std": args.min_group_std,
        "min_batch_std": args.min_batch_std,
        "gradient_checkpointing": args.gradient_checkpointing,
        "seed": args.seed,
        "algorithm": "anchored_group_reinforce",
        "initial_policy": "warm_start_adapter",
        "stage_reward_weights": stage_reward_weights,
        "stage_anchor_weights": stage_anchor_weights,
    }
    (args.out_dir / "training_manifest.json").write_text(json.dumps(training_manifest, indent=2), encoding="utf-8")

    epoch_summaries = []
    for epoch in range(args.num_train_epochs):
        summary = run_epoch(
            model,
            reference_model,
            tokenizer,
            train_rows,
            optimizer,
            args,
            stage_reward_weights,
            stage_anchor_weights,
        )
        summary["epoch"] = epoch + 1
        epoch_summaries.append(summary)
        print(json.dumps({"epoch_summary": summary}, ensure_ascii=False))

    model.save_pretrained(args.out_dir)
    tokenizer.save_pretrained(args.out_dir)
    (args.out_dir / "rl_train_metrics.json").write_text(json.dumps(epoch_summaries, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
