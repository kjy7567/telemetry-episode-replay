#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.taskbench_export import load_jsonl


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, action="append", required=True)
    parser.add_argument("--out-jsonl", type=Path, required=True)
    args = parser.parse_args()

    rows: list[dict] = []
    for benchmark_dir in args.benchmark_dir:
        corpus = benchmark_dir.parent.name if benchmark_dir.parent.name != "data" else "bts"
        for example in load_jsonl(benchmark_dir / "train.jsonl"):
            rows.append(
                {
                    "scenario_id": example["scenario_id"],
                    "corpus": corpus,
                    "site_id": example["site_id"],
                    "task_family": example["task_family"],
                    "query": example["query"],
                    "benchmark_dir": str(benchmark_dir),
                }
            )

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.out_jsonl.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(json.dumps({"candidate_count": len(rows), "out_jsonl": str(args.out_jsonl)}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
