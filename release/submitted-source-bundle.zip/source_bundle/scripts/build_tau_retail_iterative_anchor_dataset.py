#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = REPO_ROOT.parent
SRC_ROOT = REPO_ROOT / "src"
TAU_ROOT = WORKSPACE_ROOT / "external" / "tau-bench"
for path in (SRC_ROOT, TAU_ROOT):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from tau_bench.envs.retail.data import load_data
from tau_bench.envs.retail.tasks_dev import TASKS_DEV
from tau_bench.envs.retail.tasks_train import TASKS_TRAIN
from tau_bench.envs.retail.tools import ALL_TOOLS
from tau_bench.types import RESPOND_ACTION_NAME, Action, Task

from bts_agentbench.iterative_contract import contract_fields, contract_manifest_fields


SYSTEM_PROMPT = """You are a retail support agent in a tool-using loop.

At each assistant turn, do exactly one of the following:
1. Return exactly one compact JSON action and nothing else:
   {"tool_name":"...", "arguments":{...}}
2. Answer the customer in concise natural language once the task is complete.

Rules:
- Use only the available retail tools.
- Do not wrap the final answer in JSON.
- Do not invent order ids, item ids, addresses, emails, or payment methods.
"""


def load_tasks(split: str) -> list[Task]:
    if split == "train":
        return TASKS_TRAIN
    if split == "dev":
        return TASKS_DEV
    raise ValueError(f"Unsupported split for training view: {split}")


def tool_name_list() -> list[str]:
    names = []
    for tool in ALL_TOOLS:
        names.append(tool.get_info()["function"]["name"])
    return sorted(names)


def compact_tool_result(name: str, result: Any) -> str:
    text = json.dumps(result, ensure_ascii=False) if isinstance(result, (dict, list)) else str(result)
    return f"{name} -> {text}"


def final_answer_for_task(task: Task) -> str:
    respond_actions = [action for action in task.actions if action.name == RESPOND_ACTION_NAME]
    if respond_actions:
        return str(respond_actions[-1].kwargs.get("content", "")).strip()
    if task.outputs:
        return " ".join(output.strip() for output in task.outputs if output.strip())
    return "I completed the requested retail support task."


def execute_nonrespond_actions(task: Task) -> list[tuple[Action, Any]]:
    data = copy.deepcopy(load_data())
    tools_map = {tool.get_info()["function"]["name"]: tool for tool in ALL_TOOLS}
    executed: list[tuple[Action, Any]] = []
    for action in task.actions:
        if action.name == RESPOND_ACTION_NAME:
            continue
        result = tools_map[action.name].invoke(data=data, **action.kwargs)
        executed.append((action, result))
    return executed


def make_record(
    *,
    task: Task,
    split: str,
    task_index: int,
    stage: str,
    step_index: int,
    history: list[dict[str, str]],
) -> dict[str, Any]:
    return {
        "scenario_id": f"tau_retail_{split}_{task_index:05d}",
        "split": split,
        "task_family": "tau_retail",
        "site_id": "tau_retail",
        "track": "tau_retail_e2e",
        "source": "anchor",
        "stage": stage,
        "step_index": step_index,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}] + history,
        "query": task.instruction,
        "metadata": {
            "user_id": task.user_id,
            "available_tools": tool_name_list(),
        },
        **contract_fields(stage),
    }


def build_rows_for_task(task: Task, split: str, task_index: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    history: list[dict[str, str]] = [{"role": "user", "content": task.instruction}]
    step_index = 1

    for action, result in execute_nonrespond_actions(task):
        tool_payload = json.dumps(
            {"tool_name": action.name, "arguments": action.kwargs},
            ensure_ascii=False,
        )
        rows.append(
            make_record(
                task=task,
                split=split,
                task_index=task_index,
                stage="tool_call",
                step_index=step_index,
                history=history + [{"role": "assistant", "content": tool_payload}],
            )
        )
        history.extend(
            [
                {"role": "assistant", "content": tool_payload},
                {"role": "user", "content": f"Tool result: {compact_tool_result(action.name, result)}"},
            ]
        )
        step_index += 1

    final_answer = final_answer_for_task(task)
    rows.append(
        make_record(
            task=task,
            split=split,
            task_index=task_index,
            stage="final_answer",
            step_index=step_index,
            history=history + [{"role": "assistant", "content": final_answer}],
        )
    )
    return rows


def build_split_rows(split: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for idx, task in enumerate(load_tasks(split)):
        rows.extend(build_rows_for_task(task, split, idx))
    return rows


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    train_rows = build_split_rows("train")
    dev_rows = build_split_rows("dev")

    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)
    stage_counts_train = dict(Counter(row["stage"] for row in train_rows))
    manifest = {
        "track": "tau_retail_e2e",
        "source": "iterative_anchor",
        "train_examples": len(train_rows),
        "dev_examples": len(dev_rows),
        "stage_counts_train": stage_counts_train,
        "task_counts": {"train": len(TASKS_TRAIN), "dev": len(TASKS_DEV)},
        "tool_count": len(tool_name_list()),
        "benchmark_source": str(TAU_ROOT),
        **contract_manifest_fields(stage_counts_train),
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
