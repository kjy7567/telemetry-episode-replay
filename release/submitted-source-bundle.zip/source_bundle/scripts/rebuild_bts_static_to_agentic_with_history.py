#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from bts_agentbench.bts_e2e import build_bts_e2e
from bts_agentbench.runtime import ToolStoreRuntime

from audit_bts_canonical_contract import audit_contract
from build_bts_e2e_agentic import build_agentic_bts_e2e
from build_canonical_agentic_final import build_canonical_agentic_final, build_latent_risk_report
from build_explicit_controller_failure_analysis import analyze_rows as analyze_explicit_controller_failures
from build_explicit_controller_failure_analysis import load_jsonl as load_controller_jsonl
from build_explicit_controller_round_report import build_report as build_explicit_controller_round_report
from run_bts_explicit_controller_eval import run_controller_suite


STATIC_DEFAULT = Path("/workspace/BTS-AgentBench/data/scenario_benchmark_heldoutfix")
E2E_OUT_DEFAULT = Path("/workspace/BTS-AgentBench/data/bts_e2e_heldoutfix_history")
AGENTIC_OUT_DEFAULT = Path("/workspace/BTS-AgentBench/data/bts_e2e_agentic_heldoutfix_history")
CANONICAL_OUT_DEFAULT = Path("/workspace/BTS-AgentBench/data/bts_e2e_agentic_canonical_heldoutfix_history")
CORE_OUT_DEFAULT = Path("/workspace/BTS-AgentBench/data/bts_e2e_agentic_canonical_core_heldoutfix_history")
TOOL_STORE_DB = Path("/workspace/BTS-AgentBench/data/bts/tool_store/tool_store.duckdb")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--static-dir", type=Path, default=STATIC_DEFAULT)
    parser.add_argument("--e2e-out-dir", type=Path, default=E2E_OUT_DEFAULT)
    parser.add_argument("--agentic-out-dir", type=Path, default=AGENTIC_OUT_DEFAULT)
    parser.add_argument("--canonical-out-dir", type=Path, default=CANONICAL_OUT_DEFAULT)
    parser.add_argument("--canonical-core-out-dir", type=Path, default=CORE_OUT_DEFAULT)
    parser.add_argument("--tool-store-db", type=Path, default=TOOL_STORE_DB)
    parser.add_argument("--corpus-name", type=str, default="bts")
    parser.add_argument("--skip-explicit-controller-audit", action="store_true")
    parser.add_argument("--explicit-controller-max-accomplished", type=int, default=0)
    parser.add_argument("--verify-replayability", action="store_true")
    parser.add_argument(
        "--replayability-work-dir",
        type=Path,
        default=Path("/workspace/BTS-AgentBench/data/_replayability_check_bts"),
    )
    return parser.parse_args()


def reset_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[Any]:
    rows: list[Any] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            stripped = line.strip()
            if stripped:
                rows.append(json.loads(stripped))
    return rows


def build_pipeline_once(
    *,
    static_dir: Path,
    e2e_out_dir: Path,
    agentic_out_dir: Path,
    canonical_out_dir: Path,
    canonical_core_out_dir: Path,
    tool_store_db: Path,
    corpus_name: str,
) -> dict[str, Any]:
    reset_dir(e2e_out_dir)
    reset_dir(agentic_out_dir)
    reset_dir(canonical_out_dir)
    reset_dir(canonical_core_out_dir)

    e2e_manifest = build_bts_e2e(static_dir, e2e_out_dir)
    agentic_manifest = build_agentic_bts_e2e(e2e_out_dir, agentic_out_dir)
    canonical_manifest = build_canonical_agentic_final(
        static_dir=static_dir,
        source_dir=agentic_out_dir,
        tool_store_db=tool_store_db,
        out_dir=canonical_out_dir,
        core_out_dir=canonical_core_out_dir,
        corpus_name=corpus_name,
        uniform_reference=None,
        use_default_uniform_reference=False,
    )
    return {
        "e2e": e2e_manifest,
        "agentic": agentic_manifest,
        "canonical": canonical_manifest,
    }


def run_explicit_controller_audit(
    *,
    benchmark_dir: Path,
    tool_store_db: Path,
    max_accomplished: int,
) -> dict[str, Any]:
    witness_dir = benchmark_dir / "explicit_controller_witnesses"
    reset_dir(witness_dir)
    runtime = ToolStoreRuntime(tool_store_db)
    try:
        for split in ("train", "dev", "test"):
            out_dir = witness_dir / split
            suite = run_controller_suite(benchmark_dir, split, runtime, ["phase_complete_stronger_controller"])
            out_dir.mkdir(parents=True, exist_ok=True)
            combined_report = {
                "benchmark_dir": str(benchmark_dir),
                "split": split,
                "controllers": ["phase_complete_stronger_controller"],
                "reports": suite["reports"],
            }
            write_json(out_dir / "explicit_controller_report.json", combined_report)
            for name, rows in suite["rows_by_controller"].items():
                write_jsonl(out_dir / f"{name}.jsonl", rows)
                write_json(out_dir / f"{name}_summary.json", suite["reports"][name])
    finally:
        runtime.close()

    round_report = build_explicit_controller_round_report(witness_dir)
    report_path = benchmark_dir / "explicit_controller_audit_round2_report.json"
    write_json(report_path, round_report)

    accomplished = int(round_report["totals"]["accomplished_count"])
    if accomplished > max_accomplished:
        raise RuntimeError(
            f"explicit_controller_audit_failed: accomplished_count={accomplished} exceeds allowed max {max_accomplished}"
        )
    return {
        "witness_dir": str(witness_dir),
        "report_path": str(report_path),
        "summary": round_report,
    }


def build_explicit_controller_failure_analysis_report(
    *,
    benchmark_dir: Path,
    witness_dir: Path,
) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for split in ("train", "dev", "test"):
        rows.extend(load_controller_jsonl(witness_dir / split / "phase_complete_stronger_controller.jsonl"))
    report = analyze_explicit_controller_failures(rows)
    report_path = benchmark_dir / "explicit_controller_failure_analysis.json"
    write_json(report_path, report)
    return {
        "report_path": str(report_path),
        "summary": report,
    }


def normalize_with_roots(value: Any, roots: list[Path]) -> Any:
    if isinstance(value, dict):
        return {key: normalize_with_roots(item, roots) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_with_roots(item, roots) for item in value]
    if isinstance(value, str):
        normalized = value
        for root in roots:
            root_text = str(root)
            if root_text and root_text in normalized:
                normalized = normalized.replace(root_text, "<RUN_ROOT>")
        return normalized
    return value


def normalized_file_content(path: Path, roots: list[Path]) -> str:
    if path.suffix == ".jsonl":
        rows = load_jsonl(path)
        payload = normalize_with_roots(rows, roots)
        return json.dumps(payload, ensure_ascii=False, sort_keys=True)
    if path.suffix == ".json":
        payload = load_json(path)
        payload = normalize_with_roots(payload, roots)
        return json.dumps(payload, ensure_ascii=False, sort_keys=True)
    return normalize_with_roots(path.read_text(encoding="utf-8"), roots)


def generated_relpaths(root: Path) -> list[Path]:
    return sorted(
        path.relative_to(root)
        for path in root.rglob("*")
        if path.is_file() and path.suffix in {".json", ".jsonl"}
    )


def compare_runs(left_root: Path, right_root: Path, *, normalization_roots: list[Path] | None = None) -> dict[str, Any]:
    left_files = generated_relpaths(left_root)
    right_files = generated_relpaths(right_root)
    roots = normalization_roots or [left_root, right_root]
    mismatches: list[str] = []
    if left_files != right_files:
        left_only = sorted(str(path) for path in set(left_files) - set(right_files))
        right_only = sorted(str(path) for path in set(right_files) - set(left_files))
        mismatches.extend([f"left_only:{path}" for path in left_only])
        mismatches.extend([f"right_only:{path}" for path in right_only])
    shared_files = sorted(set(left_files) & set(right_files))
    for relpath in shared_files:
        left_content = normalized_file_content(left_root / relpath, roots)
        right_content = normalized_file_content(right_root / relpath, roots)
        if left_content != right_content:
            mismatches.append(str(relpath))
    return {
        "left_root": str(left_root),
        "right_root": str(right_root),
        "file_count_left": len(left_files),
        "file_count_right": len(right_files),
        "shared_file_count": len(shared_files),
        "identical": not mismatches,
        "mismatch_count": len(mismatches),
        "mismatches": mismatches[:200],
    }


def verify_replayability(
    *,
    static_dir: Path,
    tool_store_db: Path,
    corpus_name: str,
    work_dir: Path,
    run_explicit_controller: bool,
    explicit_controller_max_accomplished: int,
) -> dict[str, Any]:
    reset_dir(work_dir)
    run_a = work_dir / "run_a"
    run_b = work_dir / "run_b"

    for run_root in (run_a, run_b):
        build_pipeline_once(
            static_dir=static_dir,
            e2e_out_dir=run_root / "e2e",
            agentic_out_dir=run_root / "agentic",
            canonical_out_dir=run_root / "canonical",
            canonical_core_out_dir=run_root / "canonical_core",
            tool_store_db=tool_store_db,
            corpus_name=corpus_name,
        )
        if run_explicit_controller:
            run_explicit_controller_audit(
                benchmark_dir=run_root / "canonical",
                tool_store_db=tool_store_db,
                max_accomplished=explicit_controller_max_accomplished,
            )

    normalization_roots = [run_a, run_b]
    comparisons = {
        "e2e": compare_runs(run_a / "e2e", run_b / "e2e", normalization_roots=normalization_roots),
        "agentic": compare_runs(run_a / "agentic", run_b / "agentic", normalization_roots=normalization_roots),
        "canonical": compare_runs(run_a / "canonical", run_b / "canonical", normalization_roots=normalization_roots),
        "canonical_core": compare_runs(
            run_a / "canonical_core",
            run_b / "canonical_core",
            normalization_roots=normalization_roots,
        ),
    }
    identical = all(section["identical"] for section in comparisons.values())
    return {
        "verification_type": "replayable_deterministic_reconstruction",
        "work_dir": str(work_dir),
        "identical": identical,
        "comparisons": comparisons,
    }


def run_contract_preflight(
    *,
    benchmark_dir: Path,
    tool_store_db: Path,
) -> dict[str, Any]:
    report = audit_contract(benchmark_dir, tool_store_db)
    report_path = benchmark_dir / "contract_preflight_report.json"
    write_json(report_path, report)
    if int(report.get("issue_count", 0)) != 0:
        raise RuntimeError(f"contract_preflight_failed: issue_count={report['issue_count']}")
    return {"report_path": str(report_path), "summary": report}


def update_manifests_with_validation(
    *,
    canonical_out_dir: Path,
    canonical_core_out_dir: Path,
    explicit_controller_result: dict[str, Any] | None,
    explicit_controller_failure_analysis_result: dict[str, Any] | None,
    contract_preflight_result: dict[str, Any] | None,
    latent_risk_result: dict[str, Any] | None,
    replayability_report: dict[str, Any] | None,
) -> None:
    for artifact_dir in (canonical_out_dir, canonical_core_out_dir):
        manifest_path = artifact_dir / "manifest.json"
        if not manifest_path.exists():
            continue
        manifest = load_json(manifest_path)
        if explicit_controller_result is not None:
            manifest["explicit_controller_validation"] = {
                "enabled": True,
                "witness_dir": explicit_controller_result["witness_dir"],
                "report_path": explicit_controller_result["report_path"],
                "accomplished_count": explicit_controller_result["summary"]["totals"]["accomplished_count"],
                "accomplished_rate": explicit_controller_result["summary"]["totals"]["accomplished_rate"],
            }
        if explicit_controller_failure_analysis_result is not None:
            manifest["explicit_controller_failure_analysis"] = explicit_controller_failure_analysis_result["report_path"]
        if contract_preflight_result is not None:
            manifest["contract_preflight"] = {
                "enabled": True,
                "report_path": contract_preflight_result["report_path"],
                "issue_count": contract_preflight_result["summary"]["issue_count"],
            }
        if latent_risk_result is not None:
            manifest["latent_risk_report"] = str(canonical_out_dir / "latent_risk_report.json")
        if replayability_report is not None:
            manifest["replayability_verification"] = {
                "enabled": True,
                "report_path": str(canonical_out_dir / "replayability_verification_report.json"),
                "identical": replayability_report["identical"],
            }
        write_json(manifest_path, manifest)


def main() -> None:
    args = parse_args()

    stage_manifests = build_pipeline_once(
        static_dir=args.static_dir,
        e2e_out_dir=args.e2e_out_dir,
        agentic_out_dir=args.agentic_out_dir,
        canonical_out_dir=args.canonical_out_dir,
        canonical_core_out_dir=args.canonical_core_out_dir,
        tool_store_db=args.tool_store_db,
        corpus_name=args.corpus_name,
    )

    explicit_controller_result = None
    explicit_controller_failure_analysis_result = None
    if not args.skip_explicit_controller_audit:
        explicit_controller_result = run_explicit_controller_audit(
            benchmark_dir=args.canonical_out_dir,
            tool_store_db=args.tool_store_db,
            max_accomplished=args.explicit_controller_max_accomplished,
        )
        explicit_controller_failure_analysis_result = build_explicit_controller_failure_analysis_report(
            benchmark_dir=args.canonical_out_dir,
            witness_dir=args.canonical_out_dir / "explicit_controller_witnesses",
        )

    contract_preflight_result = run_contract_preflight(
        benchmark_dir=args.canonical_out_dir,
        tool_store_db=args.tool_store_db,
    )

    latent_risk_result = {
        "report_path": str(args.canonical_out_dir / "latent_risk_report.json"),
        "summary": build_latent_risk_report(
            load_jsonl(args.canonical_out_dir / "train.jsonl")
            + load_jsonl(args.canonical_out_dir / "dev.jsonl")
            + load_jsonl(args.canonical_out_dir / "test.jsonl"),
            contract_preflight_result["summary"],
            explicit_controller_result["summary"] if explicit_controller_result is not None else None,
        ),
    }
    write_json(args.canonical_out_dir / "latent_risk_report.json", latent_risk_result["summary"])

    replayability_report = None
    if args.verify_replayability:
        replayability_report = verify_replayability(
            static_dir=args.static_dir,
            tool_store_db=args.tool_store_db,
            corpus_name=args.corpus_name,
            work_dir=args.replayability_work_dir,
            run_explicit_controller=not args.skip_explicit_controller_audit,
            explicit_controller_max_accomplished=args.explicit_controller_max_accomplished,
        )
        write_json(args.canonical_out_dir / "replayability_verification_report.json", replayability_report)

    update_manifests_with_validation(
        canonical_out_dir=args.canonical_out_dir,
        canonical_core_out_dir=args.canonical_core_out_dir,
        explicit_controller_result=explicit_controller_result,
        explicit_controller_failure_analysis_result=explicit_controller_failure_analysis_result,
        contract_preflight_result=contract_preflight_result,
        latent_risk_result=latent_risk_result,
        replayability_report=replayability_report,
    )

    pipeline_manifest = {
        "pipeline": "bts_static_to_agentic_with_history",
        "history_recording": True,
        "main_artifact": str(args.canonical_out_dir),
        "auxiliary_core_artifact": str(args.canonical_core_out_dir),
        "static_dir": str(args.static_dir),
        "e2e_out_dir": str(args.e2e_out_dir),
        "agentic_out_dir": str(args.agentic_out_dir),
        "canonical_out_dir": str(args.canonical_out_dir),
        "canonical_core_out_dir": str(args.canonical_core_out_dir),
        "tool_store_db": str(args.tool_store_db),
        "stage_manifests": stage_manifests,
        "post_build_validation": {
            "explicit_controller_audit": explicit_controller_result,
            "explicit_controller_failure_analysis": explicit_controller_failure_analysis_result,
            "contract_preflight": contract_preflight_result,
            "latent_risk_report": latent_risk_result,
            "replayability_verification": replayability_report,
        },
    }
    manifest_path = args.canonical_out_dir / "rebuild_pipeline_manifest.json"
    write_json(manifest_path, pipeline_manifest)
    print(json.dumps(pipeline_manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
