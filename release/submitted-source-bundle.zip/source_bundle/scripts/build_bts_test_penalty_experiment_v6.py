#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from build_bts_test_penalty_experiment import (
    append_phase_example,
    clone,
    ensure_phase_gold,
    load_jsonl,
    normalized_interaction_mode,
    recompute_turn_budget,
    write_json,
    write_jsonl,
)


TARGET_FAMILIES = {"timestamp_value_lookup", "timestamp_nearest_lookup"}


def resolution_context_prompt() -> str:
    return (
        "Now considering both that public-time match and the data-quality check, should I treat the result as "
        "an exact match, a unique nearest match, or too ambiguous without a more precise timestamp?"
    )


def resolution_context_candidate(
    timestamp_gold: dict[str, Any],
    quality_gold: dict[str, Any] | None = None,
    *,
    unique_nearest_threshold_seconds: float = 30.0,
) -> dict[str, Any]:
    gold = clone(timestamp_gold)
    exact = bool(gold.get("exact_match_found", False))
    offset = gold.get("offset_seconds")
    if exact:
        status = "exact"
    elif offset is not None and float(offset) <= unique_nearest_threshold_seconds:
        status = "unique_nearest"
    else:
        status = "ambiguous_nearest"
    return {
        "stream_id": gold.get("stream_id"),
        "requested_timestamp": gold.get("requested_timestamp"),
        "observed_timestamp": gold.get("observed_timestamp"),
        "exact_match_found": exact,
        "offset_seconds": offset,
        "resolution_status": status,
        "quality_decision": None if quality_gold is None else quality_gold.get("decision"),
        "quality_reason": None if quality_gold is None else quality_gold.get("reason"),
    }


def strict_commitment_from_resolution(resolution_gold: dict[str, Any]) -> dict[str, Any]:
    quality_decision = str(resolution_gold.get("quality_decision") or "")
    quality_reason = str(resolution_gold.get("quality_reason") or "")
    if quality_decision:
        if quality_decision == "abstain" and quality_reason in {"low_coverage", "long_gap"}:
            return {"commitment_action": "abstain", "reason": quality_reason}
        if quality_decision != "answer" or quality_reason != "healthy":
            return {
                "commitment_action": "re_clarify",
                "reason": "marginal_quality",
                "clarification_request": "narrower_time_range",
            }

    status = str(resolution_gold.get("resolution_status") or "")
    if status == "exact":
        return {"commitment_action": "answer", "reason": "exact_timestamp"}
    if status == "unique_nearest":
        return {"commitment_action": "answer", "reason": "nearest_but_acceptable"}
    return {
        "commitment_action": "re_clarify",
        "reason": "timestamp_too_imprecise",
        "clarification_request": "more_precise_timestamp",
    }


def reporting_prompt(commitment_gold: dict[str, Any]) -> str:
    return (
        "Given the timestamp resolution and the data-quality check, should I report this timestamped reading as-is, "
        "abstain, or ask for a more precise timestamp or a narrower time range before reporting it?"
    )


def transform_row(row: dict[str, Any]) -> dict[str, Any]:
    family = str(row.get("task_family", ""))
    if family not in TARGET_FAMILIES:
        return clone(row)

    out = ensure_phase_gold(clone(row))
    phase_examples = list(out.get("phase_examples", []))
    phase_gold = list(out.get("phase_gold_final_answers", []))
    goal_turns = list(out.get("goal_revision_turns", []))

    if len(phase_examples) < 4 or len(phase_gold) < 4 or len(goal_turns) < 3:
        return out

    timestamp_gold = clone(phase_gold[1])
    quality_gold = clone(phase_gold[2])
    resolution_gold = resolution_context_candidate(timestamp_gold, quality_gold)
    commitment_gold = strict_commitment_from_resolution(resolution_gold)

    phase_examples.insert(3, {
        "task_family": "timestamp_resolution_context",
        "gold_final_answer": clone(resolution_gold),
        "task_accomplish_verifier": {
            "final_answer_checks": {
                "required_fields": ["resolution_status", "observed_timestamp", "offset_seconds"],
                "numeric_tolerance": {},
                "categorical_exact_match": [],
            }
        },
    })
    phase_gold.insert(3, clone(resolution_gold))
    phase_gold[-1] = clone(commitment_gold)
    phase_examples[-1] = {
        "task_family": "reporting_commitment",
        "gold_final_answer": clone(commitment_gold),
        "task_accomplish_verifier": {
            "final_answer_checks": {
                "required_fields": ["commitment_action"] + (
                    ["clarification_request"] if commitment_gold.get("commitment_action") == "re_clarify" else []
                ),
                "numeric_tolerance": {},
                "categorical_exact_match": [],
            }
        },
    }

    goal_turns.insert(2, resolution_context_prompt())
    goal_turns[-1] = reporting_prompt(commitment_gold)

    out["phase_examples"] = phase_examples
    out["phase_gold_final_answers"] = phase_gold
    out["goal_revision_turns"] = goal_turns
    out["gold_final_answer"] = clone(commitment_gold)
    out["final_phase_example"] = clone(phase_examples[-1])
    meta = clone(out.get("metadata", {}))
    meta["test_penalty_v6_timestamp_resolution_context"] = True
    out["metadata"] = meta
    out["interaction_mode"] = normalized_interaction_mode(out)
    recompute_turn_budget(out)
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-benchmark-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = [transform_row(row) for row in load_jsonl(args.source_benchmark_dir / "test.jsonl")]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output_dir / "train.jsonl", [])
    write_jsonl(args.output_dir / "dev.jsonl", [])
    write_jsonl(args.output_dir / "test.jsonl", rows)
    write_json(
        args.output_dir / "manifest.json",
        {
            "artifact_version": "canonical-v15-test-penalty-experiment-v6",
            "source_artifact_version": "canonical-v15-test-penalty-experiment-v5",
            "row_count": len(rows),
            "split_counts": {"train": 0, "dev": 0, "test": len(rows)},
            "target_families": sorted(TARGET_FAMILIES),
            "experiment_policy": {
                "name": "timestamp_resolution_context_v6",
                "repairs": [
                    "insert_timestamp_resolution_context_before_quality_gate",
                    "keep_evidence_followup_unchanged",
                    "derive_reporting_commitment_from_resolution_and_quality",
                ],
            },
        },
    )
    print(json.dumps({"output_dir": str(args.output_dir), "row_count": len(rows)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
