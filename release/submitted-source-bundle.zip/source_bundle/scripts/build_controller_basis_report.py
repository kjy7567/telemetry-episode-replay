#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


SPLITS = ("train", "dev", "test")


def load_rows(dataset_dir: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for split in SPLITS:
        with (dataset_dir / f"{split}.jsonl").open("r", encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                row["_split"] = split
                rows.append(row)
    return rows


def classify_basis(row: dict[str, Any]) -> str:
    family = row["task_family"]
    if family in {
        "point_disambiguation",
        "day_mean_lookup",
        "relative_24h_mean_lookup",
        "window_mean_lookup",
        "timestamp_value_lookup",
    }:
        return "single_stream_stateful_revision"
    if family == "timestamp_nearest_lookup":
        return "timestamp_fallback_policy"
    if family in {"window_pairwise_compare", "window_rank"}:
        return "pairwise_or_rank_group_reasoning"
    if family == "quality_gate":
        return "quality_decision_branch"
    raise ValueError(f"unclassified_family:{family}")


def build_report(rows: list[dict[str, Any]]) -> dict[str, Any]:
    family_counts = Counter(row["task_family"] for row in rows)
    interaction_mode_counts = Counter(row.get("interaction_mode", "") for row in rows)
    clarification_slot_sets = Counter(tuple(row.get("required_clarification_slots", [])) for row in rows)
    goal_revision_lengths = Counter(len(row.get("goal_revision_turns", [])) for row in rows)
    post_answer_lengths = Counter(len(row.get("post_answer_user_turns", [])) for row in rows)
    skeleton_counts = Counter(tuple(call["tool_name"] for call in row.get("canonical_tool_calls", [])) for row in rows)

    basis_counts = Counter()
    basis_families: dict[str, Counter[str]] = defaultdict(Counter)
    basis_skeletons: dict[str, Counter[str]] = defaultdict(Counter)
    basis_modes: dict[str, Counter[str]] = defaultdict(Counter)
    basis_necessity: dict[str, Counter[str]] = defaultdict(Counter)
    basis_primitives: dict[str, Counter[str]] = defaultdict(Counter)

    for row in rows:
        basis = classify_basis(row)
        basis_counts[basis] += 1
        basis_families[basis][row["task_family"]] += 1
        basis_skeletons[basis][" -> ".join(call["tool_name"] for call in row.get("canonical_tool_calls", []))] += 1
        basis_modes[basis][row.get("interaction_mode", "")] += 1
        for necessity, active in row["agentic_lifting"]["interaction_necessity"].items():
            if active:
                basis_necessity[basis][necessity] += 1
        for primitive in row["agentic_lifting"]["interaction_primitives"]:
            basis_primitives[basis][primitive] += 1

    partition_total = sum(basis_counts.values())
    if partition_total != len(rows):
        raise ValueError(f"basis_partition_mismatch:{partition_total}!={len(rows)}")

    return {
        "report_version": "controller-basis-v2",
        "row_count": len(rows),
        "closed_world_contract_constraints": {
            "read_only_tool_skeleton_count": len(skeleton_counts),
            "canonical_tool_skeletons": { " -> ".join(k): v for k, v in sorted(skeleton_counts.items()) },
            "clarification_slot_universe": sorted({slot for row in rows for slot in row.get("required_clarification_slots", [])}),
            "clarification_slot_set_counts": {str(list(k)): v for k, v in sorted(clarification_slot_sets.items())},
            "max_goal_revision_turns": max(goal_revision_lengths) if goal_revision_lengths else 0,
            "goal_revision_turn_count_distribution": dict(sorted(goal_revision_lengths.items())),
            "max_post_answer_turns": max(post_answer_lengths) if post_answer_lengths else 0,
            "post_answer_turn_count_distribution": dict(sorted(post_answer_lengths.items())),
            "interaction_mode_count": len(interaction_mode_counts),
            "interaction_mode_distribution": dict(sorted(interaction_mode_counts.items())),
        },
        "family_counts": dict(sorted(family_counts.items())),
        "capability_basis_partition": {
            "basis_count": len(basis_counts),
            "basis_row_counts": dict(sorted(basis_counts.items())),
            "basis_family_coverage": {basis: dict(sorted(counter.items())) for basis, counter in sorted(basis_families.items())},
            "basis_skeleton_coverage": {basis: dict(sorted(counter.items())) for basis, counter in sorted(basis_skeletons.items())},
            "basis_interaction_modes": {basis: dict(sorted(counter.items())) for basis, counter in sorted(basis_modes.items())},
            "basis_active_necessity_axes": {basis: dict(sorted(counter.items())) for basis, counter in sorted(basis_necessity.items())},
            "basis_active_primitives": {basis: dict(sorted(counter.items())) for basis, counter in sorted(basis_primitives.items())},
        },
        "controller_basis_argument": {
            "single_stream_stateful_revision": {
                "row_count": basis_counts["single_stream_stateful_revision"],
                "claim": (
                    "Rows in this cluster maintain exactly one active target under a fixed site/context and "
                    "apply one or two bounded same-context revisions before the evidence follow-up."
                ),
                "families": sorted(basis_families["single_stream_stateful_revision"]),
            },
            "timestamp_fallback_policy": {
                "row_count": basis_counts["timestamp_fallback_policy"],
                "claim": (
                    "Rows in this cluster require exact-probe followed by miss-sensitive nearest fallback, "
                    "and may include one additional bounded timestamp revision over the same stream."
                ),
                "families": sorted(basis_families["timestamp_fallback_policy"]),
            },
            "pairwise_or_rank_group_reasoning": {
                "row_count": basis_counts["pairwise_or_rank_group_reasoning"],
                "claim": (
                    "Rows in this cluster maintain either a stream pair or a rankable candidate set and "
                    "reuse that group state across one or two bounded revisions."
                ),
                "families": sorted(basis_families["pairwise_or_rank_group_reasoning"]),
            },
            "quality_decision_branch": {
                "row_count": basis_counts["quality_decision_branch"],
                "claim": (
                    "Rows in this cluster add a quality decision branch over a single resolved stream, may "
                    "include one additional bounded window revision, and require both rationale and evidence closure."
                ),
                "families": sorted(basis_families["quality_decision_branch"]),
            },
        },
        "scope_note": (
            "This report does not claim that four controllers span every possible non-agent method in general. "
            "It claims that, under the current BTS deterministic contract grammar, every row falls into one of "
            "four operational capability clusters or their union."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a controller-basis report for a canonical BTS artifact.")
    parser.add_argument("--dataset-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    dataset_dir = Path(args.dataset_dir)
    rows = load_rows(dataset_dir)
    report = build_report(rows)

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
