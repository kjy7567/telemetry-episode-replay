#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.scenario_benchmark import generate_scenario_benchmark


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--heldout-site-id", action="append", default=[])
    parser.add_argument("--family", action="append", default=[])
    args = parser.parse_args()

    manifest = generate_scenario_benchmark(
        args.tool_store_db,
        args.out_dir,
        heldout_site_ids=args.heldout_site_id or None,
        include_families=args.family or None,
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
