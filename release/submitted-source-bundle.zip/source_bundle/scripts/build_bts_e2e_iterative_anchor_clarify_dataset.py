#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any

from bts_agentbench.bts_e2e import (
    FOLLOWUP_PROMPT,
    RATIONALE_FOLLOWUP_PROMPT,
    TIME_CLARIFICATION_SLOT,
    evidence_followup_prompt,
    load_jsonl,
    month_name,
    normalize_space,
    parse_iso_like_timestamp,
    remove_site_mentions,
    remove_time_mentions,
    render_time_reference,
    time_reference_question,
)
from bts_agentbench.clarify_policy import clarify_policy_manifest_fields
from bts_agentbench.iterative_contract import contract_fields, contract_manifest_fields
from bts_agentbench.operator_answer import render_operator_answer
from bts_agentbench.runtime import ToolStoreRuntime


SYSTEM_PROMPT = """You are a building-operations agent in a multi-turn conversation with an operator.

You may do exactly one of the following at each assistant turn:
1. Ask the operator one short clarification question if the required time reference is missing.
2. Return exactly one compact JSON tool action and nothing else:
   {"tool_name":"...", "arguments":{...}}
3. Answer the operator in concise natural language once you have enough information.

Additional rules:
- Tool results will appear as later user messages prefixed with "Tool result:".
- Do not wrap the final operator answer in JSON.
- When a prior tool result already contains a `stream_id` or `stream_ids`, you may refer to it in later tool calls as `$e1.stream_id` or `$e1.stream_ids` instead of copying long values.
- Use the exact tool schemas below. Do not invent alias argument names such as `date_range_start` or `date_range_end`.
- resolve_point arguments: `site_id`, `point_class`, `equipment_label`, optional `location_label`
- list_points arguments: `site_id`, `point_class`, `location_type`
- aggregate_window arguments: `stream_id`, `metric`, `window_start`, `window_end`, `period`
- compare_window arguments: `left_stream_id`, `right_stream_id`, `metric`, `window_start`, `window_end`, `period`
- rank_window arguments: `stream_ids`, `metric`, `window_start`, `window_end`, `period`, `order`, `topk`
- lookup_observation arguments: `stream_id`, `timestamp`, `mode`
- After `aggregate_window`, answer with the returned `mean_value`.
- After `rank_window`, answer with `ranked_streams[0]` and include the exact winning `stream_id` and its `mean_value` when the operator asks which stream is top.
- After `lookup_observation` with `mode: "exact"`, report the exact returned value. If the tool result says `exact_match_found` is false, say there was no exact logged reading and do not invent a nearby value unless the task explicitly asks for a nearby reading.
- For `timestamp_nearest_lookup`, use `lookup_observation` with `mode: "nearest"` and report the returned nearby timestamp and value.
- If the operator asks which stream or point you used, answer directly in natural language and include the exact stream_id you actually used.
- If the operator asks why you would answer or abstain, explain the quality-based reason directly in natural language.
- If a time reference is missing, ask for the specific missing unit the task needs, such as a date, week, month, time window, or exact timestamp. For timestamp tasks, ask for the exact timestamp including seconds.
- Do not invent stream_ids, timestamps, or values.
"""

TIME_CLARIFY_FAMILIES = {
    "day_mean_lookup",
    "relative_24h_mean_lookup",
    "window_mean_lookup",
    "window_pairwise_compare",
    "window_rank",
    "timestamp_value_lookup",
    "timestamp_nearest_lookup",
}


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def render_time_reference_from_calls(example: dict[str, Any]) -> str:
    family = example["task_family"]
    for call in example.get("canonical_tool_calls", []):
        arguments = call.get("arguments", {})
        if family == "timestamp_value_lookup" and "timestamp" in arguments:
            requested = parse_iso_like_timestamp(arguments["timestamp"])
            return f"I mean {requested.strftime('%H:%M')} UTC on {requested.strftime('%B')} {requested.day}, {requested.year}."
        if family in {"day_mean_lookup", "window_mean_lookup", "window_pairwise_compare", "window_rank", "relative_24h_mean_lookup"} and "window_start" in arguments and "window_end" in arguments:
            start = parse_iso_like_timestamp(arguments["window_start"])
            end = parse_iso_like_timestamp(arguments["window_end"])
            if family == "day_mean_lookup":
                return f"I mean {start.strftime('%B')} {start.day}, {start.year}."
            if family == "relative_24h_mean_lookup":
                return f"Use the 24 hours leading up to {end.strftime('%H:%M')} UTC on {end.strftime('%B')} {end.day}, {end.year}."
            if family in {"window_mean_lookup", "window_pairwise_compare"}:
                return f"I mean the week beginning {start.strftime('%B')} {start.day}, {start.year}."
            if family == "window_rank":
                return f"I mean {month_name(start.month)} {start.year}."
    return "Please use the exact time reference from my original request."


def clarify_spec(example: dict[str, Any]) -> dict[str, str] | None:
    hidden = example["hidden_user_instruction"]
    family = example["task_family"]
    if family in TIME_CLARIFY_FAMILIES:
        initial = remove_time_mentions(hidden, family)
        if normalize_space(initial) != normalize_space(hidden):
            return {
                "slot": TIME_CLARIFICATION_SLOT,
                "interaction_mode": "clarify_time_then_followups",
                "initial_user_message": initial,
                "question": time_reference_question(example),
                "answer": render_time_reference(example)
                if family in {"day_mean_lookup", "relative_24h_mean_lookup", "window_mean_lookup", "window_rank", "timestamp_value_lookup", "timestamp_nearest_lookup"}
                else render_time_reference_from_calls(example),
            }
    return None


def evidence_answer(example: dict[str, Any], runtime: ToolStoreRuntime) -> str:
    stream_ids = example.get("evidence", {}).get("stream_ids", [])
    if not stream_ids:
        return "I did not use a specific stream."
    descriptions = []
    for stream_id in stream_ids:
        description = runtime.describe_stream(stream_id)
        equipment = description.get("equipment_label")
        location = description.get("location_label")
        if equipment and location:
            descriptions.append(f"stream {stream_id} for {equipment} serving {location}")
        elif equipment:
            descriptions.append(f"stream {stream_id} for {equipment}")
        elif location:
            descriptions.append(f"stream {stream_id} for the point serving {location}")
        else:
            descriptions.append(f"stream {stream_id}")
    if len(descriptions) == 1:
        return f"I used {descriptions[0]}."
    return "I used " + "; ".join(descriptions) + "."


def quality_rationale_answer(example: dict[str, Any]) -> str:
    gold = example["gold_final_answer"]
    if gold["decision"] == "abstain":
        return (
            f"I would abstain because the signal quality is not reliable enough. "
            f"Observed coverage was {gold['observed_fraction']} and the gap ratio was {gold['gap_ratio']}."
        )
    return (
        f"I would answer because the signal looks healthy enough. "
        f"Observed coverage was {gold['observed_fraction']} and the gap ratio was {gold['gap_ratio']}."
    )


def reference_candidates(executed_calls: list[Any]) -> list[tuple[Any, str]]:
    refs: list[tuple[Any, str]] = []
    for call in executed_calls:
        for field in ("stream_id", "stream_ids"):
            if field in call.output:
                refs.append((call.output[field], f"${call.call_id}.{field}"))
    return refs


def compactify_arguments(arguments: dict[str, Any], executed_calls: list[Any]) -> dict[str, Any]:
    refs = reference_candidates(executed_calls)

    def replace(value: Any) -> Any:
        for candidate, ref in refs:
            if value == candidate:
                return ref
        if isinstance(value, list):
            return [replace(v) for v in value]
        if isinstance(value, dict):
            return {k: replace(v) for k, v in value.items()}
        return value

    return replace(arguments)


def base_record(
    example: dict[str, Any],
    stage: str,
    step_index: int,
    history: list[dict[str, str]],
    spec: dict[str, str],
) -> dict[str, Any]:
    available_tools = sorted({call["tool_name"] for call in example.get("canonical_tool_calls", [])})
    return {
        "scenario_id": example["scenario_id"],
        "split": example["split"],
        "task_family": example["task_family"],
        "site_id": example["site_id"],
        "track": "bts_e2e",
        "source": "anchor_time_clarify_extension",
        "stage": stage,
        "step_index": step_index,
        "interaction_mode": spec["interaction_mode"],
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}] + history,
        "query": spec["initial_user_message"],
        "metadata": {
            "available_tools": available_tools,
            "hidden_user_instruction": example["hidden_user_instruction"],
            "clarification_slot": spec["slot"],
        },
        **contract_fields(stage),
    }


def build_rows_for_example(example: dict[str, Any], runtime: ToolStoreRuntime) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    spec = clarify_spec(example)
    if spec is None:
        return rows
    history: list[dict[str, str]] = [{"role": "user", "content": spec["initial_user_message"]}]
    step_index = 1

    rows.append(
        base_record(
            example,
            "clarification_question",
            step_index,
            history + [{"role": "assistant", "content": spec["question"]}],
            spec,
        )
    )
    history.extend(
        [
            {"role": "assistant", "content": spec["question"]},
            {"role": "user", "content": spec["answer"]},
        ]
    )
    step_index += 1

    executed = runtime.execute_call_sequence(example["canonical_tool_calls"])
    compact_history: list[Any] = []
    for idx, call in enumerate(executed, start=1):
        call = call.__class__(
            call_id=f"e{idx}",
            tool_name=call.tool_name,
            arguments=call.arguments,
            output=call.output,
        )
        compact_arguments = compactify_arguments(call.arguments, compact_history)
        tool_payload = json.dumps(
            {"tool_name": call.tool_name, "arguments": compact_arguments},
            ensure_ascii=False,
        )
        rows.append(
            base_record(
                example,
                "tool_call",
                step_index,
                history + [{"role": "assistant", "content": tool_payload}],
                spec,
            )
        )
        history.extend(
            [
                {"role": "assistant", "content": tool_payload},
                {"role": "user", "content": f"Tool result: {ToolStoreRuntime.compact_observation(call)}"},
            ]
        )
        compact_history.append(call)
        step_index += 1

    final_answer = render_operator_answer(example, example["gold_final_answer"], runtime)
    rows.append(base_record(example, "final_answer", step_index, history + [{"role": "assistant", "content": final_answer}], spec))
    history.append({"role": "assistant", "content": final_answer})
    step_index += 1

    default_followup = example.get("followup_prompt", evidence_followup_prompt(example))
    for prompt in example.get("post_answer_user_turns", [default_followup]):
        history.append({"role": "user", "content": prompt})
        if prompt == default_followup:
            answer = evidence_answer(example, runtime)
            stage = "evidence_followup_answer"
        elif prompt == RATIONALE_FOLLOWUP_PROMPT:
            answer = quality_rationale_answer(example)
            stage = "rationale_followup_answer"
        else:
            answer = "I used the observed tool outputs to answer that."
            stage = "followup_answer"
        rows.append(base_record(example, stage, step_index, history + [{"role": "assistant", "content": answer}], spec))
        history.append({"role": "assistant", "content": answer})
        step_index += 1

    return rows


def build_split_rows(split_path: Path, runtime: ToolStoreRuntime) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for example in load_jsonl(split_path):
        rows.extend(build_rows_for_example(example, runtime))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    runtime = ToolStoreRuntime(args.tool_store_db)
    try:
        train_rows = build_split_rows(args.benchmark_dir / "train.jsonl", runtime)
        dev_rows = build_split_rows(args.benchmark_dir / "dev.jsonl", runtime)
    finally:
        runtime.close()

    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)
    stage_counts_train = dict(Counter(row["stage"] for row in train_rows))
    interaction_modes_train = dict(Counter(row["interaction_mode"] for row in train_rows))
    manifest = {
        "track": "bts_e2e",
        "source": "iterative_anchor_time_clarify_extension",
        "train_examples": len(train_rows),
        "dev_examples": len(dev_rows),
        "stage_counts_train": stage_counts_train,
        "interaction_modes_train": interaction_modes_train,
        "benchmark_dir": str(args.benchmark_dir),
        "tool_store_db": str(args.tool_store_db),
        **contract_manifest_fields(stage_counts_train),
        **clarify_policy_manifest_fields(
            clarify_count=stage_counts_train.get("clarification_question", 0),
            clarify_scope="serialized_bts_hidden_state",
        ),
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
