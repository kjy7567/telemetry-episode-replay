#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from statistics import mean
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = REPO_ROOT.parent
SRC_ROOT = REPO_ROOT / "src"
TOOLSANDBOX_ROOT = WORKSPACE_ROOT / "external" / "ToolSandbox"
SCRIPTS_ROOT = REPO_ROOT / "scripts"
for path in (SRC_ROOT, TOOLSANDBOX_ROOT, SCRIPTS_ROOT):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from run_local_agent_eval import LocalChatModel, extract_json_payload
from tool_sandbox.common.execution_context import DatabaseNamespace, get_current_context
from tool_sandbox.common.message_conversion import Message
from tool_sandbox.common.tool_discovery import ToolBackend
from tool_sandbox.roles.base_role import BaseRole
from tool_sandbox.roles.execution_environment import ExecutionEnvironment
from tool_sandbox.roles.openai_api_agent import OpenAIAPIAgent
from tool_sandbox.scenarios.insufficient_information_scenarios import named_insufficient_information_scenarios
from tool_sandbox.scenarios.single_tool_call_scenarios import named_single_tool_call_scenarios


SYSTEM_PROMPT = """You are a mobile assistant agent in an interactive tool-using task.

At each assistant turn, do exactly one of the following:
1. Return exactly one compact JSON tool action and nothing else:
   {"tool_name":"...", "arguments":{...}}
2. Answer the user in concise natural language when you have enough information.

Rules:
- Use only the allowed tools.
- Do not wrap the final answer in JSON.
- Do not invent phone numbers, reminder ids, names, or settings values.
"""


def exact_trace_scenarios() -> dict[str, Any]:
    scenarios: dict[str, Any] = {}
    scenarios.update(named_single_tool_call_scenarios(preferred_tool_backend=ToolBackend.DEFAULT))
    scenarios.update(named_insufficient_information_scenarios(preferred_tool_backend=ToolBackend.DEFAULT))
    selected: dict[str, Any] = {}
    for name, scenario in scenarios.items():
        keep = False
        for milestone in scenario.evaluation.milestone_matcher.milestones:
            for constraint in milestone.snapshot_constraints:
                if (
                    constraint.database_namespace == DatabaseNamespace.SANDBOX
                    and constraint.target_dataframe is not None
                    and "tool_trace" in constraint.target_dataframe.columns
                ):
                    keep = True
        if keep:
            selected[name] = scenario
    return dict(sorted(selected.items()))


def selected_scenarios(manifest_json: Path | None, split: str, max_scenarios: int) -> list[tuple[str, Any]]:
    scenarios = exact_trace_scenarios()
    if manifest_json is None:
        items = list(scenarios.items())
        if split != "all":
            raise ValueError("split-specific ToolSandbox evaluation requires --manifest-json")
        return items[:max_scenarios]

    manifest = json.loads(manifest_json.read_text(encoding="utf-8"))
    if split == "train":
        names = manifest.get("train_scenarios", [])
    elif split == "dev":
        names = manifest.get("dev_scenarios", [])
    else:
        names = manifest.get("train_scenarios", []) + manifest.get("dev_scenarios", [])
    filtered = [(name, scenarios[name]) for name in names if name in scenarios]
    return filtered[:max_scenarios]


def tool_python_call(tool_name: str, arguments: dict[str, Any]) -> str:
    args_text = json.dumps(arguments, ensure_ascii=False)
    return (
        f"tool_parameters = {args_text}\n"
        f"tool_response = {tool_name}(**tool_parameters)\n"
        f"print(repr(tool_response))"
    )


class DeterministicEndUser(BaseRole):
    role_type = "USER"

    def respond(self, ending_index: int | None = None) -> None:
        messages = self.get_messages(ending_index=ending_index)
        self.messages_validation(messages)
        messages = self.filter_messages(messages)
        if messages[-1].sender == "SYSTEM":
            return
        self.add_messages(
            [
                Message(
                    sender="USER",
                    recipient="EXECUTION_ENVIRONMENT",
                    content="end_conversation()",
                )
            ]
        )


class LocalToolSandboxAgent(BaseRole):
    role_type = "AGENT"

    def __init__(self, model_id: str):
        self.model = LocalChatModel(model_id)
        self.tool_call_index = 0

    def _messages_for_model(self, ending_index: int | None = None) -> list[dict[str, str]]:
        messages = self.get_messages(ending_index=ending_index)
        self.messages_validation(messages)
        messages = self.filter_messages(messages)
        available_tools = sorted(self.get_available_tools().keys())
        prompt_messages: list[dict[str, str]] = [
            {"role": "system", "content": SYSTEM_PROMPT + f"\nAllowed tools: {', '.join(available_tools)}"}
        ]
        for message in messages:
            if message.sender == "SYSTEM" and message.recipient == "AGENT":
                prompt_messages.append({"role": "system", "content": message.content})
            elif message.sender == "USER" and message.recipient == "AGENT":
                prompt_messages.append({"role": "user", "content": message.content})
            elif message.sender == "EXECUTION_ENVIRONMENT" and message.recipient == "AGENT":
                prompt_messages.append({"role": "user", "content": f"Tool result: {message.content}"})
            elif message.sender == "AGENT" and message.recipient == "USER":
                prompt_messages.append({"role": "assistant", "content": message.content})
        return prompt_messages

    def respond(self, ending_index: int | None = None) -> None:
        prompt_messages = self._messages_for_model(ending_index=ending_index)
        text = self.model.generate(prompt_messages)
        try:
            payload = extract_json_payload(text)
        except Exception:
            payload = None

        current_context = get_current_context()
        available_tool_names = set(self.get_available_tools().keys())
        if isinstance(payload, dict) and payload.get("tool_name") in available_tool_names:
            tool_name = payload["tool_name"]
            execution_name = current_context.get_execution_facing_tool_name(tool_name)
            content = tool_python_call(execution_name, payload.get("arguments", {}))
            self.tool_call_index += 1
            message = Message(
                sender="AGENT",
                recipient="EXECUTION_ENVIRONMENT",
                content=content,
                openai_tool_call_id=f"local_tool_call_{self.tool_call_index}",
                openai_function_name=tool_name,
            )
        else:
            message = Message(
                sender="AGENT",
                recipient="USER",
                content=text.strip(),
            )
        self.add_messages([message])

    def reset(self) -> None:
        self.tool_call_index = 0


def summarize(results: list[dict[str, Any]]) -> dict[str, Any]:
    similarities = [row["similarity"] for row in results]
    accomplished = sum(1 for value in similarities if value >= 0.999)
    return {
        "scenario_count": len(results),
        "accomplished": accomplished,
        "mean_similarity": mean(similarities) if similarities else 0.0,
        "mean_turn_count": mean(row["turn_count"] for row in results) if results else 0.0,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--manifest-json", type=Path, default=None)
    parser.add_argument("--split", type=str, choices=["train", "dev", "all"], default="all")
    parser.add_argument("--max-scenarios", type=int, default=13)
    args = parser.parse_args()

    scenarios = selected_scenarios(args.manifest_json, args.split, args.max_scenarios)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    roles = {
        "AGENT": LocalToolSandboxAgent(args.model),
        "USER": DeterministicEndUser(),
        "EXECUTION_ENVIRONMENT": ExecutionEnvironment(),
    }

    results: list[dict[str, Any]] = []
    for name, scenario in scenarios:
        result = scenario.play_and_evaluate(
            roles=roles,
            output_directory=args.out_dir,
            scenario_name=name,
        )
        evaluation = result.evaluation_result
        results.append(
            {
                "scenario_name": name,
                "similarity": evaluation.similarity,
                "milestone_similarity": evaluation.milestone_similarity,
                "minefield_similarity": evaluation.minefield_similarity,
                "turn_count": evaluation.turn_count,
            }
        )
        for role in roles.values():
            role.reset()

    jsonl_path = args.out_dir / "results.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as handle:
        for row in results:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    summary = summarize(results)
    summary.update(
        {
            "model": args.model,
            "split": args.split,
            "manifest_json": str(args.manifest_json) if args.manifest_json is not None else None,
            "scenario_names": [name for name, _ in scenarios],
            "jsonl_path": str(jsonl_path),
        }
    )
    (args.out_dir / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
