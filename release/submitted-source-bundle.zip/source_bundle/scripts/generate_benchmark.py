#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.generator import generate_benchmark


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--per-family", type=int, default=60)
    args = parser.parse_args()

    manifest = generate_benchmark(args.catalog_dir, args.out_dir, per_family=args.per_family)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
