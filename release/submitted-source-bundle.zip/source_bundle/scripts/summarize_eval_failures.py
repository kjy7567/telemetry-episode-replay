#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def normalize_issue(issue: str) -> str:
    if issue.startswith("missing_tool:"):
        return "missing_tool"
    if issue.startswith("missing_final_field:"):
        return "missing_final_field"
    if issue.startswith("missing_evidence:"):
        return "missing_evidence"
    if issue.startswith("numeric_mismatch:"):
        return "numeric_mismatch"
    if issue.startswith("categorical_mismatch:"):
        return "categorical_mismatch"
    if issue.startswith("value_mismatch:"):
        return "value_mismatch"
    if issue.startswith("tool_execution_error:"):
        return "tool_execution_error"
    if issue.startswith("json_parse_error:"):
        return "json_parse_error"
    return issue


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-jsonl", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    args = parser.parse_args()

    rows = load_jsonl(args.results_jsonl)
    label_counts = Counter()
    issue_counts = Counter()
    issue_by_family: dict[str, Counter[str]] = defaultdict(Counter)
    issue_by_label: dict[str, Counter[str]] = defaultdict(Counter)

    for row in rows:
        verification = row["verification"]
        label = verification["label"]
        family = row["task_family"]
        label_counts[label] += 1
        for issue in verification.get("issues", []):
            key = normalize_issue(issue)
            issue_counts[key] += 1
            issue_by_family[family][key] += 1
            issue_by_label[label][key] += 1

    report = {
        "scenario_count": len(rows),
        "label_counts": dict(label_counts),
        "issue_counts": dict(issue_counts),
        "issue_by_family": {k: dict(v) for k, v in sorted(issue_by_family.items())},
        "issue_by_label": {k: dict(v) for k, v in sorted(issue_by_label.items())},
    }
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
