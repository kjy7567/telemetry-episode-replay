#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import mean
from typing import Any

from bts_agentbench.evaluator import verify_prediction
from bts_agentbench.runtime import ExecutedCall, ToolStoreRuntime


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def benchmark_index(benchmark_dir: Path) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for split in ["train", "dev", "test"]:
        for row in load_jsonl(benchmark_dir / f"{split}.jsonl"):
            rows[row["scenario_id"]] = row
    return rows


def to_executed_calls(raw_calls: list[dict[str, Any]]) -> list[ExecutedCall]:
    calls: list[ExecutedCall] = []
    for idx, raw in enumerate(raw_calls, start=1):
        calls.append(
            ExecutedCall(
                call_id=raw.get("call_id", f"m{idx}"),
                tool_name=raw["tool_name"],
                arguments=raw["arguments"],
                output=raw.get("output", {}),
            )
        )
    return calls


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    label_counts: dict[str, int] = {}
    for row in rows:
        label = row["verification"]["label"]
        label_counts[label] = label_counts.get(label, 0) + 1
    return {
        "scenario_count": len(rows),
        "label_counts": label_counts,
        "mean_process_score": round(mean(row["verification"]["process_score"] for row in rows), 4) if rows else 0.0,
        "mean_final_score": round(mean(row["verification"]["final_score"] for row in rows), 4) if rows else 0.0,
        "mean_evidence_score": round(mean(row["verification"]["evidence_score"] for row in rows), 4) if rows else 0.0,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--predictions-jsonl", type=Path, required=True)
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-summary", type=Path, required=True)
    args = parser.parse_args()

    gold = benchmark_index(args.benchmark_dir)
    predictions = load_jsonl(args.predictions_jsonl)
    runtime = ToolStoreRuntime(args.tool_store_db)

    scored_rows: list[dict[str, Any]] = []
    for row in predictions:
        example = gold[row["scenario_id"]]
        executed_calls = to_executed_calls(row.get("executed_calls", []))
        verification = verify_prediction(
            example,
            executed_calls,
            row.get("final_answer"),
            row.get("evidence"),
            runtime,
        )
        scored_rows.append(
            {
                "scenario_id": row["scenario_id"],
                "task_family": example["task_family"],
                "site_id": example["site_id"],
                "query": example["query"],
                "executed_calls": [call.as_dict() for call in executed_calls],
                "final_answer": row.get("final_answer"),
                "evidence": row.get("evidence"),
                "verification": verification.as_dict(),
            }
        )

    runtime.close()
    summary = summarize(scored_rows)

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.out_jsonl.open("w", encoding="utf-8") as handle:
        for row in scored_rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    args.out_summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
