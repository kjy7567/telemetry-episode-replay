#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def load_summary(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def build_row(path: Path) -> dict[str, Any]:
    summary = load_summary(path)
    counts = summary.get("counts", {})
    scenario_count = int(summary.get("scenario_count", 0))
    accomplished = int(counts.get("accomplished", 0))
    partially_accomplished = int(counts.get("partially_accomplished", 0))
    not_accomplished = int(counts.get("not_accomplished", 0))
    accomplished_rate = (accomplished / scenario_count) if scenario_count else 0.0
    return {
        "summary_path": str(path),
        "model": summary.get("model"),
        "split": summary.get("split"),
        "scenario_count": scenario_count,
        "accomplished": accomplished,
        "partially_accomplished": partially_accomplished,
        "not_accomplished": not_accomplished,
        "accomplished_rate": round(accomplished_rate, 4),
        "mean_process_score": summary.get("mean_process_score", 0.0),
        "mean_final_score": summary.get("mean_final_score", 0.0),
        "mean_evidence_score": summary.get("mean_evidence_score", 0.0),
        "interaction_issue_counts": summary.get("interaction_issue_counts", {}),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary", type=Path, action="append", required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    args = parser.parse_args()

    rows = [build_row(path) for path in args.summary]
    rows.sort(
        key=lambda row: (
            row["accomplished_rate"],
            row["mean_final_score"],
            row["mean_process_score"],
            row["mean_evidence_score"],
        ),
        reverse=True,
    )

    out = {
        "ranking_metric": [
            "accomplished_rate",
            "mean_final_score",
            "mean_process_score",
            "mean_evidence_score",
        ],
        "rows": rows,
    }
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
