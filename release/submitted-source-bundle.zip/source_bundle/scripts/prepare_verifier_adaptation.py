#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.runtime import ToolStoreRuntime


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def benchmark_index(benchmark_dir: Path) -> dict[str, dict]:
    index = {}
    for split in ["train", "dev", "test"]:
        for row in load_jsonl(benchmark_dir / f"{split}.jsonl"):
            index[row["scenario_id"]] = row
    return index


def _freeze(value):
    if isinstance(value, list):
        return tuple(_freeze(v) for v in value)
    if isinstance(value, dict):
        return tuple(sorted((k, _freeze(v)) for k, v in value.items()))
    return value


def _normalize_call(call: dict) -> tuple:
    return call["tool_name"], tuple(sorted((key, _freeze(value)) for key, value in call["arguments"].items()))


def _best_gold_variant(gold: dict, runtime: ToolStoreRuntime) -> list[dict]:
    best_variant = gold["acceptable_tool_call_sets"][0]
    best_len = -1
    for variant in gold["acceptable_tool_call_sets"]:
        executed = runtime.execute_call_sequence(variant)
        concrete = [
            {
                "call_id": call.call_id,
                "tool_name": call.tool_name,
                "arguments": call.arguments,
            }
            for call in executed
        ]
        if len(concrete) > best_len:
            best_variant = concrete
            best_len = len(concrete)
    return best_variant


def _matching_prefix(predicted_calls: list[dict], gold_calls: list[dict]) -> int:
    matched = 0
    for pred, gold in zip(predicted_calls, gold_calls):
        if _normalize_call(pred) != _normalize_call(gold):
            break
        matched += 1
    return matched


def weight_from_verification(verification: dict) -> float:
    if verification["label"] == "accomplished":
        return 1.0
    if verification["label"] == "partially_accomplished":
        return round(
            0.25
            + 0.35 * verification["process_score"]
            + 0.25 * verification["final_score"]
            + 0.15 * verification["evidence_score"],
            4,
        )
    return round(0.05 + 0.25 * verification["process_score"], 4)


def convert_rollout(rollout: dict, gold: dict, teacher_model: str, runtime: ToolStoreRuntime) -> dict:
    verification = rollout["verification"]
    gold_variant = _best_gold_variant(gold, runtime)
    if verification["label"] == "accomplished":
        target = {
            "tool_calls": rollout["executed_calls"],
            "final_answer": rollout["final_answer"],
            "evidence": rollout.get("evidence", {}),
        }
        adaptation_mode = "retain_teacher"
    else:
        prefix_len = _matching_prefix(rollout["executed_calls"], gold_variant)
        repaired_calls = rollout["executed_calls"][:prefix_len] + gold_variant[prefix_len:]
        target = {
            "tool_calls": repaired_calls,
            "final_answer": gold["gold_final_answer"],
            "evidence": gold["evidence"],
        }
        adaptation_mode = "prefix_repair_with_gold" if prefix_len > 0 else "repair_with_gold"

    return {
        "scenario_id": rollout["scenario_id"],
        "teacher_model": teacher_model,
        "task_family": gold["task_family"],
        "site_id": gold["site_id"],
        "query": gold["query"],
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are a building-operations agent. Return JSON with keys "
                    "'tool_calls', 'final_answer', and 'evidence'."
                ),
            },
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "query": gold["query"],
                        "task_family": gold["task_family"],
                        "site_id": gold["site_id"],
                    },
                    ensure_ascii=False,
                ),
            },
            {"role": "assistant", "content": json.dumps(target, ensure_ascii=False)},
        ],
        "teacher_rollout": {
            "executed_calls": rollout["executed_calls"],
            "final_answer": rollout["final_answer"],
            "evidence": rollout.get("evidence", {}),
            "raw_model_responses": rollout.get("raw_model_responses", []),
        },
        "gold_reference": {
            "canonical_tool_calls": gold_variant,
            "gold_final_answer": gold["gold_final_answer"],
            "evidence": gold["evidence"],
        },
        "verification": verification,
        "adaptation_mode": adaptation_mode,
        "adaptation_weight": weight_from_verification(verification),
        "matching_prefix_length": _matching_prefix(rollout["executed_calls"], gold_variant),
    }


def summarize(rows: list[dict]) -> dict:
    mode_counts: dict[str, int] = {}
    for row in rows:
        mode = row["adaptation_mode"]
        mode_counts[mode] = mode_counts.get(mode, 0) + 1
    return {
        "example_count": len(rows),
        "adaptation_mode_counts": mode_counts,
        "mean_adaptation_weight": round(sum(row["adaptation_weight"] for row in rows) / len(rows), 4) if rows else 0.0,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--rollouts-jsonl", type=Path, required=True)
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-summary", type=Path, required=True)
    parser.add_argument("--teacher-model", required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    args = parser.parse_args()

    gold = benchmark_index(args.benchmark_dir)
    rollouts = load_jsonl(args.rollouts_jsonl)
    runtime = ToolStoreRuntime(args.tool_store_db)
    rows = [convert_rollout(rollout, gold[rollout["scenario_id"]], args.teacher_model, runtime) for rollout in rollouts]
    runtime.close()
    summary = summarize(rows)
    summary["teacher_model"] = args.teacher_model

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.out_jsonl.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    args.out_summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
