#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def make_closure_variant(row: dict[str, Any], closure_weight: float) -> dict[str, Any]:
    variant = json.loads(json.dumps(row))
    variant["source"] = "closure_aux"
    variant["sample_weight"] = closure_weight
    user_message = variant["messages"][-2]["content"]
    variant["messages"][-2]["content"] = (
        user_message
        + "\nNow answer the operator directly using only the observed tool results above."
    )
    return variant


def convert_rows(rows: list[dict[str, Any]], closure_weight: float) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in rows:
        base = json.loads(json.dumps(row))
        base["sample_weight"] = 1.0
        out.append(base)
        if row.get("stage") == "final_answer":
            out.append(make_closure_variant(row, closure_weight=closure_weight))
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-jsonl", type=Path, required=True)
    parser.add_argument("--dev-jsonl", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--closure-weight", type=float, default=2.0)
    args = parser.parse_args()

    train_rows = convert_rows(load_jsonl(args.train_jsonl), closure_weight=args.closure_weight)
    dev_rows = convert_rows(load_jsonl(args.dev_jsonl), closure_weight=args.closure_weight)

    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)

    summary = {
        "input_train_jsonl": str(args.train_jsonl),
        "input_dev_jsonl": str(args.dev_jsonl),
        "closure_weight": args.closure_weight,
        "train_rows": len(train_rows),
        "dev_rows": len(dev_rows),
        "train_closure_aux_rows": sum(1 for row in train_rows if row.get("source") == "closure_aux"),
        "dev_closure_aux_rows": sum(1 for row in dev_rows if row.get("source") == "closure_aux"),
        "train_mean_weight": round(sum(float(row.get("sample_weight", 1.0)) for row in train_rows) / len(train_rows), 6) if train_rows else 0.0,
        "dev_mean_weight": round(sum(float(row.get("sample_weight", 1.0)) for row in dev_rows) / len(dev_rows), 6) if dev_rows else 0.0,
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
