#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from zipfile import BadZipFile, ZipFile

import requests


FILES = {
    "meta": {
        "Site_A_metadata.csv": {"url": "https://ndownloader.figshare.com/files/53352143", "size": 1523881},
        "Site_B_metadata.csv": {"url": "https://ndownloader.figshare.com/files/53352146", "size": 136315},
        "Site_C_metadata.csv": {"url": "https://ndownloader.figshare.com/files/53352149", "size": 1492713},
        "Site_A.ttl": {"url": "https://ndownloader.figshare.com/files/53352152", "size": 3559525},
        "Site_B.ttl": {"url": "https://ndownloader.figshare.com/files/53352155", "size": 378775},
        "Site_C.ttl": {"url": "https://ndownloader.figshare.com/files/53352158", "size": 4835746},
        "Brick_v1.2.1.ttl": {"url": "https://ndownloader.figshare.com/files/53352173", "size": 707352},
    },
    "raw": {
        "Site_Aaa.zip": {"url": "https://ndownloader.figshare.com/files/53366168", "size": 8482784978},
        "Site_Baa.zip": {"url": "https://ndownloader.figshare.com/files/53354039", "size": 1510328054},
        "Site_Caa.zip": {"url": "https://ndownloader.figshare.com/files/53386793", "size": 8977683868},
    },
}


def download_file(url: str, destination: Path, expected_size: int | None = None, retries: int = 5) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if expected_size and destination.exists() and destination.stat().st_size == expected_size:
        print(f"Skipping {destination.name}: already complete ({expected_size} bytes)")
        return

    tmp = destination.with_suffix(destination.suffix + ".part")
    if tmp.exists():
        tmp.unlink()

    for attempt in range(1, retries + 1):
        try:
            print(f"Downloading {destination.name} (attempt {attempt}/{retries})")
            with requests.get(url, stream=True, timeout=(30, 300)) as response:
                response.raise_for_status()
                server_size = response.headers.get("Content-Length")
                server_size = int(server_size) if server_size and server_size.isdigit() else None
                effective_size = server_size or expected_size
                downloaded = 0
                next_report = 100 * 1024 * 1024
                with tmp.open("wb") as handle:
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        if not chunk:
                            continue
                        handle.write(chunk)
                        downloaded += len(chunk)
                        if downloaded >= next_report:
                            print(f"  {destination.name}: {downloaded} bytes", flush=True)
                            next_report += 100 * 1024 * 1024
            final_size = tmp.stat().st_size
            if effective_size and final_size != effective_size:
                raise RuntimeError(
                    f"Size mismatch for {destination.name}: expected {effective_size}, got {final_size}"
                )
            if destination.suffix == ".zip":
                try:
                    with ZipFile(tmp) as archive:
                        archive.testzip()
                except BadZipFile as exc:
                    raise RuntimeError(f"Invalid ZIP archive for {destination.name}") from exc
            tmp.replace(destination)
            print(f"Completed {destination.name}: {destination.stat().st_size} bytes")
            return
        except Exception as exc:
            print(f"Download failed for {destination.name}: {exc}", file=sys.stderr)
            if attempt == retries:
                raise
            time.sleep(min(30, attempt * 5))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True, help="Root BTS data directory.")
    parser.add_argument("--metadata-only", action="store_true")
    parser.add_argument(
        "--raw-files",
        nargs="*",
        default=None,
        help="Optional subset of raw archive names, e.g. Site_Baa.zip",
    )
    args = parser.parse_args()

    for name, entry in FILES["meta"].items():
        print(f"Downloading metadata: {name}")
        download_file(entry["url"], args.root / "meta" / name, expected_size=entry["size"])

    if not args.metadata_only:
        raw_names = args.raw_files or list(FILES["raw"].keys())
        for name in raw_names:
            entry = FILES["raw"][name]
            print(f"Downloading raw archive: {name}")
            download_file(entry["url"], args.root / "raw" / name, expected_size=entry["size"])


if __name__ == "__main__":
    main()
