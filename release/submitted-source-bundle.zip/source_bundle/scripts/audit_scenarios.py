#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path

import duckdb
import pandas as pd

from bts_agentbench.raw import extract_stream_history


AGGREGATION_COMPATIBILITY_REGEX = re.compile(
    r"^(?!Time_)(?!Duration_Sensor$)(?!.*_Energy_Sensor$)(?!Chilled_Water_Supply_Flow_Sensor$)"
    r"(?!.*_Parameter$).*(?:_Sensor|_Setpoint|_Limit)$"
)
TIMESTAMP_COMPATIBILITY_REGEX = re.compile(r"^(?!.*_Parameter$).*(?:_Sensor|_Setpoint|_Limit)$")
QUALITY_COMPATIBILITY_REGEX = re.compile(
    r"^(?!Time_)(?!Duration_Sensor$)(?!.*_Energy_Sensor$)(?!.*_Parameter$)"
    r"(?!Min_Limit$)(?!Max_Limit$).*(?:_Sensor|_Setpoint|_Limit)$"
)


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def scenario_rows(scenario_dir: Path) -> list[dict]:
    rows = []
    for split in ["train", "dev", "test"]:
        rows.extend(load_jsonl(scenario_dir / f"{split}.jsonl"))
    return rows


def one(con: duckdb.DuckDBPyConnection, query: str, params: tuple):
    return con.execute(query, params).fetchone()


def resolve_point(con: duckdb.DuckDBPyConnection, args: dict) -> list[str]:
    where = ["site_id = ?", "point_class = ?", "equipment_label = ?"]
    params: list[object] = [args["site_id"], args["point_class"], args["equipment_label"]]
    if args.get("location_label") is not None:
        where.append("location_label = ?")
        params.append(args["location_label"])
    rows = con.execute(
        f"select stream_id from tool_ready_points where {' and '.join(where)} order by stream_id",
        tuple(params),
    ).fetchall()
    return [row[0] for row in rows]


def derive_quality_cutoffs(con: duckdb.DuckDBPyConnection) -> dict:
    row = con.execute(
        """
        select
            quantile_cont(observed_fraction, 0.10),
            quantile_cont(observed_fraction, 0.75),
            quantile_cont(longest_gap_seconds / nullif(median_step_seconds, 0), 0.50),
            quantile_cont(longest_gap_seconds / nullif(median_step_seconds, 0), 0.95)
        from quality_metrics
        where median_step_seconds is not null and median_step_seconds > 0
        """
    ).fetchone()
    return {
        "obs_q10": float(row[0]),
        "obs_q75": float(row[1]),
        "gap_q50": float(row[2]),
        "gap_q95": float(row[3]),
    }


@lru_cache(maxsize=4096)
def load_raw_history(zip_path: str, member_name: str | None, stream_id: str) -> pd.DataFrame:
    member = member_name if member_name else None
    frame = extract_stream_history(Path(zip_path), stream_id, member)
    frame = frame.dropna(subset=["timestamp", "value"]).sort_values("timestamp").reset_index(drop=True)
    return frame


def load_table_history(con: duckdb.DuckDBPyConnection, stream_id: str) -> pd.DataFrame:
    frame = con.execute(
        """
        select timestamp, value
        from raw_observations
        where stream_id = ?
        order by timestamp
        """,
        (stream_id,),
    ).df()
    if frame.empty:
        return frame
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], utc=True, errors="coerce")
    frame["value"] = pd.to_numeric(frame["value"], errors="coerce")
    return frame.dropna(subset=["timestamp", "value"]).reset_index(drop=True)


def load_history_for_stream(
    con: duckdb.DuckDBPyConnection,
    zip_path: str | None,
    member_name: str | None,
    stream_id: str,
) -> pd.DataFrame:
    if zip_path:
        return load_raw_history(str(zip_path), member_name, stream_id)
    return load_table_history(con, stream_id)


def audit_scenario(con: duckdb.DuckDBPyConnection, row: dict, quality_cutoffs: dict) -> list[str]:
    issues: list[str] = []
    family = row["task_family"]
    calls = row["canonical_tool_calls"]
    answer = row["gold_final_answer"]
    metadata = row["metadata"]

    if family in {
        "day_mean_lookup",
        "relative_24h_mean_lookup",
        "window_mean_lookup",
        "window_pairwise_compare",
        "window_rank",
    }:
        point_class = metadata["point_class"]
        if not AGGREGATION_COMPATIBILITY_REGEX.match(point_class):
            issues.append(f"incompatible_point_class:{point_class}")
    elif family in {"timestamp_value_lookup", "timestamp_nearest_lookup"}:
        point_class = metadata["point_class"]
        if not TIMESTAMP_COMPATIBILITY_REGEX.match(point_class):
            issues.append(f"incompatible_timestamp_point_class:{point_class}")
    elif family == "quality_gate":
        point_class = metadata["point_class"]
        if not QUALITY_COMPATIBILITY_REGEX.match(point_class):
            issues.append(f"incompatible_quality_point_class:{point_class}")

    if family == "point_disambiguation":
        resolved = resolve_point(con, calls[0]["arguments"])
        if answer["stream_id"] not in resolved:
            issues.append("point_disambiguation_unresolved")

    elif family == "day_mean_lookup":
        resolved = resolve_point(con, calls[0]["arguments"])
        if answer["stream_id"] not in resolved:
            issues.append("day_mean_unresolved")
        agg = one(
            con,
            """
            select mean_value
            from daily_aggregates
            where site_id = ? and stream_id = ? and window_start = ? and window_end = ?
            """,
            (
                row["site_id"],
                answer["stream_id"],
                answer["window_start"],
                answer["window_end"],
            ),
        )
        if agg is None:
            issues.append("day_mean_missing_aggregate")
        elif round(float(agg[0]), 4) != round(float(answer["mean_value"]), 4):
            issues.append("day_mean_mismatch")

    elif family == "relative_24h_mean_lookup":
        resolved = resolve_point(con, calls[0]["arguments"])
        if answer["stream_id"] not in resolved:
            issues.append("relative_24h_unresolved")
        agg = one(
            con,
            """
            select mean_value
            from daily_aggregates
            where site_id = ? and stream_id = ? and window_start = ? and window_end = ?
            """,
            (
                row["site_id"],
                answer["stream_id"],
                answer["window_start"],
                answer["window_end"],
            ),
        )
        if agg is None:
            issues.append("relative_24h_missing_aggregate")
        elif round(float(agg[0]), 4) != round(float(answer["mean_value"]), 4):
            issues.append("relative_24h_mean_mismatch")

    elif family == "window_mean_lookup":
        resolved = resolve_point(con, calls[0]["arguments"])
        if answer["stream_id"] not in resolved:
            issues.append("window_mean_unresolved")
        agg = one(
            con,
            """
            select mean_value
            from weekly_aggregates
            where site_id = ? and stream_id = ? and window_start = ? and window_end = ?
            """,
            (
                row["site_id"],
                answer["stream_id"],
                answer["window_start"],
                answer["window_end"],
            ),
        )
        if agg is None:
            issues.append("window_mean_missing_aggregate")
        elif round(float(agg[0]), 4) != round(float(answer["mean_value"]), 4):
            issues.append("window_mean_mismatch")

    elif family == "window_pairwise_compare":
        left = resolve_point(con, calls[0]["arguments"])
        right = resolve_point(con, calls[1]["arguments"])
        if answer["left_stream_id"] not in left:
            issues.append("pairwise_left_unresolved")
        if answer["right_stream_id"] not in right:
            issues.append("pairwise_right_unresolved")
        left_mean = one(
            con,
            """
            select mean_value
            from weekly_aggregates
            where site_id = ? and stream_id = ? and window_start = ? and window_end = ?
            """,
            (row["site_id"], answer["left_stream_id"], calls[2]["arguments"]["window_start"], calls[2]["arguments"]["window_end"]),
        )
        right_mean = one(
            con,
            """
            select mean_value
            from weekly_aggregates
            where site_id = ? and stream_id = ? and window_start = ? and window_end = ?
            """,
            (row["site_id"], answer["right_stream_id"], calls[2]["arguments"]["window_start"], calls[2]["arguments"]["window_end"]),
        )
        if left_mean is None or right_mean is None:
            issues.append("pairwise_missing_aggregate")
        else:
            winner = answer["left_stream_id"] if float(left_mean[0]) > float(right_mean[0]) else answer["right_stream_id"]
            if winner != answer["winning_stream_id"]:
                issues.append("pairwise_winner_mismatch")
        if len(row["acceptable_tool_call_sets"]) < 2:
            issues.append("pairwise_missing_alternative_path")

    elif family == "window_rank":
        args = calls[0]["arguments"]
        rank_args = calls[1]["arguments"]
        rows = con.execute(
            """
            with monthly_window_quality as (
                select
                    m.site_id,
                    m.stream_id,
                    m.window_start,
                    m.window_end,
                    least(
                        1.0,
                        m.count / greatest(
                            1.0,
                            floor((epoch(m.window_end) - epoch(m.window_start)) / q.median_step_seconds) + 1.0
                        )
                    ) as window_coverage
                from monthly_aggregates m
                join quality_metrics q using (site_id, stream_id)
                where q.median_step_seconds is not null and q.median_step_seconds > 0
            ),
            support_cutoff as (
                select quantile_cont(window_coverage, 0.10) as min_window_coverage
                from monthly_window_quality
            ),
            class_caps as (
                select
                    t.site_id,
                    t.point_class,
                    quantile_cont(abs(m.mean_value), 0.995) as max_abs_mean
                from tool_ready_points t
                join monthly_aggregates m using (site_id, stream_id)
                where t.point_class is not null and t.point_class <> 'Point' and m.mean_value is not null
                group by 1, 2
                having count(*) >= 100
            )
            select t.stream_id, m.mean_value
            from tool_ready_points t
            join monthly_aggregates m using (site_id, stream_id)
            join monthly_window_quality q using (site_id, stream_id, window_start, window_end)
            join support_cutoff s on true
            join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
            where t.site_id = ? and t.point_class = ? and t.location_type = ?
              and m.window_start = ? and m.window_end = ?
              and q.window_coverage >= s.min_window_coverage
              and abs(m.mean_value) <= c.max_abs_mean
            order by m.mean_value desc, t.stream_id
            """,
            (
                args["site_id"],
                args["point_class"],
                args["location_type"],
                rank_args["window_start"],
                rank_args["window_end"],
            ),
        ).fetchall()
        if not rows:
            issues.append("window_rank_empty_candidate_set")
        elif rows[0][0] != answer["stream_id"]:
            issues.append("window_rank_top_mismatch")

    elif family == "timestamp_value_lookup":
        resolved = resolve_point(con, calls[0]["arguments"])
        if answer["stream_id"] not in resolved:
            issues.append("timestamp_exact_unresolved")
        raw_row = one(
            con,
            """
            select raw_zip_path, raw_member_name
            from tool_ready_points
            where site_id = ? and stream_id = ?
            """,
            (row["site_id"], answer["stream_id"]),
        )
        if raw_row is None:
            issues.append("timestamp_exact_missing_raw_ref")
        else:
            history = load_history_for_stream(con, raw_row[0], raw_row[1], answer["stream_id"])
            target_ts = pd.Timestamp(answer["observed_timestamp"])
            matches = history[pd.to_datetime(history["timestamp"], utc=True) == target_ts]
            if matches.empty:
                issues.append("timestamp_exact_missing_observation")
            else:
                value = float(matches.iloc[0]["value"])
                if round(value, 4) != round(float(answer["value"]), 4):
                    issues.append("timestamp_exact_value_mismatch")
            if answer.get("exact_match_found") is not True:
                issues.append("timestamp_exact_flag_mismatch")

    elif family == "timestamp_nearest_lookup":
        resolved = resolve_point(con, calls[0]["arguments"])
        if answer["stream_id"] not in resolved:
            issues.append("timestamp_nearest_unresolved")
        raw_row = one(
            con,
            """
            select raw_zip_path, raw_member_name
            from tool_ready_points
            where site_id = ? and stream_id = ?
            """,
            (row["site_id"], answer["stream_id"]),
        )
        if raw_row is None:
            issues.append("timestamp_nearest_missing_raw_ref")
        else:
            history = load_history_for_stream(con, raw_row[0], raw_row[1], answer["stream_id"]).copy()
            history["delta_seconds"] = (
                pd.to_datetime(history["timestamp"], utc=True) - pd.Timestamp(answer["requested_timestamp"])
            ).abs().dt.total_seconds()
            best = history.sort_values(["delta_seconds", "timestamp"]).iloc[0]
            if str(pd.Timestamp(best["timestamp"]).isoformat()) != answer["observed_timestamp"]:
                issues.append("timestamp_nearest_timestamp_mismatch")
            if round(float(best["value"]), 4) != round(float(answer["value"]), 4):
                issues.append("timestamp_nearest_value_mismatch")
            if round(float(best["delta_seconds"]), 3) != round(float(answer["offset_seconds"]), 3):
                issues.append("timestamp_nearest_offset_mismatch")
            if answer.get("exact_match_found") is not False:
                issues.append("timestamp_nearest_flag_mismatch")
            if answer.get("fallback_reason") != "nearest_available_observation":
                issues.append("timestamp_nearest_reason_mismatch")

    elif family == "quality_gate":
        resolved = resolve_point(con, calls[0]["arguments"])
        if answer["stream_id"] not in resolved:
            issues.append("quality_unresolved")
        quality = one(
            con,
            """
            select
                observed_fraction,
                longest_gap_seconds / nullif(median_step_seconds, 0) as gap_ratio,
                duplicate_timestamp_fraction,
                nan_fraction
            from quality_metrics
            where site_id = ? and stream_id = ?
            """,
            (row["site_id"], answer["stream_id"]),
        )
        if quality is None:
            issues.append("quality_missing_metrics")
        else:
            observed_fraction, gap_ratio, dup_frac, nan_frac = [float(v) if v is not None else None for v in quality]
            if row["gold_final_answer"]["decision"] == "abstain":
                if not (
                    observed_fraction < quality_cutoffs["obs_q10"]
                    or (gap_ratio is not None and gap_ratio > quality_cutoffs["gap_q95"])
                ):
                    issues.append("quality_abstain_rule_mismatch")
            else:
                if not (
                    observed_fraction >= quality_cutoffs["obs_q75"]
                    and gap_ratio is not None
                    and gap_ratio <= quality_cutoffs["gap_q50"]
                    and dup_frac == 0.0
                    and nan_frac == 0.0
                ):
                    issues.append("quality_answer_rule_mismatch")

    return issues


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--scenario-dir", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    args = parser.parse_args()

    rows = scenario_rows(args.scenario_dir)
    con = duckdb.connect(str(args.tool_store_db), read_only=True)
    quality_cutoffs = derive_quality_cutoffs(con)

    issues_by_scenario: dict[str, list[str]] = {}
    issue_counter: Counter[str] = Counter()
    family_counter: dict[str, Counter[str]] = defaultdict(Counter)

    for row in rows:
        issues = audit_scenario(con, row, quality_cutoffs)
        if issues:
            issues_by_scenario[row["scenario_id"]] = issues
            for issue in issues:
                issue_counter[issue] += 1
                family_counter[row["task_family"]][issue] += 1

    report = {
        "scenario_count": len(rows),
        "failed_scenarios": len(issues_by_scenario),
        "quality_cutoffs": quality_cutoffs,
        "issue_counter": dict(issue_counter),
        "family_issue_counter": {family: dict(counter) for family, counter in family_counter.items()},
        "issues_by_scenario": issues_by_scenario,
    }

    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
