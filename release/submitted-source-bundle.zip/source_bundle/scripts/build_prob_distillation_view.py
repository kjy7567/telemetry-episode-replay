#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any

from bts_agentbench.prob_accomplishment import save_bundle, train_prob_model
from bts_agentbench.runtime import ToolStoreRuntime


SYSTEM_PROMPT = """You are a building-operations tool-using agent.

Solve each scenario by choosing one tool action at a time, or by answering the operator directly once you have enough information.

Available tools:
- resolve_point(site_id, point_class, equipment_label, location_label?)
- list_points(site_id, point_class?, equipment_type?, location_type?)
- aggregate_window(stream_id, metric, window_start, window_end, period)
- compare_window(left_stream_id, right_stream_id, metric, window_start, window_end, period)
- rank_window(stream_ids, metric, window_start, window_end, period, order, topk)
- lookup_observation(stream_id, timestamp, mode)
- inspect_quality(stream_id)
- inspect_quality_window(stream_id, window_start, window_end, period)

Rules:
1. If you still need a tool, return exactly one compact JSON action and nothing else:
   {"tool_name":"...", "arguments":{...}}
2. Once you have enough information, answer in concise natural language for the operator.
3. Do not return the final operator answer as JSON.
4. Reuse exact stream_id values from observations when available.
5. Do not invent stream_ids, timestamps, or values.
6. If there is no exact timestamp match, use lookup_observation with mode "nearest".
7. Prefer resolve_point when the question already names a concrete equipment_label or location_label.
8. Use list_points mainly when the question asks over a group.
9. Questions may paraphrase point classes and compress equipment names.
10. For weekly quality-decision questions, use inspect_quality_window with the requested week rather than inspect_quality."""


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def benchmark_index(benchmark_dir: Path) -> dict[str, dict[str, Any]]:
    index: dict[str, dict[str, Any]] = {}
    for split in ["train", "dev", "test"]:
        for row in load_jsonl(benchmark_dir / f"{split}.jsonl"):
            index[row["scenario_id"]] = row
    return index


def scenario_messages(query: str, observations: list[str]) -> list[dict[str, str]]:
    obs_block = "\n".join(f"- {obs}" for obs in observations) if observations else "- none yet"
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Operator request: {query}\nObserved tool results so far:\n{obs_block}"},
    ]


def compact_observation(call: dict[str, Any]) -> str:
    payload = {
        "call_id": call["call_id"],
        "tool_name": call["tool_name"],
        "output": call["output"],
    }
    return json.dumps(payload, ensure_ascii=False)


def stepwise_rows_from_candidate(example: dict[str, Any], candidate: dict[str, Any], source: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    observations: list[str] = []
    for idx, call in enumerate(candidate["executed_calls"], start=1):
        rows.append(
            {
                "scenario_id": example["scenario_id"],
                "split": example["split"],
                "task_family": example["task_family"],
                "site_id": example["site_id"],
                "source": source,
                "stage": "tool_call",
                "step_index": idx,
                "messages": scenario_messages(example["query"], list(observations))
                + [
                    {
                        "role": "assistant",
                        "content": json.dumps(
                            {"tool_name": call["tool_name"], "arguments": call["arguments"]},
                            ensure_ascii=False,
                        ),
                    }
                ],
                "query": example["query"],
            }
        )
        observations.append(compact_observation(call))

    final_answer = candidate.get("final_answer")
    if isinstance(final_answer, str) and final_answer.strip():
        rows.append(
            {
                "scenario_id": example["scenario_id"],
                "split": example["split"],
                "task_family": example["task_family"],
                "site_id": example["site_id"],
                "source": source,
                "stage": "final_answer",
                "step_index": len(candidate["executed_calls"]) + 1,
                "messages": scenario_messages(example["query"], list(observations))
                + [{"role": "assistant", "content": final_answer}],
                "query": example["query"],
            }
        )
    return rows


def train_rows_from_traces(traces: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for trace in traces:
        for candidate in trace["candidates"]:
            item = dict(candidate)
            item["scenario_id"] = trace["scenario_id"]
            item["task_family"] = trace["task_family"]
            item["query"] = trace["query"]
            rows.append(item)
    return rows


def choose_candidate(candidates: list[dict[str, Any]], threshold: float) -> dict[str, Any] | None:
    rescored = sorted(candidates, key=lambda item: float(item["predicted_accomplishment_prob"]), reverse=True)
    for candidate in rescored:
        if float(candidate["predicted_accomplishment_prob"]) < threshold:
            continue
        if not candidate.get("executed_calls"):
            continue
        final_answer = candidate.get("final_answer")
        if not isinstance(final_answer, str) or not final_answer.strip():
            continue
        if final_answer.strip().lower().startswith("use "):
            continue
        return candidate
    return None


def score_traces(bundle, runtime: ToolStoreRuntime, traces: list[dict[str, Any]]) -> list[dict[str, Any]]:
    from bts_agentbench.prob_accomplishment import rollout_features
    import torch

    out: list[dict[str, Any]] = []
    for trace in traces:
        candidates = []
        for candidate in trace["candidates"]:
            item = dict(candidate)
            item["scenario_id"] = trace["scenario_id"]
            item["task_family"] = trace["task_family"]
            item["query"] = trace["query"]
            candidates.append(item)

        x_rows = []
        for candidate in candidates:
            feats = rollout_features(candidate, runtime)
            x_rows.append([float(feats.get(name, 0.0)) for name in bundle.feature_names])
        x = torch.tensor(x_rows, dtype=torch.float32)
        x = (x - bundle.mean) / bundle.std
        with torch.inference_mode():
            probs = bundle.model(x).cpu().tolist()

        rescored_candidates = []
        for candidate, prob in zip(trace["candidates"], probs):
            item = dict(candidate)
            item["predicted_accomplishment_prob"] = round(float(prob), 6)
            rescored_candidates.append(item)

        out.append(
            {
                "scenario_id": trace["scenario_id"],
                "task_family": trace["task_family"],
                "query": trace["query"],
                "candidates": rescored_candidates,
            }
        )
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--train-traces", type=Path, required=True)
    parser.add_argument("--dev-traces", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--threshold", type=float, default=0.55)
    parser.add_argument("--target-mode", choices=["binary", "utility"], default="binary")
    args = parser.parse_args()

    runtime = ToolStoreRuntime(args.tool_store_db)
    try:
        train_traces = load_jsonl(args.train_traces)
        dev_traces = load_jsonl(args.dev_traces)
        benchmark = benchmark_index(args.benchmark_dir)

        train_candidates = train_rows_from_traces(train_traces)
        runtime_map = {row["site_id"]: runtime for row in train_candidates}
        bundle, metrics = train_prob_model(
            train_candidates,
            runtime_map,
            epochs=args.epochs,
            batch_size=64,
            learning_rate=1e-3,
            target_mode=args.target_mode,
        )

        bundle_path = args.out_dir / "prob_bundle.pt"
        args.out_dir.mkdir(parents=True, exist_ok=True)
        save_bundle(bundle, str(bundle_path))

        rescored_train = score_traces(bundle, runtime, train_traces)
        rescored_dev = score_traces(bundle, runtime, dev_traces)

        train_rows: list[dict[str, Any]] = []
        dev_rows: list[dict[str, Any]] = []
        selected_train = 0
        selected_dev = 0
        skipped = Counter()

        for trace in rescored_train:
            example = benchmark[trace["scenario_id"]]
            chosen = choose_candidate(trace["candidates"], args.threshold)
            if chosen is None:
                skipped["train"] += 1
                continue
            selected_train += 1
            train_rows.extend(stepwise_rows_from_candidate(example, chosen, source="prob_distill"))

        for trace in rescored_dev:
            example = benchmark[trace["scenario_id"]]
            chosen = choose_candidate(trace["candidates"], args.threshold)
            if chosen is None:
                skipped["dev"] += 1
                continue
            selected_dev += 1
            dev_rows.extend(stepwise_rows_from_candidate(example, chosen, source="prob_distill"))

        write_jsonl(args.out_dir / "train.jsonl", train_rows)
        write_jsonl(args.out_dir / "dev.jsonl", dev_rows)
        write_jsonl(args.out_dir / "rescored_train_traces.jsonl", rescored_train)
        write_jsonl(args.out_dir / "rescored_dev_traces.jsonl", rescored_dev)

        summary = {
            "corpus": args.corpus,
            "prob_model_epochs": args.epochs,
            "target_mode": args.target_mode,
            "threshold": args.threshold,
            "bundle_path": str(bundle_path),
            "train_candidate_count": len(train_candidates),
            "train_trace_count": len(train_traces),
            "dev_trace_count": len(dev_traces),
            "selected_train_scenarios": selected_train,
            "selected_dev_scenarios": selected_dev,
            "train_rows": len(train_rows),
            "dev_rows": len(dev_rows),
            "skipped": dict(skipped),
            "train_metrics": metrics,
        }
        (args.out_dir / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps(summary, indent=2, ensure_ascii=False))
    finally:
        runtime.close()


if __name__ == "__main__":
    main()
