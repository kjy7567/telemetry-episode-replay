#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def location_clause(metadata: dict[str, Any]) -> str:
    location = metadata.get("location_label")
    equipment = metadata.get("equipment_label")
    if not location:
        return ""
    if equipment and str(location) == str(equipment):
        return ""
    return f" at location {location}"


def canonical_query(row: dict[str, Any]) -> str:
    family = row["task_family"]
    meta = row.get("metadata", {})
    gold = row["gold_final_answer"]
    calls = row["canonical_tool_calls"]
    site = row["site_id"]
    point_class = meta.get("point_class", "Unknown_Point")
    equipment = meta.get("equipment_label")
    loc = location_clause(meta)

    if family == "point_disambiguation":
        return (
            f"For site {site}, which stream_id corresponds to point class {point_class} "
            f"on equipment {equipment}{loc}?"
        )
    if family == "day_mean_lookup":
        return (
            f"For site {site}, what is the mean_value for point class {point_class} on equipment {equipment}{loc} "
            f"between {gold['window_start']} and {gold['window_end']}?"
        )
    if family == "relative_24h_mean_lookup":
        return (
            f"For site {site}, what is the mean_value for point class {point_class} on equipment {equipment}{loc} "
            f"over the previous 24 hours ending at {gold['window_end']}?"
        )
    if family == "window_mean_lookup":
        return (
            f"For site {site}, what is the weekly mean_value for point class {point_class} on equipment {equipment}{loc} "
            f"between {gold['window_start']} and {gold['window_end']}?"
        )
    if family == "window_pairwise_compare":
        left = calls[0]["arguments"]["equipment_label"]
        right = calls[1]["arguments"]["equipment_label"]
        left_loc = calls[0]["arguments"].get("location_label")
        right_loc = calls[1]["arguments"].get("location_label")
        left_loc_clause = f" at location {left_loc}" if left_loc and left_loc != left else ""
        right_loc_clause = f" at location {right_loc}" if right_loc and right_loc != right else ""
        compare = calls[2]["arguments"]
        return (
            f"For site {site}, which stream has the higher {compare['metric']} for point class {point_class} "
            f"between equipment {left}{left_loc_clause} and equipment {right}{right_loc_clause}, "
            f"over {compare['window_start']} to {compare['window_end']}?"
        )
    if family == "window_rank":
        location_type = meta.get("location_type", "UnknownLocation")
        rank = calls[1]["arguments"]
        return (
            f"For site {site}, which stream_id ranks first by {rank['metric']} for point class {point_class} "
            f"among location_type {location_type} between {rank['window_start']} and {rank['window_end']}?"
        )
    if family == "timestamp_value_lookup":
        return (
            f"For site {site}, what value is recorded for point class {point_class} on equipment {equipment}{loc} "
            f"at timestamp {gold['requested_timestamp']}?"
        )
    if family == "timestamp_nearest_lookup":
        return (
            f"For site {site}, if there is no exact observation for point class {point_class} on equipment {equipment}{loc} "
            f"at timestamp {gold['requested_timestamp']}, what is the nearest available observation?"
        )
    if family == "quality_gate":
        quality = next(call["arguments"] for call in calls if call["tool_name"] == "inspect_quality_window")
        return (
            f"For site {site}, should the agent answer or abstain for a weekly trend request on point class {point_class} "
            f"for equipment {equipment}{loc} for the week beginning {quality['window_start']}, based on inspect_quality_window?"
        )
    raise KeyError(f"Unhandled family {family}")


def rewrite_rows(rows: list[dict[str, Any]], *, split_name: str) -> list[dict[str, Any]]:
    rewritten: list[dict[str, Any]] = []
    for row in rows:
        clone = json.loads(json.dumps(row, ensure_ascii=False))
        clone["surface_split"] = split_name
        clone.setdefault("metadata", {})
        clone["metadata"]["surface_split"] = split_name
        if split_name == "canonical":
            clone["query"] = canonical_query(clone)
            clone["query_surface_version"] = "canonical-v1"
            clone["metadata"]["query_surface_version"] = "canonical-v1"
            clone["metadata"]["surface_template_id"] = f"{clone['task_family']}_canonical_t1"
            clone["metadata"]["surface_transforms"] = []
        rewritten.append(clone)
    return rewritten


def copy_manifest(in_dir: Path, out_dir: Path, split_name: str) -> None:
    manifest = json.loads((in_dir / "manifest.json").read_text(encoding="utf-8"))
    manifest["surface_split"] = split_name
    if split_name == "canonical":
        manifest["query_surface_version"] = "canonical-v1"
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--out-root", type=Path, required=True)
    parser.add_argument("--corpus", required=True)
    args = parser.parse_args()

    canonical_dir = args.out_root / args.corpus / "canonical"
    robust_dir = args.out_root / args.corpus / "robustness"
    canonical_dir.mkdir(parents=True, exist_ok=True)
    robust_dir.mkdir(parents=True, exist_ok=True)

    for split in ["train", "dev", "test"]:
        rows = load_jsonl(args.benchmark_dir / f"{split}.jsonl")
        write_jsonl(canonical_dir / f"{split}.jsonl", rewrite_rows(rows, split_name="canonical"))
        write_jsonl(robust_dir / f"{split}.jsonl", rewrite_rows(rows, split_name="robustness"))

    copy_manifest(args.benchmark_dir, canonical_dir, "canonical")
    copy_manifest(args.benchmark_dir, robust_dir, "robustness")

    summary = {
        "corpus": args.corpus,
        "source_benchmark_dir": str(args.benchmark_dir),
        "canonical_dir": str(canonical_dir),
        "robustness_dir": str(robust_dir),
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
