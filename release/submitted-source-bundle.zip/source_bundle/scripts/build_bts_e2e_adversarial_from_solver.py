#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from functools import lru_cache
from pathlib import Path
from typing import Any

import duckdb
import pandas as pd

from bts_agentbench.raw import extract_stream_history

REPO_ROOT = Path(__file__).resolve().parents[1]


TARGET_SLOT = "target_reference"
COMPARISON_SLOT = "comparison_targets"
RANKING_SLOT = "ranking_scope"
SITE_SLOT = "site_id"
TIME_SLOT = "time_reference"


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def solved_ids(paths: list[Path]) -> set[str]:
    ids: set[str] = set()
    for path in paths:
        for row in load_jsonl(path):
            if row.get("verification", {}).get("label") == "accomplished":
                ids.add(row["scenario_id"])
    return ids


def display_label(site_id: str, value: str | None) -> str:
    if not value:
        return ""
    prefix = f"{site_id} "
    return value[len(prefix) :] if value.startswith(prefix) else value


def readable_point_class(point_class: str) -> str:
    return point_class.replace("_", " ").lower()


def point_class_alias(point_class: str) -> str:
    aliases = {
        "Electrical_Energy_Sensor": "energy counter",
        "Electrical_Power_Sensor": "power draw",
        "Air_Differential_Pressure_Sensor": "air pressure delta",
        "Air_Differential_Pressure_Setpoint": "air pressure delta target",
        "Air_Flow_Sensor": "airflow",
        "Position_Sensor": "position signal",
        "Run_Time_Sensor": "runtime counter",
        "Frequency_Sensor": "frequency signal",
        "Motor_Speed_Sensor": "motor speed signal",
        "Heating_Thermal_Power_Sensor": "heating thermal output",
        "Temperature_Setpoint": "temperature target",
        "Air_Temperature_Setpoint": "air temperature target",
        "Chilled_Water_Flow_Sensor": "chilled-water flow",
    }
    return aliases.get(point_class, readable_point_class(point_class).replace(" sensor", " signal").replace(" setpoint", " target"))


def asset_alias(label: str) -> str:
    patterns = [
        (r"^Electrical Generation Meter (\d+)$", "EGM-{}"),
        (r"^Electrical Storage Meter (\d+)$", "ESM-{}"),
        (r"^Electrical Meter (\d+)$", "EM-{}"),
        (r"^Supply Fan (\d+)$", "SF-{}"),
        (r"^Terminal Unit (\d+)$", "TU-{}"),
        (r"^VAV (\d+)$", "VAV-{}"),
        (r"^Zone (\d+)$", "zone tag Z-{}"),
        (r"^Floor (\d+)$", "floor tag F-{}"),
        (r"^Chilled Water Coil (\d+)$", "CHW coil {}"),
        (r"^Chilled Water Loop (\d+)$", "CHW loop {}"),
        (r"^Hot Water Coil (\d+)$", "HW coil {}"),
        (r"^Water Heater (\d+)$", "WH-{}"),
        (r"^Ventilation Air System (\d+)$", "VAS-{}"),
    ]
    for pattern, template in patterns:
        match = re.match(pattern, label)
        if match:
            return template.format(match.group(1))
    return label


def first_call_args(row: dict[str, Any], tool_name: str) -> dict[str, Any]:
    for call in row.get("canonical_tool_calls", []):
        if call.get("tool_name") == tool_name:
            return call.get("arguments", {})
    return {}


def evidence_stream_id(row: dict[str, Any]) -> str:
    final = row.get("gold_final_answer", {})
    if isinstance(final, dict) and isinstance(final.get("stream_id"), str):
        return final["stream_id"]
    required = row.get("task_accomplish_verifier", {}).get("evidence_checks", {}).get("required_stream_ids", [])
    if required:
        return str(required[0])
    evidence = row.get("evidence", {})
    if isinstance(evidence, dict):
        stream_ids = evidence.get("stream_ids", [])
        if stream_ids:
            return str(stream_ids[0])
    raise ValueError(f"missing target stream_id for {row['scenario_id']}")


def candidate_index(con: duckdb.DuckDBPyConnection, site_id: str, point_class: str, stream_id: str) -> tuple[int, int]:
    rows = con.execute(
        """
        select stream_id
        from tool_ready_points
        where site_id = ? and point_class = ?
        order by stream_id
        """,
        (site_id, point_class),
    ).fetchall()
    stream_ids = [str(row[0]) for row in rows]
    if stream_id not in stream_ids:
        raise ValueError(f"stream_id not in candidate set: {stream_id}")
    return stream_ids.index(stream_id) + 1, len(stream_ids)


def resolve_stream_id(con: duckdb.DuckDBPyConnection, args: dict[str, Any]) -> str:
    where = ["site_id = ?", "point_class = ?"]
    params: list[Any] = [args["site_id"], args["point_class"]]
    if args.get("equipment_label") is not None:
        where.append("lower(equipment_label) = lower(?)")
        params.append(args["equipment_label"])
    if args.get("location_label") is not None:
        where.append("lower(location_label) = lower(?)")
        params.append(args["location_label"])
    rows = con.execute(
        f"""
        select stream_id
        from tool_ready_points
        where {' and '.join(where)}
        order by stream_id
        """,
        tuple(params),
    ).fetchall()
    if len(rows) != 1:
        raise ValueError(f"expected one stream for resolve args, found {len(rows)}")
    return str(rows[0][0])


def distinct_point_class_index(con: duckdb.DuckDBPyConnection, site_id: str, point_class: str) -> tuple[int, int]:
    rows = con.execute(
        """
        select distinct point_class
        from tool_ready_points
        where site_id = ?
        order by point_class
        """,
        (site_id,),
    ).fetchall()
    classes = [str(row[0]) for row in rows]
    if point_class not in classes:
        raise ValueError(f"point_class not in site inventory: {point_class}")
    return classes.index(point_class) + 1, len(classes)


def first_observation_timestamp(con: duckdb.DuckDBPyConnection, stream_id: str) -> str:
    row = con.execute(
        """
        select first_timestamp
        from raw_stream_index
        where stream_id = ?
        """,
        (stream_id,),
    ).fetchone()
    if row is None or row[0] is None:
        raise ValueError(f"missing first timestamp for {stream_id}")
    return str(row[0])


@lru_cache(maxsize=8192)
def load_valid_raw_history(zip_path: str, member_name: str | None, stream_id: str) -> pd.DataFrame:
    path = Path(zip_path)
    if not path.is_absolute():
        path = REPO_ROOT / path
    frame = extract_stream_history(path, stream_id, member_name if member_name else None).copy()
    frame = frame.dropna(subset=["timestamp", "value"]).sort_values("timestamp").reset_index(drop=True)
    return frame


def first_observation_timestamp_in_window(
    con: duckdb.DuckDBPyConnection,
    stream_id: str,
    window_start: str,
    window_end: str,
) -> str | None:
    row = con.execute(
        """
        select raw_zip_path, raw_member_name
        from tool_ready_points
        where stream_id = ?
        """,
        (stream_id,),
    ).fetchone()
    if row is None or row[0] is None:
        return None
    frame = load_valid_raw_history(str(row[0]), str(row[1]) if row[1] is not None else None, stream_id)
    start_ts = pd.Timestamp(window_start)
    end_ts = pd.Timestamp(window_end)
    local = frame[(frame["timestamp"] >= start_ts) & (frame["timestamp"] < end_ts)]
    if local.empty:
        return None
    return str(local.iloc[0]["timestamp"])


def sample_verification_timestamp(row: dict[str, Any], con: duckdb.DuckDBPyConnection) -> str:
    stream_id = evidence_stream_id(row)
    gold = row.get("gold_final_answer", {})

    if row.get("task_family") in {"timestamp_value_lookup", "timestamp_nearest_lookup"}:
        observed_timestamp = gold.get("observed_timestamp")
        if isinstance(observed_timestamp, str):
            return observed_timestamp

    for tool_name in ["inspect_quality_window", "aggregate_window", "compare_window", "rank_window"]:
        call = first_tool_call(row, tool_name)
        if call is None:
            continue
        args = call.get("arguments", {})
        window_start = args.get("window_start")
        window_end = args.get("window_end")
        if isinstance(window_start, str) and isinstance(window_end, str):
            local = first_observation_timestamp_in_window(con, stream_id, window_start, window_end)
            if local is not None:
                return local
            raise ValueError(
                f"missing task-local raw sample for {row['scenario_id']} "
                f"({tool_name}, {window_start} .. {window_end}, stream={stream_id})"
            )

    return first_observation_timestamp(con, stream_id)


def target_answer(row: dict[str, Any], *, coded: bool) -> tuple[str, str, str]:
    family = row["task_family"]
    site = row["site_id"]

    if family == "window_pairwise_compare":
        calls = [call["arguments"] for call in row["canonical_tool_calls"] if call["tool_name"] == "resolve_point"]
        left, right = calls[0], calls[1]
        point = point_class_alias(left["point_class"]) if coded else readable_point_class(left["point_class"])
        left_asset = asset_alias(display_label(site, left.get("equipment_label"))) if coded else display_label(site, left.get("equipment_label"))
        right_asset = asset_alias(display_label(site, right.get("equipment_label"))) if coded else display_label(site, right.get("equipment_label"))
        answer = f"Compare {left_asset} and {right_asset} using the {point}."
        return COMPARISON_SLOT, "Which two candidates and signal should I compare?", answer

    if family == "window_rank":
        args = first_call_args(row, "list_points")
        point = point_class_alias(args["point_class"]) if coded else readable_point_class(args["point_class"])
        scope = args.get("location_type") or "Location"
        scope_text = "location tags" if coded else f"{scope} locations"
        answer = f"Rank the {point} streams across {scope_text}."
        return RANKING_SLOT, "Which signal group and scope should I rank?", answer

    args = first_call_args(row, "resolve_point")
    point = point_class_alias(args["point_class"]) if coded else readable_point_class(args["point_class"])
    asset = display_label(site, args.get("equipment_label"))
    asset_text = asset_alias(asset) if coded else asset
    location = display_label(site, args.get("location_label"))
    if location:
        location = asset_alias(location) if coded else location
        answer = f"Use the {point} on {asset_text} serving {location}."
    else:
        answer = f"Use the {point} on {asset_text}."
    return TARGET_SLOT, "Which signal or equipment should I use?", answer


def indexed_target_answer(row: dict[str, Any], con: duckdb.DuckDBPyConnection) -> tuple[str, str, str]:
    family = row["task_family"]
    site = row["site_id"]

    if family == "window_pairwise_compare":
        calls = [call["arguments"] for call in row["canonical_tool_calls"] if call["tool_name"] == "resolve_point"]
        left, right = calls[0], calls[1]
        point = point_class_alias(left["point_class"])
        left_stream = resolve_stream_id(con, left)
        right_stream = resolve_stream_id(con, right)
        left_index, left_total = candidate_index(con, site, left["point_class"], str(left_stream))
        right_index, right_total = candidate_index(con, site, right["point_class"], str(right_stream))
        answer = (
            f"Compare {point} candidate #{left_index} of {left_total} and candidate #{right_index} of {right_total}. "
            "The indices are 1-based over resolve_point matches sorted by stream_id."
        )
        return COMPARISON_SLOT, "Which candidate indices should I use after resolving the ambiguous signal?", answer

    if family == "window_rank":
        args = first_call_args(row, "list_points")
        index, total = distinct_point_class_index(con, site, args["point_class"])
        scope = args.get("location_type") or "Location"
        answer = (
            f"Use point-class index #{index} of {total} from the site's lexicographically sorted distinct point_class list, "
            f"then rank across {scope} locations."
        )
        return RANKING_SLOT, "Which indexed signal group and scope should I rank?", answer

    args = first_call_args(row, "resolve_point")
    stream_id = evidence_stream_id(row)
    index, total = candidate_index(con, site, args["point_class"], stream_id)
    point = point_class_alias(args["point_class"])
    answer = (
        f"Use the {point} candidate #{index} of {total}. "
        "The candidate index is 1-based over resolve_point matches for the site and point class, sorted by stream_id."
    )
    return TARGET_SLOT, "Which candidate should I use after resolving the ambiguous signal?", answer


def first_tool_call(row: dict[str, Any], tool_name: str) -> dict[str, Any] | None:
    for call in row.get("canonical_tool_calls", []):
        if call.get("tool_name") == tool_name:
            return call
    return None


def with_required_tool(row: dict[str, Any], tool_name: str) -> None:
    verifier = dict(row.get("task_accomplish_verifier", {}))
    process = dict(verifier.get("process_checks", {}))
    required = list(process.get("required_tools", []))
    if tool_name not in required:
        required.append(tool_name)
    process["required_tools"] = required
    verifier["process_checks"] = process
    row["task_accomplish_verifier"] = verifier


def default_clarification_question(slot: str) -> str:
    if slot == SITE_SLOT:
        return "Which BTS site should I use?"
    if slot == TIME_SLOT:
        return "Which date, week, month, time window, or exact timestamp should I use?"
    if slot == TARGET_SLOT:
        return "Which signal or equipment should I use?"
    if slot == COMPARISON_SLOT:
        return "Which two candidates and signal should I compare?"
    if slot == RANKING_SLOT:
        return "Which signal group and scope should I rank?"
    return f"Which value should I use for {slot}?"


def clarification_milestone_name(slot: str) -> str:
    return f"collect_{slot}"


def slot_phrase(slots: list[str]) -> str:
    ordered = []
    if any(slot in slots for slot in {TARGET_SLOT, COMPARISON_SLOT, RANKING_SLOT}):
        ordered.append("target")
    if SITE_SLOT in slots:
        ordered.append("site")
    if TIME_SLOT in slots:
        ordered.append("time")
    if not ordered:
        return "missing details"
    if len(ordered) == 1:
        return f"missing {ordered[0]} details"
    if len(ordered) == 2:
        return f"missing {ordered[0]} or {ordered[1]} details"
    return f"missing {ordered[0]}, {ordered[1]}, or {ordered[2]} details"


def normalize_clarification_scaffolding(row: dict[str, Any]) -> dict[str, Any]:
    out = dict(row)
    slots = list(out.get("required_clarification_slots", []))
    slot_order = {SITE_SLOT: 0, TARGET_SLOT: 1, COMPARISON_SLOT: 1, RANKING_SLOT: 1, TIME_SLOT: 2}
    slots = sorted(dict.fromkeys(slots), key=lambda slot: (slot_order.get(slot, 99), slot))
    out["required_clarification_slots"] = slots

    answers = dict(out.get("clarification_answers", {}))
    if SITE_SLOT in slots and SITE_SLOT not in answers:
        answers[SITE_SLOT] = f"It's in {out['site_id']}."
    out["clarification_answers"] = answers

    questions = dict(out.get("clarification_questions", {}))
    for slot in slots:
        questions.setdefault(slot, default_clarification_question(slot))
    out["clarification_questions"] = questions

    existing = [m for m in out.get("interaction_milestones", []) if m.get("type") != "user_clarification"]
    user_milestones = [
        {"name": clarification_milestone_name(slot), "type": "user_clarification", "slot": slot, "required": True}
        for slot in slots
    ]
    out["interaction_milestones"] = user_milestones + existing

    interaction_verifier = dict(out.get("interaction_verifier", {}))
    interaction_verifier["required_clarification_slots"] = slots
    interaction_verifier["max_user_turns"] = 2 + len(slots) + len(out.get("post_answer_user_turns", []))
    out["interaction_verifier"] = interaction_verifier
    return out


def existing_quality_tool_name(row: dict[str, Any]) -> str | None:
    for call in row.get("canonical_tool_calls", []):
        tool_name = call.get("tool_name")
        if tool_name in {"inspect_quality", "inspect_quality_window"}:
            return str(tool_name)
    return None


def prepend_candidate_enumeration(row: dict[str, Any]) -> bool:
    resolve_call = first_tool_call(row, "resolve_point")
    if resolve_call is None:
        return False
    args = resolve_call.get("arguments", {})
    list_call = {
        "call_id": "c0",
        "tool_name": "list_points",
        "arguments": {"site_id": args["site_id"], "point_class": args["point_class"]},
    }
    canonical = list(row.get("canonical_tool_calls", []))
    if not canonical or canonical[0].get("tool_name") != "list_points":
        row["canonical_tool_calls"] = [list_call] + canonical
    acceptable = []
    for variant in row.get("acceptable_tool_call_sets", []):
        if variant and variant[0].get("tool_name") == "list_points":
            acceptable.append(variant)
        else:
            acceptable.append([list_call] + list(variant))
    row["acceptable_tool_call_sets"] = acceptable
    with_required_tool(row, "list_points")
    return True


def append_rank_quality_check(row: dict[str, Any]) -> bool:
    if row.get("task_family") != "window_rank":
        return False
    stream_id = evidence_stream_id(row)
    quality_call = {
        "call_id": "c_quality",
        "tool_name": "inspect_quality",
        "arguments": {"stream_id": stream_id},
    }
    canonical = list(row.get("canonical_tool_calls", []))
    if not any(call.get("tool_name") == "inspect_quality" for call in canonical):
        row["canonical_tool_calls"] = canonical + [quality_call]
    acceptable = []
    for variant in row.get("acceptable_tool_call_sets", []):
        if any(call.get("tool_name") == "inspect_quality" for call in variant):
            acceptable.append(variant)
        else:
            acceptable.append(list(variant) + [quality_call])
    row["acceptable_tool_call_sets"] = acceptable
    with_required_tool(row, "inspect_quality")
    return True


def append_target_quality_check(row: dict[str, Any]) -> bool:
    existing_tool = existing_quality_tool_name(row)
    if existing_tool is not None:
        with_required_tool(row, existing_tool)
        return False
    stream_id = evidence_stream_id(row)
    quality_call = {
        "call_id": "c_quality",
        "tool_name": "inspect_quality",
        "arguments": {"stream_id": stream_id},
    }
    canonical = list(row.get("canonical_tool_calls", []))
    if any(call.get("tool_name") == "inspect_quality" for call in canonical):
        with_required_tool(row, "inspect_quality")
        return False
    row["canonical_tool_calls"] = canonical + [quality_call]

    acceptable = []
    for variant in row.get("acceptable_tool_call_sets", []):
        if any(call.get("tool_name") == "inspect_quality" for call in variant):
            acceptable.append(variant)
        else:
            acceptable.append(list(variant) + [quality_call])
    row["acceptable_tool_call_sets"] = acceptable
    with_required_tool(row, "inspect_quality")
    return True


def append_sample_verification(row: dict[str, Any], con: duckdb.DuckDBPyConnection) -> tuple[bool, str]:
    stream_id = evidence_stream_id(row)
    timestamp = sample_verification_timestamp(row, con)
    lookup_call = {
        "call_id": "c_sample",
        "tool_name": "lookup_observation",
        "arguments": {"stream_id": stream_id, "timestamp": timestamp, "mode": "exact"},
    }
    canonical = list(row.get("canonical_tool_calls", []))
    if any(call.get("tool_name") == "lookup_observation" and call.get("arguments", {}).get("timestamp") == timestamp for call in canonical):
        with_required_tool(row, "lookup_observation")
        return False, timestamp
    row["canonical_tool_calls"] = canonical + [lookup_call]

    acceptable = []
    for variant in row.get("acceptable_tool_call_sets", []):
        if any(call.get("tool_name") == "lookup_observation" and call.get("arguments", {}).get("timestamp") == timestamp for call in variant):
            acceptable.append(variant)
        else:
            acceptable.append(list(variant) + [lookup_call])
    row["acceptable_tool_call_sets"] = acceptable
    with_required_tool(row, "lookup_observation")
    return True, timestamp


def require_sample_result_in_final_answer(row: dict[str, Any], con: duckdb.DuckDBPyConnection) -> tuple[bool, str]:
    timestamp = sample_verification_timestamp(row, con)
    append_sample_verification(row, con)

    gold = dict(row.get("gold_final_answer", {}))
    gold["sample_exact_match_found"] = True
    gold["sample_checked_timestamp"] = timestamp
    row["gold_final_answer"] = gold

    verifier = dict(row.get("task_accomplish_verifier", {}))
    final_checks = dict(verifier.get("final_answer_checks", {}))
    required = list(final_checks.get("required_fields", []))
    for field in ["sample_exact_match_found", "sample_checked_timestamp"]:
        if field not in required:
            required.append(field)
    categorical = list(final_checks.get("categorical_exact_match", []))
    for field in ["sample_exact_match_found", "sample_checked_timestamp"]:
        if field not in categorical:
            categorical.append(field)
    final_checks["required_fields"] = required
    final_checks["categorical_exact_match"] = categorical
    verifier["final_answer_checks"] = final_checks
    row["task_accomplish_verifier"] = verifier
    return True, timestamp


def strip_procedural_target_suffix(text: str) -> str:
    markers = [
        " First enumerate the candidate set with list_points, then apply the index.",
        " After ranking, inspect the top stream quality before finalizing.",
        " After selecting the target stream, inspect its quality before returning the final answer.",
        " Also verify the raw sample at ",
        " In the final answer, explicitly state that this raw sample check was an exact match and cite the checked timestamp.",
    ]
    stripped = text
    for marker in markers[:3]:
        stripped = stripped.replace(marker, "")
    sample_idx = stripped.find(markers[3])
    if sample_idx >= 0:
        stripped = stripped[:sample_idx]
    stripped = stripped.replace(markers[4], "")
    return stripped.strip()


def enforce_agentic_candidate_workflow(
    row: dict[str, Any],
    round_name: str,
    tool_con: duckdb.DuckDBPyConnection | None = None,
) -> dict[str, Any]:
    if round_name not in {"adv4", "adv5", "adv6", "adv7"}:
        return row

    enumerated = prepend_candidate_enumeration(row)
    rank_checked = append_rank_quality_check(row)
    target_quality_checked = append_target_quality_check(row) if round_name in {"adv5", "adv6", "adv7"} else False
    sample_checked = False
    sample_timestamp = ""
    sample_result_required = False
    if round_name in {"adv6", "adv7"}:
        if tool_con is None:
            raise ValueError(f"{round_name} requires --tool-store-db")
        if round_name == "adv7":
            sample_result_required, sample_timestamp = require_sample_result_in_final_answer(row, tool_con)
            sample_checked = True
        else:
            sample_checked, sample_timestamp = append_sample_verification(row, tool_con)
    answers = dict(row.get("clarification_answers", {}))
    target_slot = row.get("metadata", {}).get("adversarial_target_slot")
    if target_slot in answers:
        answers[target_slot] = strip_procedural_target_suffix(str(answers[target_slot]))
    row["clarification_answers"] = answers

    metadata = dict(row.get("metadata", {}))
    metadata["requires_explicit_candidate_enumeration"] = bool(enumerated)
    metadata["requires_rank_quality_validation"] = bool(rank_checked)
    metadata["requires_target_quality_validation"] = bool(target_quality_checked)
    metadata["requires_raw_sample_verification"] = bool(sample_checked)
    metadata["requires_sample_result_in_final_answer"] = bool(sample_result_required)
    if sample_timestamp:
        metadata["raw_sample_verification_timestamp"] = sample_timestamp
    row["metadata"] = metadata

    difficulty = dict(row.get("difficulty_proxy", {}))
    difficulty["requires_explicit_candidate_enumeration"] = bool(enumerated)
    difficulty["requires_rank_quality_validation"] = bool(rank_checked)
    difficulty["requires_target_quality_validation"] = bool(target_quality_checked)
    difficulty["requires_raw_sample_verification"] = bool(sample_checked)
    difficulty["requires_sample_result_in_final_answer"] = bool(sample_result_required)
    row["difficulty_proxy"] = difficulty
    return row


def objective_prompt(row: dict[str, Any]) -> str:
    family = row["task_family"]
    slots = list(row.get("required_clarification_slots", []))
    slot_label_map = {
        TARGET_SLOT: "exact target",
        COMPARISON_SLOT: "candidate pair",
        RANKING_SLOT: "signal group",
        SITE_SLOT: "site",
        TIME_SLOT: "time context",
    }

    def slot_labels(values: list[str]) -> str:
        labels = [slot_label_map.get(value, value) for value in values]
        if not labels:
            return ""
        if len(labels) == 1:
            return labels[0]
        if len(labels) == 2:
            return f"{labels[0]} and {labels[1]}"
        return f"{', '.join(labels[:-1])}, and {labels[-1]}"

    if slots:
        common = f"The handoff omitted the {slot_labels(slots)}. Ask me for the {slot_phrase(slots)} before using tools."
    else:
        common = "Use the building telemetry tools and return the result you can justify."
    if family == "quality_gate":
        week_start = None
        for call in row.get("canonical_tool_calls", []):
            if call.get("tool_name") == "inspect_quality_window":
                week_start = call.get("arguments", {}).get("window_start")
                break
        if week_start is not None:
            ts = pd.Timestamp(week_start)
            if ts.tzinfo is not None:
                ts = ts.tz_convert("UTC")
            week_phrase = f"{ts.strftime('%B')} {ts.day}, {ts.year}"
            return (
                "Operator handoff: "
                f"I need to decide whether to answer or abstain for a weekly trend request for the week beginning {week_phrase}, "
                f"{common}"
            )
    prompts = {
        "point_disambiguation": f"I need the stream id for a building telemetry signal. {common}",
        "day_mean_lookup": f"I need a day-average value for a building telemetry signal. {common}",
        "relative_24h_mean_lookup": f"I need the prior-24-hour average for a building telemetry signal. {common}",
        "window_mean_lookup": f"I need a weekly average for a building telemetry signal. {common}",
        "window_pairwise_compare": f"I need to compare which of two telemetry points averaged higher. {common}",
        "window_rank": f"I need to rank a group of telemetry streams by average value. {common}",
        "timestamp_value_lookup": f"I need the logged reading for a building telemetry signal at a specific timestamp. {common}",
        "timestamp_nearest_lookup": (
            "I need the logged reading to use when a building telemetry signal has no exact sample at a requested "
            f"timestamp. State that the exact sample was unavailable and return the nearest logged reading. {common}"
        ),
        "quality_gate": f"I need to decide whether to answer or abstain for a weekly trend request based on signal quality. {common}",
    }
    return f"Operator handoff: {prompts.get(family, prompts['point_disambiguation'])}"


def add_custom_slot(
    row: dict[str, Any],
    *,
    coded: bool,
    round_name: str,
    tool_con: duckdb.DuckDBPyConnection | None = None,
) -> dict[str, Any]:
    out = dict(row)
    if round_name in {"adv3", "adv4", "adv5", "adv6", "adv7"}:
        if tool_con is None:
            raise ValueError(f"{round_name} requires --tool-store-db")
        slot, question, answer = indexed_target_answer(row, tool_con)
    else:
        slot, question, answer = target_answer(row, coded=coded)
    answers = dict(out.get("clarification_answers", {}))
    if "site_id" not in answers:
        answers["site_id"] = f"It's in {out['site_id']}."
    answers[slot] = answer
    questions = dict(out.get("clarification_questions", {}))
    if SITE_SLOT not in questions:
        questions[SITE_SLOT] = default_clarification_question(SITE_SLOT)
    questions[slot] = question

    slots = list(out.get("required_clarification_slots", []))
    if SITE_SLOT not in slots:
        slots.insert(0, SITE_SLOT)
    if slot not in slots:
        if SITE_SLOT in slots:
            insert_at = slots.index(SITE_SLOT) + 1
        else:
            insert_at = 0
        slots.insert(insert_at, slot)

    metadata = dict(out.get("metadata", {}))
    prior = list(metadata.get("adversarial_transforms", []))
    prior.append(round_name)
    metadata.update(
        {
            "adversarial_transforms": prior,
            "adversarial_target_slot": slot,
            "coded_target_reference": coded,
            "indexed_target_reference": round_name in {"adv3", "adv4", "adv5", "adv6", "adv7"},
        }
    )

    out["clarification_answers"] = answers
    out["clarification_questions"] = questions
    out["required_clarification_slots"] = slots
    out["metadata"] = metadata
    out["difficulty_proxy"] = dict(out.get("difficulty_proxy", {}))
    out["difficulty_proxy"]["requires_target_clarification"] = True
    out["difficulty_proxy"]["requires_candidate_enumeration"] = round_name in {"adv3", "adv4", "adv5", "adv6", "adv7"}
    out["difficulty_proxy"]["agentic_turn_requirements"] = len(slots) + len(out.get("post_answer_user_turns", []))
    out = normalize_clarification_scaffolding(out)
    out["query"] = objective_prompt(out)
    out["initial_user_message"] = out["query"]
    out = enforce_agentic_candidate_workflow(out, round_name, tool_con=tool_con)
    return out


def transform_split(
    rows: list[dict[str, Any]],
    solved: set[str],
    round_name: str,
    tool_con: duckdb.DuckDBPyConnection | None = None,
) -> tuple[list[dict[str, Any]], Counter[str]]:
    transformed: list[dict[str, Any]] = []
    counts: Counter[str] = Counter()
    coded = round_name in {"adv2", "adv3", "adv4", "adv5", "adv6", "adv7"}
    for row in rows:
        if row["scenario_id"] in solved:
            new_row = add_custom_slot(row, coded=coded, round_name=round_name, tool_con=tool_con)
            transformed.append(new_row)
            counts["transformed"] += 1
            counts[f"transformed:{row['task_family']}"] += 1
        else:
            transformed.append(row)
            counts["unchanged"] += 1
    return transformed, counts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--solver-jsonl", type=Path, action="append")
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--round", choices=["adv1", "adv2", "adv3", "adv4", "adv5", "adv6", "adv7"], required=True)
    parser.add_argument("--tool-store-db", type=Path)
    parser.add_argument("--all-rows", action="store_true")
    args = parser.parse_args()

    if not args.all_rows and not args.solver_jsonl:
        raise SystemExit("--solver-jsonl is required unless --all-rows is set")
    solved = (
        {
            row["scenario_id"]
            for split in ["train", "dev", "test"]
            for row in load_jsonl(args.benchmark_dir / f"{split}.jsonl")
        }
        if args.all_rows
        else solved_ids(args.solver_jsonl or [])
    )
    if args.round in {"adv3", "adv4", "adv5", "adv6", "adv7"} and args.tool_store_db is None:
        raise SystemExit(f"--tool-store-db is required for --round {args.round}")
    tool_con = duckdb.connect(str(args.tool_store_db)) if args.tool_store_db is not None else None
    args.out_dir.mkdir(parents=True, exist_ok=True)
    split_counts: dict[str, dict[str, int]] = {}
    try:
        for split in ["train", "dev", "test"]:
            rows = load_jsonl(args.benchmark_dir / f"{split}.jsonl")
            out_rows, counts = transform_split(rows, solved, args.round, tool_con=tool_con)
            write_jsonl(args.out_dir / f"{split}.jsonl", out_rows)
            split_counts[split] = dict(counts)
    finally:
        if tool_con is not None:
            tool_con.close()

    for name in ["scenario_tool_registry.json", "e2e_audit.json"]:
        src = args.benchmark_dir / name
        if src.exists():
            (args.out_dir / name).write_text(src.read_text(encoding="utf-8"), encoding="utf-8")

    manifest = {
        "source_benchmark_dir": str(args.benchmark_dir),
        "round": args.round,
        "solver_jsonl": [str(path) for path in (args.solver_jsonl or [])],
        "solved_id_count": len(solved),
        "all_rows_transformed": bool(args.all_rows),
        "split_counts": split_counts,
        "agentic_change": {
            "target_clarification_added_to_solver_solved_examples": not args.all_rows,
            "target_clarification_added_uniformly_to_all_examples": bool(args.all_rows),
            "coded_target_references": args.round in {"adv2", "adv3", "adv4", "adv5", "adv6", "adv7"},
            "indexed_target_references": args.round in {"adv3", "adv4", "adv5", "adv6", "adv7"},
            "explicit_candidate_enumeration_required": args.round in {"adv4", "adv5", "adv6", "adv7"},
            "target_quality_validation_required": args.round in {"adv5", "adv6", "adv7"},
            "raw_sample_verification_required": args.round in {"adv6", "adv7"},
            "sample_result_in_final_answer_required": args.round == "adv7",
        },
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
