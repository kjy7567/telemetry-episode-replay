#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from build_bts_test_penalty_experiment import load_jsonl, write_json, write_jsonl
from build_canonical_agentic_final import clone


TIMESTAMP_PHASES = {"timestamp_value_lookup", "timestamp_nearest_lookup", "timestamp_preference"}
QUALITY_PHASES = {"quality_gate", "quality_preference"}


def phase_examples(row: dict[str, Any]) -> list[dict[str, Any]]:
    return list(row.get("phase_examples") or [])


def phase_golds(row: dict[str, Any]) -> list[dict[str, Any]]:
    return list(row.get("phase_gold_final_answers") or [])


def family_names(row: dict[str, Any]) -> list[str]:
    return [str(example.get("task_family", "")) for example in phase_examples(row)]


def last_phase_match(row: dict[str, Any], families: set[str]) -> tuple[str, dict[str, Any]] | None:
    for example, gold in reversed(list(zip(phase_examples(row), phase_golds(row)))):
        family = str(example.get("task_family", ""))
        if family in families:
            return family, clone(gold)
    return None


def evidence_basis_prompt(row: dict[str, Any], evidence: dict[str, Any]) -> str:
    multi = len(evidence.get("stream_ids", [])) > 1 or row.get("task_family") in {"window_pairwise_compare", "window_rank"}
    subject = "streams or points" if multi else "stream or point"
    has_timestamp = bool(evidence.get("basis_observed_timestamp"))
    has_window = bool(evidence.get("basis_window_start")) and bool(evidence.get("basis_period"))
    has_point = any(evidence.get(key) for key in ["basis_equipment_label", "basis_point_label", "basis_location_label"])
    period = str(evidence.get("basis_period") or "")

    if has_timestamp and has_window:
        return f"Which {subject} and which timestamp or {period} basis did you use?"
    if has_timestamp:
        return f"Which {subject} and which timestamp basis did you use?"
    if has_window:
        if period in {"day", "week", "month"}:
            return f"Which {subject} and which {period} basis did you use?"
        return f"Which {subject} and which time-window basis did you use?"
    if has_point:
        return f"Which {subject} and which resolved point basis did you use?"
    return f"Which {subject} and which basis did you use?"


def family_native_reporting_prompt(row: dict[str, Any]) -> str:
    family = str(row.get("task_family", ""))
    if family in {"timestamp_value_lookup", "timestamp_nearest_lookup"}:
        return (
            "Considering the timestamped reading and any data-quality check we just discussed, should I report this reading as-is, "
            "abstain, or ask for a more precise timestamp before reporting it?"
        )
    if family in {"day_mean_lookup", "relative_24h_mean_lookup", "window_mean_lookup"}:
        return (
            "Considering the timestamped reading and the data-quality check we just discussed for this aggregate result, "
            "should I report this aggregate as-is, abstain, or ask for more time detail before reporting it?"
        )
    if family == "point_disambiguation":
        return (
            "Considering the timestamped reading and the data-quality check we just discussed for this resolved point, "
            "should I report this resolved reading as-is, abstain, or ask for more time detail before reporting it?"
        )
    if family in {"window_pairwise_compare", "window_rank"}:
        return (
            "Considering the timestamped reading and the data-quality check we just discussed for this chosen result, "
            "should I report this result as-is, abstain, or ask for more time detail before reporting it?"
        )
    if family == "quality_gate":
        return (
            "Considering the timestamped reading and the data-quality check we just discussed, should I report this "
            "result as-is, abstain, or ask for more time detail before reporting it?"
        )
    return "Considering the timestamped reading and the data-quality check we just discussed, should I report it as-is, abstain, or ask for more time detail before reporting it?"


def evidence_contract_for_row(row: dict[str, Any]) -> dict[str, Any]:
    evidence = clone(row.get("evidence", {}))
    if not evidence:
        return evidence

    timestamp_match = last_phase_match(row, TIMESTAMP_PHASES)
    quality_match = last_phase_match(row, QUALITY_PHASES)
    preference_match = last_phase_match(row, {"quality_preference", "timestamp_preference"})

    if timestamp_match is not None:
        _, gold = timestamp_match
        if isinstance(gold.get("observed_timestamp"), str):
            evidence["basis_observed_timestamp"] = gold["observed_timestamp"]
        if isinstance(gold.get("requested_timestamp"), str):
            evidence["basis_requested_timestamp"] = gold["requested_timestamp"]
        if isinstance(gold.get("stream_id"), str):
            evidence["basis_stream_id"] = gold["stream_id"]
    if quality_match is not None:
        _, gold = quality_match
        if gold.get("window_start") is not None:
            evidence["basis_window_start"] = gold["window_start"]
        if gold.get("period") is not None:
            evidence["basis_period"] = gold["period"]
        if gold.get("preferred_reference") is not None:
            evidence["basis_preferred_reference"] = gold["preferred_reference"]
        if isinstance(gold.get("stream_id"), str):
            evidence["basis_stream_id"] = gold["stream_id"]
    elif preference_match is not None:
        _, gold = preference_match
        if gold.get("preferred_reference") is not None:
            evidence["basis_preferred_reference"] = gold["preferred_reference"]
        if gold.get("window_start") is not None:
            evidence["basis_window_start"] = gold["window_start"]
        if gold.get("period") is not None:
            evidence["basis_period"] = gold["period"]
        if isinstance(gold.get("observed_timestamp"), str):
            evidence["basis_observed_timestamp"] = gold["observed_timestamp"]
        if isinstance(gold.get("stream_id"), str):
            evidence["basis_stream_id"] = gold["stream_id"]

    metadata = row.get("metadata", {})
    for key in ["equipment_label", "point_label", "location_label"]:
        value = metadata.get(key)
        if isinstance(value, str) and value.strip():
            evidence[f"basis_{key}"] = value
    return evidence


def transform_row(row: dict[str, Any]) -> dict[str, Any]:
    out = clone(row)
    evidence = evidence_contract_for_row(out)
    out["evidence"] = evidence

    prompt = evidence_basis_prompt(out, evidence)
    out["followup_prompt"] = prompt
    post = list(out.get("post_answer_user_turns", []))
    if post:
        post[-1] = prompt
    out["post_answer_user_turns"] = post

    goal_turns = list(out.get("goal_revision_turns", []))
    families = family_names(out)
    if families and families[-1] == "reporting_commitment" and goal_turns:
        goal_turns[-1] = family_native_reporting_prompt(out)
        out["goal_revision_turns"] = goal_turns

    metadata = clone(out.get("metadata", {}))
    metadata["test_penalty_v3_basis_evidence"] = True
    metadata["test_penalty_v3_family_native_reporting_prompt"] = True
    out["metadata"] = metadata
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-benchmark-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = [transform_row(row) for row in load_jsonl(args.source_benchmark_dir / "test.jsonl")]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output_dir / "train.jsonl", [])
    write_jsonl(args.output_dir / "dev.jsonl", [])
    write_jsonl(args.output_dir / "test.jsonl", rows)
    manifest = {
        "artifact_version": "canonical-v15-test-penalty-experiment-v3",
        "source_artifact_version": "canonical-v15-test-penalty-experiment",
        "row_count": len(rows),
        "split_counts": {"train": 0, "dev": 0, "test": len(rows)},
        "experiment_policy": {
            "name": "test_penalty_repair_v3",
            "repairs": [
                "evidence_followup_requires_stream_plus_basis",
                "family_native_reporting_commitment_prompt",
            ],
        },
    }
    write_json(args.output_dir / "manifest.json", manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
