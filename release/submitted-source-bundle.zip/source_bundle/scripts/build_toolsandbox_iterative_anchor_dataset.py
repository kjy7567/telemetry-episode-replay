#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = REPO_ROOT.parent
SRC_ROOT = REPO_ROOT / "src"
TOOLSANDBOX_ROOT = WORKSPACE_ROOT / "external" / "ToolSandbox"
for path in (SRC_ROOT, TOOLSANDBOX_ROOT):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from tool_sandbox.common.execution_context import DatabaseNamespace, get_current_context, set_current_context
from tool_sandbox.common.message_conversion import Message
from tool_sandbox.common.tool_discovery import ToolBackend
from tool_sandbox.roles.execution_environment import ExecutionEnvironment
from tool_sandbox.scenarios.insufficient_information_scenarios import named_insufficient_information_scenarios
from tool_sandbox.scenarios.single_tool_call_scenarios import named_single_tool_call_scenarios

from bts_agentbench.iterative_contract import contract_fields, contract_manifest_fields


SYSTEM_PROMPT = """You are a mobile assistant agent in a tool-using loop.

At each assistant turn, do exactly one of the following:
1. Return exactly one compact JSON tool action and nothing else:
   {"tool_name":"...", "arguments":{...}}
2. Answer the user in concise natural language when you have enough information.

Rules:
- Use only the allowed tools.
- Do not wrap the final answer in JSON.
- Ask for clarification only when the request is genuinely underspecified.
"""


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_candidate_scenarios() -> dict[str, Any]:
    scenarios: dict[str, Any] = {}
    scenarios.update(named_single_tool_call_scenarios(preferred_tool_backend=ToolBackend.DEFAULT))
    scenarios.update(named_insufficient_information_scenarios(preferred_tool_backend=ToolBackend.DEFAULT))
    return scenarios


def exact_trace_payload(scenario: Any) -> dict[str, Any] | None:
    for milestone in scenario.evaluation.milestone_matcher.milestones:
        for constraint in milestone.snapshot_constraints:
            if (
                constraint.database_namespace == DatabaseNamespace.SANDBOX
                and constraint.target_dataframe is not None
                and "tool_trace" in constraint.target_dataframe.columns
            ):
                rows = constraint.target_dataframe.to_dicts()
                if not rows:
                    continue
                return json.loads(rows[0]["tool_trace"])
    return None


def final_answer_target(scenario: Any) -> str | None:
    for milestone in scenario.evaluation.milestone_matcher.milestones:
        for constraint in milestone.snapshot_constraints:
            if (
                constraint.database_namespace == DatabaseNamespace.SANDBOX
                and constraint.target_dataframe is not None
                and {"sender", "recipient", "content"} <= set(constraint.target_dataframe.columns)
            ):
                rows = constraint.target_dataframe.to_dicts()
                for row in rows:
                    if row["sender"] == "AGENT" and row["recipient"] == "USER":
                        return str(row["content"]).strip()
    return None


def current_task_user_message(scenario: Any) -> str:
    db = scenario.starting_context.get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    rows = db.select(["sender", "recipient", "content"]).to_dicts()
    for row in reversed(rows):
        if row["sender"] == "USER" and row["recipient"] == "AGENT":
            return str(row["content"]).strip()
    raise ValueError("No USER->AGENT message found in scenario")


def system_messages_for_agent(scenario: Any) -> list[str]:
    db = scenario.starting_context.get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    rows = db.select(["sender", "recipient", "content"]).to_dicts()
    messages: list[str] = []
    for row in rows:
        if row["sender"] == "SYSTEM" and row["recipient"] == "AGENT":
            messages.append(str(row["content"]).strip())
    return messages


def tool_python_call(tool_name: str, arguments: dict[str, Any]) -> str:
    args_text = json.dumps(arguments, ensure_ascii=False)
    return (
        f"tool_parameters = {args_text}\n"
        f"tool_response = {tool_name}(**tool_parameters)\n"
        f"print(repr(tool_response))"
    )


def prepare_execution_environment(scenario: Any) -> ExecutionEnvironment:
    execution_context = copy.deepcopy(scenario.starting_context)
    set_current_context(execution_context)
    role = ExecutionEnvironment()
    sandbox_db = execution_context.get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    max_index = execution_context.max_sandbox_message_index
    for message_index in range(max_index + 1):
        if (
            sandbox_db["recipient"][message_index] == "EXECUTION_ENVIRONMENT"
            and sandbox_db["sender"][message_index] == "SYSTEM"
        ):
            role.respond(ending_index=message_index)
    return role


def execute_tool_result_text(scenario: Any, payload: dict[str, Any]) -> str:
    role = prepare_execution_environment(scenario)
    message = Message(
        sender="AGENT",
        recipient="EXECUTION_ENVIRONMENT",
        content=tool_python_call(payload["tool_name"], payload.get("arguments", {})),
    )
    role.add_messages([message])
    role.respond()
    sandbox_db = get_current_context().get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    rows = sandbox_db.select(["sender", "recipient", "content"]).to_dicts()
    for row in reversed(rows):
        if row["sender"] == "EXECUTION_ENVIRONMENT" and row["recipient"] == "AGENT":
            return str(row["content"]).strip()
    return "Tool result unavailable."


def build_rows_for_scenario(name: str, scenario: Any, split: str) -> list[dict[str, Any]]:
    payload = exact_trace_payload(scenario)
    answer = final_answer_target(scenario)
    if payload is None or answer is None:
        return []
    user_query = current_task_user_message(scenario)
    tool_result = execute_tool_result_text(scenario, payload)
    extra_system = system_messages_for_agent(scenario)
    system_messages = [{"role": "system", "content": SYSTEM_PROMPT}] + [
        {"role": "system", "content": text} for text in extra_system
    ]
    metadata = {
        "available_tools": [tool for tool in (scenario.starting_context.tool_allow_list or []) if tool != "end_conversation"],
        "scenario_name": name,
    }
    tool_payload_text = json.dumps(
        {"tool_name": payload["tool_name"], "arguments": payload.get("arguments", {})},
        ensure_ascii=False,
    )
    base = {
        "scenario_id": f"toolsandbox_{name}",
        "split": split,
        "task_family": "toolsandbox_exact_trace",
        "site_id": "toolsandbox",
        "track": "toolsandbox_e2e",
        "source": "anchor",
        "query": user_query,
        "metadata": metadata,
    }
    return [
        {
            **base,
            "stage": "tool_call",
            "step_index": 1,
            **contract_fields("tool_call"),
            "messages": system_messages
            + [
                {"role": "user", "content": user_query},
                {"role": "assistant", "content": tool_payload_text},
            ],
        },
        {
            **base,
            "stage": "final_answer",
            "step_index": 2,
            **contract_fields("final_answer"),
            "messages": system_messages
            + [
                {"role": "user", "content": user_query},
                {"role": "assistant", "content": tool_payload_text},
                {"role": "user", "content": f"Tool result: {tool_result}"},
                {"role": "assistant", "content": answer},
            ],
        },
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    candidates = load_candidate_scenarios()
    eligible = sorted(
        [
            (name, scenario)
            for name, scenario in candidates.items()
            if exact_trace_payload(scenario) is not None and final_answer_target(scenario) is not None
        ],
        key=lambda item: item[0],
    )

    split_point = max(1, int(round(len(eligible) * 0.8)))
    train_candidates = eligible[:split_point]
    dev_candidates = eligible[split_point:]

    train_rows: list[dict[str, Any]] = []
    dev_rows: list[dict[str, Any]] = []
    for name, scenario in train_candidates:
        train_rows.extend(build_rows_for_scenario(name, scenario, "train"))
    for name, scenario in dev_candidates:
        dev_rows.extend(build_rows_for_scenario(name, scenario, "dev"))

    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)
    stage_counts_train = dict(Counter(row["stage"] for row in train_rows))
    manifest = {
        "track": "toolsandbox_e2e",
        "source": "iterative_anchor_exact_trace_subset",
        "eligible_scenarios": len(eligible),
        "train_scenarios": [name for name, _ in train_candidates],
        "dev_scenarios": [name for name, _ in dev_candidates],
        "train_examples": len(train_rows),
        "dev_examples": len(dev_rows),
        "stage_counts_train": stage_counts_train,
        "benchmark_source": str(TOOLSANDBOX_ROOT),
        "author_defined_split": True,
        **contract_manifest_fields(stage_counts_train),
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
