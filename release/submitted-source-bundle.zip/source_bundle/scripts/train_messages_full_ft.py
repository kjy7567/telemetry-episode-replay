#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from datasets import Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments


IGNORE_INDEX = -100


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def render_chat(tokenizer: AutoTokenizer, messages: list[dict[str, str]], add_generation_prompt: bool) -> str:
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
            enable_thinking=False,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )


def encode_chat_example(example: dict[str, Any], tokenizer: AutoTokenizer, max_length: int) -> dict[str, Any]:
    prompt_text = render_chat(tokenizer, example["messages"][:-1], add_generation_prompt=True)
    full_text = render_chat(tokenizer, example["messages"], add_generation_prompt=False)
    prompt_ids = tokenizer(prompt_text, add_special_tokens=False).input_ids
    full_ids = tokenizer(full_text, add_special_tokens=False).input_ids

    if len(full_ids) >= len(prompt_ids) and full_ids[: len(prompt_ids)] == prompt_ids:
        response_ids = full_ids[len(prompt_ids) :]
    else:
        response_ids = []
        full_ids = full_ids[:max_length]
        input_ids = full_ids
        attention_mask = [1] * len(input_ids)
        labels = input_ids.copy()
        prompt_len = min(len(prompt_ids), len(labels))
        labels[:prompt_len] = [IGNORE_INDEX] * prompt_len
        supervised_token_count = sum(1 for token in labels if token != IGNORE_INDEX)
        return {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "labels": labels,
            "sample_weight": float(example.get("sample_weight", 1.0)),
            "scenario_id": example.get("scenario_id"),
            "task_family": example.get("task_family"),
            "site_id": example.get("site_id"),
            "source": example.get("source", "unknown"),
            "query": example.get("query"),
            "stage": example.get("stage"),
            "supervised_token_count": supervised_token_count,
        }

    if len(response_ids) >= max_length:
        input_ids = response_ids[-max_length:]
        labels = input_ids.copy()
    else:
        kept_prompt_len = max_length - len(response_ids)
        kept_prompt_ids = prompt_ids[-kept_prompt_len:] if kept_prompt_len > 0 else []
        input_ids = kept_prompt_ids + response_ids
        labels = [IGNORE_INDEX] * len(kept_prompt_ids) + response_ids.copy()

    attention_mask = [1] * len(input_ids)
    supervised_token_count = len(response_ids[-max_length:]) if len(response_ids) >= max_length else len(response_ids)
    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels,
        "sample_weight": float(example.get("sample_weight", 1.0)),
        "scenario_id": example.get("scenario_id"),
        "task_family": example.get("task_family"),
        "site_id": example.get("site_id"),
        "source": example.get("source", "unknown"),
        "query": example.get("query"),
        "stage": example.get("stage"),
        "supervised_token_count": supervised_token_count,
    }


class PackedDataCollator:
    def __init__(self, tokenizer: AutoTokenizer):
        self.pad_id = tokenizer.pad_token_id

    def __call__(self, features: list[dict[str, Any]]) -> dict[str, torch.Tensor]:
        max_len = max(len(feature["input_ids"]) for feature in features)
        input_ids = []
        attention_mask = []
        labels = []
        sample_weight = []
        for feature in features:
            pad = max_len - len(feature["input_ids"])
            input_ids.append(feature["input_ids"] + [self.pad_id] * pad)
            attention_mask.append(feature["attention_mask"] + [0] * pad)
            labels.append(feature["labels"] + [IGNORE_INDEX] * pad)
            sample_weight.append(float(feature.get("sample_weight", 1.0)))
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "sample_weight": torch.tensor(sample_weight, dtype=torch.float32),
        }


class WeightedSFTTrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        labels = inputs.pop("labels")
        sample_weight = inputs.pop("sample_weight", None)
        outputs = model(**inputs)
        logits = outputs.logits

        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()
        token_loss = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
            reduction="none",
            ignore_index=IGNORE_INDEX,
        ).view(shift_labels.size())
        valid_mask = (shift_labels != IGNORE_INDEX).float()
        per_example_den = valid_mask.sum(dim=1).clamp(min=1.0)
        per_example_loss = (token_loss * valid_mask).sum(dim=1) / per_example_den

        if sample_weight is not None:
            weight = sample_weight.to(per_example_loss.device)
            loss = (per_example_loss * weight).sum() / weight.sum().clamp(min=1e-6)
        else:
            loss = per_example_loss.mean()

        return (loss, outputs) if return_outputs else loss


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--train-jsonl", type=Path, required=True)
    parser.add_argument("--dev-jsonl", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-length", type=int, default=1152)
    parser.add_argument("--num-train-epochs", type=float, default=1.0)
    parser.add_argument("--learning-rate", type=float, default=1e-5)
    parser.add_argument("--per-device-train-batch-size", type=int, default=1)
    parser.add_argument("--per-device-eval-batch-size", type=int, default=1)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=8)
    parser.add_argument("--logging-steps", type=int, default=10)
    parser.add_argument("--save-total-limit", type=int, default=2)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(str(args.model))
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_rows = load_jsonl(args.train_jsonl)
    dev_rows = load_jsonl(args.dev_jsonl)

    raw_train_records = [encode_chat_example(row, tokenizer, args.max_length) for row in train_rows]
    raw_dev_records = [encode_chat_example(row, tokenizer, args.max_length) for row in dev_rows]

    train_dropped = sum(1 for record in raw_train_records if record["supervised_token_count"] == 0)
    dev_dropped = sum(1 for record in raw_dev_records if record["supervised_token_count"] == 0)

    train_records = [record for record in raw_train_records if record["supervised_token_count"] > 0]
    dev_records = [record for record in raw_dev_records if record["supervised_token_count"] > 0]

    train_dataset = Dataset.from_list(train_records)
    dev_dataset = Dataset.from_list(dev_records)

    model = AutoModelForCausalLM.from_pretrained(
        str(args.model),
        torch_dtype=torch.bfloat16,
    )
    model.config.use_cache = False
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

    training_args = TrainingArguments(
        output_dir=str(args.out_dir),
        overwrite_output_dir=True,
        num_train_epochs=args.num_train_epochs,
        learning_rate=args.learning_rate,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        bf16=True,
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=args.save_total_limit,
        logging_steps=args.logging_steps,
        report_to=[],
        disable_tqdm=True,
        remove_unused_columns=False,
        dataloader_pin_memory=False,
        optim="adamw_torch",
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
    )

    trainer = WeightedSFTTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=dev_dataset,
        data_collator=PackedDataCollator(tokenizer),
    )

    manifest = {
        "base_model": str(args.model),
        "train_jsonl": str(args.train_jsonl),
        "dev_jsonl": str(args.dev_jsonl),
        "train_examples": len(train_records),
        "dev_examples": len(dev_records),
        "train_examples_raw": len(raw_train_records),
        "dev_examples_raw": len(raw_dev_records),
        "train_examples_dropped_zero_supervision": train_dropped,
        "dev_examples_dropped_zero_supervision": dev_dropped,
        "train_sample_weight_mean": sum(record["sample_weight"] for record in train_records) / len(train_records) if train_records else 0.0,
        "dev_sample_weight_mean": sum(record["sample_weight"] for record in dev_records) / len(dev_records) if dev_records else 0.0,
        "max_length": args.max_length,
        "num_train_epochs": args.num_train_epochs,
        "learning_rate": args.learning_rate,
        "gradient_accumulation_steps": args.gradient_accumulation_steps,
        "per_device_train_batch_size": args.per_device_train_batch_size,
        "tuning_mode": "full_finetune",
    }
    (args.out_dir / "training_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    trainer.train()
    trainer.save_model()
    tokenizer.save_pretrained(args.out_dir)

    metrics = trainer.evaluate()
    (args.out_dir / "final_eval_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
