#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any

from bts_agentbench.iterative_contract import (
    ITERATIVE_DECISION_CONTRACT_VERSION,
    ITERATIVE_DECISION_PROBLEM,
    ITERATIVE_DECISION_TYPES,
    decision_type_for_stage,
    response_format_for_stage,
)


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def audit_dataset(track: str, dataset_dir: Path) -> dict[str, Any]:
    rows = load_jsonl(dataset_dir / "train.jsonl")
    errors: list[str] = []
    decision_counts = Counter()
    response_counts = Counter()
    for row in rows:
        stage = row.get("stage")
        expected_decision = decision_type_for_stage(stage)
        expected_format = response_format_for_stage(stage)
        if row.get("contract_version") != ITERATIVE_DECISION_CONTRACT_VERSION:
            errors.append(f"{row['scenario_id']}:wrong_contract_version")
        if row.get("decision_problem") != ITERATIVE_DECISION_PROBLEM:
            errors.append(f"{row['scenario_id']}:wrong_decision_problem")
        if row.get("decision_type") != expected_decision:
            errors.append(f"{row['scenario_id']}:wrong_decision_type")
        if row.get("response_format") != expected_format:
            errors.append(f"{row['scenario_id']}:wrong_response_format")
        if row.get("available_decision_types") != list(ITERATIVE_DECISION_TYPES):
            errors.append(f"{row['scenario_id']}:wrong_available_decisions")
        decision_counts[row.get("decision_type")] += 1
        response_counts[row.get("response_format")] += 1
    return {
        "track": track,
        "dataset_dir": str(dataset_dir),
        "train_rows": len(rows),
        "decision_type_counts_train": dict(decision_counts),
        "response_format_counts_train": dict(response_counts),
        "error_count": len(errors),
        "sample_errors": errors[:20],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bts-dir", type=Path, required=True)
    parser.add_argument("--tau-dir", type=Path, required=True)
    parser.add_argument("--toolsandbox-dir", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    args = parser.parse_args()

    summary = {
        "contract_version": ITERATIVE_DECISION_CONTRACT_VERSION,
        "decision_problem": ITERATIVE_DECISION_PROBLEM,
        "tracks": [
            audit_dataset("bts_e2e", args.bts_dir),
            audit_dataset("tau_retail_e2e", args.tau_dir),
            audit_dataset("toolsandbox_e2e", args.toolsandbox_dir),
        ],
    }
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
