#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any

from bts_agentbench.clarify_policy import clarify_policy_manifest_fields
from bts_agentbench.iterative_contract import contract_fields, contract_manifest_fields
from bts_agentbench.operator_answer import render_operator_answer
from bts_agentbench.runtime import ToolStoreRuntime
from bts_agentbench.bts_e2e import (
    FOLLOWUP_PROMPT,
    RATIONALE_FOLLOWUP_PROMPT,
    evidence_followup_prompt,
    time_reference_question,
)


SYSTEM_PROMPT = """You are a building-operations agent in a multi-turn conversation with an operator.

You may do exactly one of the following at each assistant turn:
1. Ask the operator a short clarification question if a required site, date, week, month, or timestamp is missing.
2. Return exactly one compact JSON tool action and nothing else:
   {"tool_name":"...", "arguments":{...}}
3. Answer the operator in concise natural language once you have enough information.

Additional rules:
- Tool results will appear as later user messages prefixed with "Tool result:".
- Do not wrap the final operator answer in JSON.
- When a prior tool result already contains a `stream_id` or `stream_ids`, you may refer to it in later tool calls as `$e1.stream_id` or `$e1.stream_ids` instead of copying long values.
- Use the exact tool schemas below. Do not invent alias argument names such as `date_range_start` or `date_range_end`.
- resolve_point arguments: `site_id`, `point_class`, `equipment_label`, optional `location_label`
- list_points arguments: `site_id`, `point_class`, `location_type`
- aggregate_window arguments: `stream_id`, `metric`, `window_start`, `window_end`, `period`
- compare_window arguments: `left_stream_id`, `right_stream_id`, `metric`, `window_start`, `window_end`, `period`
- rank_window arguments: `stream_ids`, `metric`, `window_start`, `window_end`, `period`, `order`, `topk`
- lookup_observation arguments: `stream_id`, `timestamp`, `mode`
- inspect_quality arguments: `stream_id`
- inspect_quality_window arguments: `stream_id`, `window_start`, `window_end`, `period`
- After `aggregate_window`, answer with the returned `mean_value`.
- Calendar windows are half-open. For a month, use the first day of that month as `window_start` and the first day of the next month as `window_end`; do not use the last day of the month as `window_end`.
- For ranking questions, first call `list_points`, then call `rank_window` with the returned `stream_ids`; never answer from `list_points` alone.
- After `rank_window`, answer with `ranked_streams[0]` and include the exact winning `stream_id` and its `mean_value` when the operator asks which stream is top.
- For `list_points`, `location_type` is a category such as `Location`, `Room`, or `Conference_Room`; never use a site id such as `BTS_A`, `BTS_B`, or `BTS_C` as `location_type`.
- After `lookup_observation` with `mode: "exact"`, report the exact returned value. Preserve fractional seconds in timestamps. If the tool result says `exact_match_found` is false, say there was no exact logged reading and do not invent a nearby value unless the task explicitly asks for a nearby reading.
- For `timestamp_nearest_lookup`, use `lookup_observation` with `mode: "nearest"` and report the returned nearby timestamp and value.
- `inspect_quality` is a stream-level quality summary. `inspect_quality_window` is the time-bounded quality tool for a specific day, week, or month.
- For quality-gate questions, call `inspect_quality_window` for the requested week after resolving the point. Use its `quality_reference`: abstain if `observed_fraction` is below `abstain_observed_fraction_below` or `gap_ratio` is above `abstain_gap_ratio_above`; answer only if the metrics satisfy the answer thresholds. Explicitly say either "I would answer" or "I would abstain" and cite observed coverage and gap ratio.
- If the operator asks which stream or point you used, answer directly in natural language and include the exact stream_id you actually used.
- If the operator asks why you would answer or abstain, explain the quality-based reason directly in natural language.
- If a time reference is missing, ask for the specific missing unit the task needs, such as a date, week, month, time window, or exact timestamp. For timestamp tasks, ask for the exact timestamp including fractional seconds if available.
- Do not invent stream_ids, timestamps, or values.
"""

def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def clarification_question(example: dict[str, Any], slot: str) -> str:
    custom_questions = example.get("clarification_questions", {})
    if slot in custom_questions:
        return str(custom_questions[slot])
    if slot == "site_id":
        return "Which site or building is this in?"
    return time_reference_question(example)


def evidence_answer(example: dict[str, Any], runtime: ToolStoreRuntime) -> str:
    stream_ids = example.get("evidence", {}).get("stream_ids", [])
    if not stream_ids:
        return "I did not use a specific stream."
    descriptions = []
    for stream_id in stream_ids:
        description = runtime.describe_stream(stream_id)
        equipment = description.get("equipment_label")
        location = description.get("location_label")
        if equipment and location:
            descriptions.append(f"stream {stream_id} for {equipment} serving {location}")
        elif equipment:
            descriptions.append(f"stream {stream_id} for {equipment}")
        elif location:
            descriptions.append(f"stream {stream_id} for the point serving {location}")
        else:
            descriptions.append(f"stream {stream_id}")
    if len(descriptions) == 1:
        return f"I used {descriptions[0]}."
    return "I used " + "; ".join(descriptions) + "."


def quality_rationale_answer(example: dict[str, Any]) -> str:
    gold = example["gold_final_answer"]
    if gold["decision"] == "abstain":
        return (
            f"I would abstain because the signal quality is not reliable enough. "
            f"Observed coverage was {gold['observed_fraction']} and the gap ratio was {gold['gap_ratio']}."
        )
    return (
        f"I would answer because the signal looks healthy enough. "
        f"Observed coverage was {gold['observed_fraction']} and the gap ratio was {gold['gap_ratio']}."
    )


def reference_candidates(executed_calls: list[Any]) -> list[tuple[Any, str]]:
    refs: list[tuple[Any, str]] = []
    for call in executed_calls:
        for field in ("stream_id", "stream_ids"):
            if field in call.output:
                refs.append((call.output[field], f"${call.call_id}.{field}"))
    return refs


def compactify_arguments(arguments: dict[str, Any], executed_calls: list[Any]) -> dict[str, Any]:
    refs = reference_candidates(executed_calls)

    def replace(value: Any) -> Any:
        for candidate, ref in refs:
            if value == candidate:
                return ref
        if isinstance(value, list):
            return [replace(v) for v in value]
        if isinstance(value, dict):
            return {k: replace(v) for k, v in value.items()}
        return value

    return replace(arguments)


def base_record(example: dict[str, Any], stage: str, step_index: int, history: list[dict[str, str]]) -> dict[str, Any]:
    available_tools = sorted({call["tool_name"] for call in example.get("canonical_tool_calls", [])})
    return {
        "scenario_id": example["scenario_id"],
        "split": example["split"],
        "task_family": example["task_family"],
        "site_id": example["site_id"],
        "track": "bts_e2e",
        "source": "anchor",
        "stage": stage,
        "step_index": step_index,
        "interaction_mode": example["interaction_mode"],
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}] + history,
        "query": example["initial_user_message"],
        "metadata": {
            "available_tools": available_tools,
            "hidden_user_instruction": example["hidden_user_instruction"],
            "clarification_slot": (
                example["required_clarification_slots"][step_index - 1]
                if stage == "clarification_question"
                and step_index <= len(example.get("required_clarification_slots", []))
                else None
            ),
        },
        **contract_fields(stage),
    }


def build_rows_for_example(example: dict[str, Any], runtime: ToolStoreRuntime) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    history: list[dict[str, str]] = [{"role": "user", "content": example["initial_user_message"]}]
    step_index = 1

    for slot in example.get("required_clarification_slots", []):
        question = clarification_question(example, slot)
        record = base_record(
            example,
            "clarification_question",
            step_index,
            history + [{"role": "assistant", "content": question}],
        )
        rows.append(record)
        history.extend(
            [
                {"role": "assistant", "content": question},
                {"role": "user", "content": example["clarification_answers"][slot]},
            ]
        )
        step_index += 1

    executed = runtime.execute_call_sequence(example["canonical_tool_calls"])
    compact_history: list[Any] = []
    for idx, call in enumerate(executed, start=1):
        call = call.__class__(
            call_id=f"e{idx}",
            tool_name=call.tool_name,
            arguments=call.arguments,
            output=call.output,
        )
        compact_arguments = compactify_arguments(call.arguments, compact_history)
        tool_payload = json.dumps(
            {
                "tool_name": call.tool_name,
                "arguments": compact_arguments,
            },
            ensure_ascii=False,
        )
        record = base_record(example, "tool_call", step_index, history + [{"role": "assistant", "content": tool_payload}])
        rows.append(record)
        history.extend(
            [
                {"role": "assistant", "content": tool_payload},
                {"role": "user", "content": f"Tool result: {ToolStoreRuntime.compact_observation(call)}"},
            ]
        )
        compact_history.append(call)
        step_index += 1

    final_answer = render_operator_answer(example, example["gold_final_answer"], runtime)
    rows.append(base_record(example, "final_answer", step_index, history + [{"role": "assistant", "content": final_answer}]))
    history.append({"role": "assistant", "content": final_answer})
    step_index += 1

    default_followup = example.get("followup_prompt", evidence_followup_prompt(example))
    for prompt in example.get("post_answer_user_turns", [default_followup]):
        history.append({"role": "user", "content": prompt})
        if prompt == default_followup:
            answer = evidence_answer(example, runtime)
            stage = "evidence_followup_answer"
        elif prompt == RATIONALE_FOLLOWUP_PROMPT:
            answer = quality_rationale_answer(example)
            stage = "rationale_followup_answer"
        else:
            answer = "I used the observed tool outputs to answer that."
            stage = "followup_answer"
        rows.append(base_record(example, stage, step_index, history + [{"role": "assistant", "content": answer}]))
        history.append({"role": "assistant", "content": answer})
        step_index += 1

    return rows


def build_split_rows(split_path: Path, runtime: ToolStoreRuntime) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for example in load_jsonl(split_path):
        rows.extend(build_rows_for_example(example, runtime))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    runtime = ToolStoreRuntime(args.tool_store_db)
    try:
        train_rows = build_split_rows(args.benchmark_dir / "train.jsonl", runtime)
        dev_rows = build_split_rows(args.benchmark_dir / "dev.jsonl", runtime)
    finally:
        runtime.close()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)
    stage_counts_train = dict(Counter(row["stage"] for row in train_rows))
    manifest = {
        "track": "bts_e2e",
        "train_examples": len(train_rows),
        "dev_examples": len(dev_rows),
        "source": "iterative_anchor",
        "stage_counts_train": stage_counts_train,
        "interaction_modes_train": dict(Counter(row["interaction_mode"] for row in train_rows)),
        "benchmark_dir": str(args.benchmark_dir),
        "tool_store_db": str(args.tool_store_db),
        **contract_manifest_fields(stage_counts_train),
        **clarify_policy_manifest_fields(
            clarify_count=stage_counts_train.get("clarification_question", 0),
            clarify_scope="serialized_bts_hidden_state",
        ),
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
