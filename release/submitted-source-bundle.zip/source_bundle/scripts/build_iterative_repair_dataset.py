#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any

from bts_agentbench.operator_answer import render_operator_answer
from bts_agentbench.runtime import ToolStoreRuntime
from bts_agentbench.taskbench_export import load_jsonl


SYSTEM_PROMPT = """You are a building-operations tool-using agent.

Solve each scenario by choosing one tool action at a time, or by answering the operator directly once you have enough information.

Available tools:
- resolve_point(site_id, point_class, equipment_label, location_label?)
- list_points(site_id, point_class?, equipment_type?, location_type?)
- aggregate_window(stream_id, metric, window_start, window_end, period)
- compare_window(left_stream_id, right_stream_id, metric, window_start, window_end, period)
- rank_window(stream_ids, metric, window_start, window_end, period, order, topk)
- lookup_observation(stream_id, timestamp, mode)
- inspect_quality(stream_id)
- inspect_quality_window(stream_id, window_start, window_end, period)

Rules:
1. If you still need a tool, return exactly one compact JSON action and nothing else:
   {"tool_name":"...", "arguments":{...}}
2. Once you have enough information, answer in concise natural language for the operator.
3. Do not return the final operator answer as JSON.
4. Reuse exact stream_id values from observations when available.
5. Do not invent stream_ids, timestamps, or values.
6. If there is no exact timestamp match, use lookup_observation with mode "nearest".
7. Prefer resolve_point when the question already names a concrete equipment_label or location_label.
8. Use list_points mainly when the question asks over a group, such as "among ... points located in Room".
9. Questions may paraphrase point classes and compress equipment names. Map natural phrases like "temperature reading", "weekly average", or "FCU 003" back to canonical tool arguments before calling a tool.
10. For weekly quality-decision questions, use inspect_quality_window with the requested week rather than inspect_quality.
"""


def scenario_messages(example: dict[str, Any], observations: list[str]) -> list[dict[str, str]]:
    obs_block = "\n".join(f"- {obs}" for obs in observations) if observations else "- none yet"
    user_payload = (
        f"Operator request: {example['query']}\n"
        f"Observed tool results so far:\n{obs_block}"
    )
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_payload},
    ]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def benchmark_index(benchmark_dirs: list[Path]) -> dict[str, dict[str, Any]]:
    index: dict[str, dict[str, Any]] = {}
    for benchmark_dir in benchmark_dirs:
        for split in ["train", "dev", "test"]:
            for row in load_jsonl(benchmark_dir / f"{split}.jsonl"):
                index[row["scenario_id"]] = row
    return index


def stepwise_rows_from_path(
    example: dict[str, Any],
    tool_calls: list[dict[str, Any]],
    final_answer: dict[str, Any] | str,
    evidence: dict[str, Any] | None,
    runtime: ToolStoreRuntime,
    source: str,
) -> list[dict[str, Any]]:
    operator_answer = (
        final_answer
        if isinstance(final_answer, str)
        else render_operator_answer(example, final_answer, runtime)
    )
    rows: list[dict[str, Any]] = []
    observations: list[str] = []
    executed = runtime.execute_call_sequence(tool_calls)
    for idx, call in enumerate(executed, start=1):
        rows.append(
            {
                "scenario_id": example["scenario_id"],
                "split": example["split"],
                "task_family": example["task_family"],
                "site_id": example["site_id"],
                "source": source,
                "stage": "tool_call",
                "step_index": idx,
                "messages": scenario_messages(example, list(observations))
                + [
                    {
                        "role": "assistant",
                        "content": json.dumps(
                            {
                                "tool_name": call.tool_name,
                                "arguments": call.arguments,
                            },
                            ensure_ascii=False,
                        ),
                    }
                ],
                "query": example["query"],
            }
        )
        observations.append(ToolStoreRuntime.compact_observation(call))

    rows.append(
        {
            "scenario_id": example["scenario_id"],
            "split": example["split"],
            "task_family": example["task_family"],
            "site_id": example["site_id"],
            "source": source,
            "stage": "final_answer",
            "step_index": len(executed) + 1,
            "messages": scenario_messages(example, list(observations))
            + [
                {
                    "role": "assistant",
                    "content": operator_answer,
                }
            ],
            "query": example["query"],
        }
    )
    return rows


def build_anchor_rows(benchmark_dirs: list[Path], split: str, runtimes: dict[str, ToolStoreRuntime]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for benchmark_dir in benchmark_dirs:
        for example in load_jsonl(benchmark_dir / f"{split}.jsonl"):
            corpus = corpus_name_from_benchmark_dir(benchmark_dir)
            rows.extend(
                stepwise_rows_from_path(
                    example,
                    example["canonical_tool_calls"],
                    example["gold_final_answer"],
                    example["evidence"],
                    runtimes[corpus],
                    source="anchor",
                )
            )
    return rows


def corpus_name_from_benchmark_dir(benchmark_dir: Path) -> str:
    path = str(benchmark_dir)
    if "xai4heat" in path:
        return "xai4heat"
    if "pleia" in path:
        return "pleia"
    return "bts"


def build_repair_rows(
    repair_jsonls: list[Path],
    benchmark_examples: dict[str, dict[str, Any]],
    runtimes: dict[str, ToolStoreRuntime],
    repeat_default: int,
    repeat_map: dict[str, int],
) -> tuple[list[dict[str, Any]], Counter]:
    rows: list[dict[str, Any]] = []
    stats: Counter = Counter()
    for path in repair_jsonls:
        for raw in load_jsonl(path):
            scenario_id = raw["scenario_id"]
            example = benchmark_examples[scenario_id]
            assistant_payload = json.loads(raw["messages"][-1]["content"])
            tool_calls = assistant_payload["tool_calls"]
            final_answer = assistant_payload["final_answer"]
            evidence = assistant_payload.get("evidence", {})
            mode = raw.get("adaptation_mode", "repair_with_gold")
            repeat = repeat_map.get(mode, repeat_default)
            corpus = raw.get("site_id", example["site_id"])
            corpus_name = "xai4heat" if str(corpus).startswith("XAI4HEAT") else ("pleia" if str(corpus).startswith("PLEIA") else "bts")
            step_rows = stepwise_rows_from_path(example, tool_calls, final_answer, evidence, runtimes[corpus_name], source="repair")
            for _ in range(max(repeat, 0)):
                rows.extend(step_rows)
            stats[mode] += 1
    return rows, stats


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, action="append", required=True)
    parser.add_argument("--bts-tool-store-db", type=Path, required=True)
    parser.add_argument("--xai4heat-tool-store-db", type=Path, required=True)
    parser.add_argument("--pleia-tool-store-db", type=Path, required=True)
    parser.add_argument("--repair-jsonl", type=Path, action="append", default=[])
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--repair-default-repeat", type=int, default=3)
    parser.add_argument("--repair-with-gold-repeat", type=int, default=5)
    parser.add_argument("--prefix-repair-repeat", type=int, default=4)
    parser.add_argument("--retain-teacher-repeat", type=int, default=2)
    args = parser.parse_args()

    runtimes = {
        "bts": ToolStoreRuntime(args.bts_tool_store_db),
        "xai4heat": ToolStoreRuntime(args.xai4heat_tool_store_db),
        "pleia": ToolStoreRuntime(args.pleia_tool_store_db),
    }
    try:
        benchmark_examples = benchmark_index(args.benchmark_dir)
        train_anchor_rows = build_anchor_rows(args.benchmark_dir, "train", runtimes)
        dev_anchor_rows = build_anchor_rows(args.benchmark_dir, "dev", runtimes)
        repair_rows, repair_stats = build_repair_rows(
            args.repair_jsonl,
            benchmark_examples,
            runtimes,
            repeat_default=args.repair_default_repeat,
            repeat_map={
                "repair_with_gold": args.repair_with_gold_repeat,
                "prefix_repair_with_gold": args.prefix_repair_repeat,
                "retain_teacher": args.retain_teacher_repeat,
            },
        )
    finally:
        for runtime in runtimes.values():
            runtime.close()

    train_rows = train_anchor_rows + repair_rows
    dev_rows = dev_anchor_rows
    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)
    summary = {
        "train_examples": len(train_rows),
        "dev_examples": len(dev_rows),
        "source_counts": dict(Counter(row["source"] for row in train_rows)),
        "stage_counts": dict(Counter(row["stage"] for row in train_rows)),
        "repair_stats": dict(repair_stats),
        "benchmark_dirs": [str(path) for path in args.benchmark_dir],
        "repair_jsonl": [str(path) for path in args.repair_jsonl],
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
