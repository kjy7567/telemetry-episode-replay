#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.pleia import load_pleia_tables
from bts_agentbench.scenario_benchmark import generate_scenario_benchmark
from bts_agentbench.tabular_corpus import build_tool_store_from_tabular_corpus


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip-path", type=Path, required=True)
    parser.add_argument("--tool-store-dir", type=Path, required=True)
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--heldout-site-id", action="append", default=["PLEIA_C"])
    args = parser.parse_args()

    metadata, observations = load_pleia_tables(args.zip_path)
    preprocess_summary = build_tool_store_from_tabular_corpus(
        metadata=metadata,
        observations=observations,
        out_dir=args.tool_store_dir,
        source_name="pleia",
    )
    manifest = generate_scenario_benchmark(
        args.tool_store_dir / "tool_store.duckdb",
        args.benchmark_dir,
        heldout_site_ids=args.heldout_site_id,
        include_families=[
            "point_disambiguation",
            "day_mean_lookup",
            "relative_24h_mean_lookup",
            "window_mean_lookup",
            "window_pairwise_compare",
            "window_rank",
            "timestamp_value_lookup",
            "timestamp_nearest_lookup",
        ],
    )
    print(
        json.dumps(
            {
                "preprocess_summary": preprocess_summary,
                "benchmark_manifest": manifest,
            },
            indent=2,
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
