#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from collections import Counter
from pathlib import Path
from types import ModuleType
from typing import Any

from bts_agentbench.bts_e2e import TIME_CLARIFICATION_SLOT, SITE_CLARIFICATION_SLOT, audit_bts_e2e, build_bts_e2e, load_jsonl, temporal_clarification_class, write_jsonl


REPO_ROOT = Path(__file__).resolve().parents[1]
SPLITS = ("train", "dev", "test")


def load_module(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"could not load module from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def patched_interaction_mode(row: dict[str, Any]) -> str:
    slots = list(row.get("required_clarification_slots", []))
    if "quality_decision" in str(row.get("interaction_mode", "")):
        if SITE_CLARIFICATION_SLOT in slots:
            return "clarify_site_then_quality_decision_then_rationale_then_evidence"
        return "quality_decision_then_rationale_then_evidence"
    if row.get("task_family") == "timestamp_nearest_lookup" and TIME_CLARIFICATION_SLOT not in slots:
        if SITE_CLARIFICATION_SLOT in slots:
            return "clarify_site_then_evidence"
        return "implicit_nearest_then_evidence" if "nearest" in str(row.get("query", "")).lower() else "direct_then_evidence"
    if TIME_CLARIFICATION_SLOT in slots and SITE_CLARIFICATION_SLOT in slots:
        return "clarify_site_time_then_evidence"
    if TIME_CLARIFICATION_SLOT in slots:
        return "clarify_time_then_evidence"
    if SITE_CLARIFICATION_SLOT in slots:
        return "clarify_site_then_evidence"
    return "direct_then_evidence"


def patch_final_row(row: dict[str, Any], adv_module: ModuleType) -> tuple[dict[str, Any], dict[str, int]]:
    out = copy.deepcopy(row)
    stats: Counter[str] = Counter()
    stats["rows_seen"] += 1

    before_slots = list(out.get("required_clarification_slots", []))
    temporal_class = temporal_clarification_class(out)
    if temporal_class == "nearest_fallback" and TIME_CLARIFICATION_SLOT in before_slots:
        out["required_clarification_slots"] = [slot for slot in before_slots if slot != TIME_CLARIFICATION_SLOT]
        answers = dict(out.get("clarification_answers", {}))
        answers.pop(TIME_CLARIFICATION_SLOT, None)
        out["clarification_answers"] = answers
        questions = dict(out.get("clarification_questions", {}))
        questions.pop(TIME_CLARIFICATION_SLOT, None)
        out["clarification_questions"] = questions
        stats["time_clarification_removed"] += 1
        stats[f"time_clarification_removed:{out['task_family']}"] += 1

    pre_normalize_slots = set(out.get("required_clarification_slots", []))
    pre_normalize_milestones = {
        milestone.get("slot")
        for milestone in out.get("interaction_milestones", [])
        if milestone.get("type") == "user_clarification"
    }
    if pre_normalize_slots - pre_normalize_milestones:
        stats["rows_with_missing_user_milestones_fixed"] += 1

    target_slot = out.get("metadata", {}).get("adversarial_target_slot")
    if target_slot and target_slot in (out.get("clarification_answers") or {}):
        original = str(out["clarification_answers"][target_slot])
        stripped = adv_module.strip_procedural_target_suffix(original)
        if stripped != original:
            out["clarification_answers"][target_slot] = stripped
            stats["procedural_target_answer_stripped"] += 1

    out = adv_module.normalize_clarification_scaffolding(out)
    out["interaction_mode"] = patched_interaction_mode(out)
    out["query"] = adv_module.objective_prompt(out)
    out["initial_user_message"] = out["query"]

    metadata = dict(out.get("metadata", {}))
    metadata["temporal_clarification_class"] = temporal_clarification_class(out)
    metadata["time_clarification_policy_patch"] = True
    metadata["required_clarification_slot_count"] = len(out.get("required_clarification_slots", []))
    out["metadata"] = metadata

    difficulty = dict(out.get("difficulty_proxy", {}))
    difficulty["agentic_turn_requirements"] = len(out.get("required_clarification_slots", [])) + len(out.get("post_answer_user_turns", []))
    difficulty["requires_multi_slot_clarification"] = len(out.get("required_clarification_slots", [])) > 1
    difficulty["requires_time_clarification"] = TIME_CLARIFICATION_SLOT in out.get("required_clarification_slots", [])
    out["difficulty_proxy"] = difficulty
    return out, dict(stats)


def patch_final_dataset(
    *,
    old_final_dir: Path,
    out_dir: Path,
) -> dict[str, Any]:
    adv_module = load_module(
        "build_bts_e2e_adversarial_from_solver_module",
        REPO_ROOT / "scripts" / "build_bts_e2e_adversarial_from_solver.py",
    )
    out_dir.mkdir(parents=True, exist_ok=True)
    split_reports: dict[str, dict[str, int]] = {}
    for split in SPLITS:
        stats: Counter[str] = Counter()
        patched_rows: list[dict[str, Any]] = []
        for row in load_jsonl(old_final_dir / f"{split}.jsonl"):
            patched, row_stats = patch_final_row(row, adv_module)
            patched_rows.append(patched)
            stats.update(row_stats)
        write_jsonl(out_dir / f"{split}.jsonl", patched_rows)
        split_reports[split] = dict(stats)

    registry = old_final_dir / "scenario_tool_registry.json"
    if registry.exists():
        (out_dir / "scenario_tool_registry.json").write_text(registry.read_text(encoding="utf-8"), encoding="utf-8")

    manifest = {
        "track": "bts_e2e_agentic",
        "variant": "v7_adv7_qgpatch_tcaudit",
        "source_final_dir": str(old_final_dir),
        "temporal_clarify_policy_patch": {
            "policy": "recoverable-slot-v2",
            "time_clarification_removed_for_nearest_fallback": True,
            "clarification_scaffolding_normalized": True,
            "split_reports": split_reports,
        },
    }
    write_json(out_dir / "manifest.json", manifest)
    write_json(out_dir / "e2e_audit.json", audit_bts_e2e(out_dir))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--static-dir", type=Path, required=True)
    parser.add_argument("--old-final-dir", type=Path, required=True)
    parser.add_argument("--out-e2e-dir", type=Path, required=True)
    parser.add_argument("--out-agentic-dir", type=Path, required=True)
    parser.add_argument("--out-final-dir", type=Path, required=True)
    args = parser.parse_args()

    build_bts_e2e(args.static_dir, args.out_e2e_dir)
    write_json(args.out_e2e_dir / "e2e_audit.json", audit_bts_e2e(args.out_e2e_dir))

    agentic_module = load_module("build_bts_e2e_agentic_module", REPO_ROOT / "scripts" / "build_bts_e2e_agentic.py")
    agentic_manifest = agentic_module.build_agentic_bts_e2e(args.static_dir, args.out_agentic_dir)
    write_json(args.out_agentic_dir / "manifest.json", agentic_manifest)
    write_json(args.out_agentic_dir / "e2e_audit.json", audit_bts_e2e(args.out_agentic_dir))

    final_manifest = patch_final_dataset(old_final_dir=args.old_final_dir, out_dir=args.out_final_dir)
    print(json.dumps({
        "out_e2e_dir": str(args.out_e2e_dir),
        "out_agentic_dir": str(args.out_agentic_dir),
        "out_final_dir": str(args.out_final_dir),
        "final_manifest": final_manifest,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
