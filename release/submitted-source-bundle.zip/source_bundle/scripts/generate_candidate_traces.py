#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.prob_accomplishment import compact_record, rollout_utility, summarize_rollouts
from bts_agentbench.runtime import ToolStoreRuntime
from run_local_agent_eval import LocalChatModel, load_jsonl, run_agent_on_example, select_subset


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def choose_oracle(candidates: list[dict]) -> dict:
    return max(candidates, key=rollout_utility)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--split", choices=["train", "dev", "test"], required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-scenarios", type=int, default=1000)
    parser.add_argument("--family-limit", type=int, default=0)
    parser.add_argument("--sampled-candidates", type=int, default=2)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-p", type=float, default=0.9)
    parser.add_argument("--max-steps", type=int, default=4)
    parser.add_argument("--max-new-tokens", type=int, default=192)
    args = parser.parse_args()

    rows = load_jsonl(args.benchmark_dir / f"{args.split}.jsonl")
    subset = select_subset(rows, max_scenarios=args.max_scenarios, family_limit=args.family_limit if args.family_limit > 0 else None)
    runtime = ToolStoreRuntime(args.tool_store_db)
    model = LocalChatModel(args.model, max_new_tokens=args.max_new_tokens)

    greedy_rows: list[dict] = []
    oracle_rows: list[dict] = []
    trace_rows: list[dict] = []

    try:
        for ex_idx, example in enumerate(subset, start=1):
            candidates: list[dict] = []
            greedy = run_agent_on_example(model, runtime, example, args.max_steps, generation_kwargs={"do_sample": False})
            greedy["candidate_index"] = 0
            candidates.append(greedy)
            for sample_idx in range(args.sampled_candidates):
                sampled = run_agent_on_example(
                    model,
                    runtime,
                    example,
                    args.max_steps,
                    generation_kwargs={
                        "do_sample": True,
                        "temperature": args.temperature,
                        "top_p": args.top_p,
                        "seed": 2400 + ex_idx * 10 + sample_idx,
                    },
                )
                sampled["candidate_index"] = sample_idx + 1
                candidates.append(sampled)

            oracle = choose_oracle(candidates)
            greedy_rows.append(greedy)
            oracle_rows.append(oracle)
            trace_rows.append(
                {
                    "scenario_id": example["scenario_id"],
                    "task_family": example["task_family"],
                    "query": example["query"],
                    "oracle_candidate_index": oracle["candidate_index"],
                    "candidates": [compact_record(candidate) | {"candidate_index": candidate["candidate_index"]} for candidate in candidates],
                }
            )
            print(
                f"[progress] {args.split} {ex_idx}/{len(subset)} {example['scenario_id']} "
                f"greedy={greedy['verification']['label']} oracle={oracle['verification']['label']}",
                flush=True,
            )
    finally:
        runtime.close()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.out_dir / f"{args.split}_greedy.jsonl", greedy_rows)
    write_jsonl(args.out_dir / f"{args.split}_oracle.jsonl", oracle_rows)
    write_jsonl(args.out_dir / f"{args.split}_candidate_traces.jsonl", trace_rows)

    summary = {
        "greedy": summarize_rollouts(greedy_rows),
        "oracle_best_of_3": summarize_rollouts(oracle_rows),
        "split": args.split,
        "model": args.model,
        "candidate_policy": {
            "greedy": 1,
            "sampled": args.sampled_candidates,
            "temperature": args.temperature,
            "top_p": args.top_p,
            "max_steps": args.max_steps,
            "max_new_tokens": args.max_new_tokens,
            "max_scenarios": args.max_scenarios,
            "family_limit": args.family_limit,
        },
    }
    (args.out_dir / f"{args.split}_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
