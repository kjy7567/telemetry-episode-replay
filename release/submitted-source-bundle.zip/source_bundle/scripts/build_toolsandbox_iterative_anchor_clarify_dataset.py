#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = REPO_ROOT.parent
SRC_ROOT = REPO_ROOT / "src"
TOOLSANDBOX_ROOT = WORKSPACE_ROOT / "external" / "ToolSandbox"
for path in (SRC_ROOT, TOOLSANDBOX_ROOT):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

from bts_agentbench.clarify_policy import clarify_policy_manifest_fields
from bts_agentbench.iterative_contract import contract_fields, contract_manifest_fields
from tool_sandbox.common.execution_context import DatabaseNamespace, get_current_context, set_current_context
from tool_sandbox.common.message_conversion import Message
from tool_sandbox.common.tool_discovery import ToolBackend
from tool_sandbox.roles.execution_environment import ExecutionEnvironment
from tool_sandbox.scenarios.insufficient_information_scenarios import named_insufficient_information_scenarios
from tool_sandbox.scenarios.single_tool_call_scenarios import named_single_tool_call_scenarios


SYSTEM_PROMPT = """You are a mobile assistant agent in a tool-using loop.

At each assistant turn, do exactly one of the following:
1. Ask the user one short clarification question if a required query slot is missing.
2. Return exactly one compact JSON tool action and nothing else:
   {"tool_name":"...", "arguments":{...}}
3. Answer the user in concise natural language when you have enough information.

Rules:
- Use only the allowed tools.
- Do not wrap the final answer in JSON.
- Do not invent names, phone numbers, coordinates, company names, or message content.
"""


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_candidate_scenarios() -> dict[str, Any]:
    scenarios: dict[str, Any] = {}
    scenarios.update(named_single_tool_call_scenarios(preferred_tool_backend=ToolBackend.DEFAULT))
    scenarios.update(named_insufficient_information_scenarios(preferred_tool_backend=ToolBackend.DEFAULT))
    return scenarios


def exact_trace_payload(scenario: Any) -> dict[str, Any] | None:
    for milestone in scenario.evaluation.milestone_matcher.milestones:
        for constraint in milestone.snapshot_constraints:
            if (
                constraint.database_namespace == DatabaseNamespace.SANDBOX
                and constraint.target_dataframe is not None
                and "tool_trace" in constraint.target_dataframe.columns
            ):
                rows = constraint.target_dataframe.to_dicts()
                if not rows:
                    continue
                return json.loads(rows[0]["tool_trace"])
    return None


def final_answer_target(scenario: Any) -> str | None:
    for milestone in scenario.evaluation.milestone_matcher.milestones:
        for constraint in milestone.snapshot_constraints:
            if (
                constraint.database_namespace == DatabaseNamespace.SANDBOX
                and constraint.target_dataframe is not None
                and {"sender", "recipient", "content"} <= set(constraint.target_dataframe.columns)
            ):
                rows = constraint.target_dataframe.to_dicts()
                for row in rows:
                    if row["sender"] == "AGENT" and row["recipient"] == "USER":
                        return str(row["content"]).strip()
    return None


def current_task_user_message(scenario: Any) -> str:
    db = scenario.starting_context.get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    rows = db.select(["sender", "recipient", "content"]).to_dicts()
    for row in reversed(rows):
        if row["sender"] == "USER" and row["recipient"] == "AGENT":
            return str(row["content"]).strip()
    raise ValueError("No USER->AGENT message found in scenario")


def system_messages_for_agent(scenario: Any) -> list[str]:
    db = scenario.starting_context.get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    rows = db.select(["sender", "recipient", "content"]).to_dicts()
    messages: list[str] = []
    for row in rows:
        if row["sender"] == "SYSTEM" and row["recipient"] == "AGENT":
            messages.append(str(row["content"]).strip())
    return messages


def tool_python_call(tool_name: str, arguments: dict[str, Any]) -> str:
    args_text = json.dumps(arguments, ensure_ascii=False)
    return (
        f"tool_parameters = {args_text}\n"
        f"tool_response = {tool_name}(**tool_parameters)\n"
        f"print(repr(tool_response))"
    )


def prepare_execution_environment(scenario: Any) -> ExecutionEnvironment:
    execution_context = copy.deepcopy(scenario.starting_context)
    set_current_context(execution_context)
    role = ExecutionEnvironment()
    sandbox_db = execution_context.get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    max_index = execution_context.max_sandbox_message_index
    for message_index in range(max_index + 1):
        if (
            sandbox_db["recipient"][message_index] == "EXECUTION_ENVIRONMENT"
            and sandbox_db["sender"][message_index] == "SYSTEM"
        ):
            role.respond(ending_index=message_index)
    return role


def execute_tool_result_text(scenario: Any, payload: dict[str, Any]) -> str:
    role = prepare_execution_environment(scenario)
    message = Message(
        sender="AGENT",
        recipient="EXECUTION_ENVIRONMENT",
        content=tool_python_call(payload["tool_name"], payload.get("arguments", {})),
    )
    role.add_messages([message])
    role.respond()
    sandbox_db = get_current_context().get_database(
        DatabaseNamespace.SANDBOX,
        drop_sandbox_message_index=False,
        get_all_history_snapshots=True,
    )
    rows = sandbox_db.select(["sender", "recipient", "content"]).to_dicts()
    for row in reversed(rows):
        if row["sender"] == "EXECUTION_ENVIRONMENT" and row["recipient"] == "AGENT":
            return str(row["content"]).strip()
    return "Tool result unavailable."


def toolsandbox_clarify_spec(name: str, user_query: str, payload: dict[str, Any]) -> dict[str, str] | None:
    if name == "find_address_with_lat_lon":
        match = re.search(r"lattitude:\s*([-\d.]+), longitude:\s*([-\d.]+)", user_query, flags=re.IGNORECASE)
        if match:
            return {
                "slot": "coordinates",
                "initial_user_message": "What is the address there?",
                "question": "Which latitude and longitude should I use?",
                "answer": f"Use latitude {match.group(1)} and longitude {match.group(2)}.",
            }
    if name == "find_phone_number_with_location_name":
        place = payload.get("arguments", {}).get("location")
        if place:
            return {
                "slot": "location_name",
                "initial_user_message": "What's the phone number of that place?",
                "question": "Which place should I look up?",
                "answer": f"Use {place}.",
            }
    if name == "find_stock_symbol_with_company_name":
        company = payload.get("arguments", {}).get("query")
        if company:
            return {
                "slot": "company_name",
                "initial_user_message": "What's the stock symbol for that company?",
                "question": "Which company should I use?",
                "answer": f"Use {company}.",
            }
    if name == "search_name_with_relationship":
        relationship = payload.get("arguments", {}).get("relationship")
        if relationship:
            return {
                "slot": "relationship",
                "initial_user_message": "What is the name of that person in my contacts?",
                "question": "Which relationship should I use?",
                "answer": f"Use my {relationship}.",
            }
    if name == "search_phone_number_with_name":
        person_name = payload.get("arguments", {}).get("name")
        if person_name:
            return {
                "slot": "contact_name",
                "initial_user_message": "What is that person's phone number?",
                "question": "Which person's name should I use?",
                "answer": f"Use {person_name}.",
            }
    if name == "search_relationship_with_phone_number":
        phone_number = payload.get("arguments", {}).get("phone_number")
        if phone_number:
            return {
                "slot": "phone_number",
                "initial_user_message": "What's my relationship with that number?",
                "question": "Which phone number should I use?",
                "answer": f"Use {phone_number}.",
            }
    if name == "search_sender_phone_number_with_content":
        content = payload.get("arguments", {}).get("content")
        if content:
            return {
                "slot": "message_content",
                "initial_user_message": "Which phone number asked me that?",
                "question": "What message content should I search for?",
                "answer": f'Search for the message content "{content}".',
            }
    return None


def build_rows_for_scenario(name: str, scenario: Any, split: str) -> list[dict[str, Any]]:
    payload = exact_trace_payload(scenario)
    answer = final_answer_target(scenario)
    if payload is None or answer is None:
        return []
    user_query = current_task_user_message(scenario)
    clarify_spec = toolsandbox_clarify_spec(name, user_query, payload)
    if clarify_spec is None:
        return []
    tool_result = execute_tool_result_text(scenario, payload)
    extra_system = system_messages_for_agent(scenario)
    system_messages = [{"role": "system", "content": SYSTEM_PROMPT}] + [
        {"role": "system", "content": text} for text in extra_system
    ]
    metadata = {
        "available_tools": [tool for tool in (scenario.starting_context.tool_allow_list or []) if tool != "end_conversation"],
        "scenario_name": name,
        "hidden_user_instruction": user_query,
        "clarification_slot": clarify_spec["slot"],
    }
    tool_payload_text = json.dumps(
        {"tool_name": payload["tool_name"], "arguments": payload.get("arguments", {})},
        ensure_ascii=False,
    )
    base = {
        "scenario_id": f"toolsandbox_clarify_{name}",
        "split": split,
        "task_family": "toolsandbox_exact_trace",
        "site_id": "toolsandbox",
        "track": "toolsandbox_e2e",
        "source": "anchor_clarify_extension",
        "query": clarify_spec["initial_user_message"],
        "interaction_mode": "clarify_slot_then_answer",
        "metadata": metadata,
    }
    return [
        {
            **base,
            "stage": "clarification_question",
            "step_index": 1,
            **contract_fields("clarification_question"),
            "messages": system_messages
            + [
                {"role": "user", "content": clarify_spec["initial_user_message"]},
                {"role": "assistant", "content": clarify_spec["question"]},
            ],
        },
        {
            **base,
            "stage": "tool_call",
            "step_index": 2,
            **contract_fields("tool_call"),
            "messages": system_messages
            + [
                {"role": "user", "content": clarify_spec["initial_user_message"]},
                {"role": "assistant", "content": clarify_spec["question"]},
                {"role": "user", "content": clarify_spec["answer"]},
                {"role": "assistant", "content": tool_payload_text},
            ],
        },
        {
            **base,
            "stage": "final_answer",
            "step_index": 3,
            **contract_fields("final_answer"),
            "messages": system_messages
            + [
                {"role": "user", "content": clarify_spec["initial_user_message"]},
                {"role": "assistant", "content": clarify_spec["question"]},
                {"role": "user", "content": clarify_spec["answer"]},
                {"role": "assistant", "content": tool_payload_text},
                {"role": "user", "content": f"Tool result: {tool_result}"},
                {"role": "assistant", "content": answer},
            ],
        },
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    candidates = load_candidate_scenarios()
    base_manifest = json.loads((REPO_ROOT / "data" / "toolsandbox_iterative_anchor_operator" / "manifest.json").read_text())
    train_names = base_manifest["train_scenarios"]
    dev_names = base_manifest["dev_scenarios"]

    train_rows: list[dict[str, Any]] = []
    dev_rows: list[dict[str, Any]] = []
    kept_train_names: list[str] = []
    kept_dev_names: list[str] = []

    for name in train_names:
        rows = build_rows_for_scenario(name, candidates[name], "train")
        if rows:
            train_rows.extend(rows)
            kept_train_names.append(name)
    for name in dev_names:
        rows = build_rows_for_scenario(name, candidates[name], "dev")
        if rows:
            dev_rows.extend(rows)
            kept_dev_names.append(name)

    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)
    stage_counts_train = dict(Counter(row["stage"] for row in train_rows))
    manifest = {
        "track": "toolsandbox_e2e",
        "source": "iterative_anchor_deterministic_clarify_extension",
        "eligible_scenarios": len(kept_train_names) + len(kept_dev_names),
        "train_scenarios": kept_train_names,
        "dev_scenarios": kept_dev_names,
        "train_examples": len(train_rows),
        "dev_examples": len(dev_rows),
        "stage_counts_train": stage_counts_train,
        "benchmark_source": str(TOOLSANDBOX_ROOT),
        "author_defined_split": True,
        "clarify_extension_policy": "mask_recoverable_query_slot_and_answer_deterministically",
        **contract_manifest_fields(stage_counts_train),
        **clarify_policy_manifest_fields(
            clarify_count=stage_counts_train.get("clarification_question", 0),
            clarify_scope="public_toolsandbox_query_or_exact_trace_arguments",
        ),
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
