from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path("/workspace/BTS-AgentBench")
sys.path.append(str(ROOT / "scripts"))

from bts_agentbench.evaluator import verify_prediction
from bts_agentbench.runtime import ExecutedCall, ToolStoreRuntime
from run_bts_e2e_local_eval import evidence_followup_ok, rationale_followup_ok


def load_rows() -> dict[str, dict]:
    rows: dict[str, dict] = {}
    for split in ["dev", "test"]:
        path = ROOT / "data" / "bts_e2e" / f"{split}.jsonl"
        for line in path.read_text().splitlines():
            row = json.loads(line)
            rows[row["scenario_id"]] = row
    return rows


def finalize_label(verification_label: str, issues: list[str]) -> str:
    if verification_label == "accomplished" and not issues:
        return "accomplished"
    if verification_label != "not_accomplished" or issues:
        return "partially_accomplished"
    return "not_accomplished"


def run_case(
    rows: dict[str, dict],
    runtime: ToolStoreRuntime,
    sid: str,
    why: str,
    clarify: str | None,
    calls_builder,
    final_answer: str,
    evidence_answer: str | None,
    rationale_answer: str | None = None,
) -> dict:
    ex = rows[sid]
    executed: list[ExecutedCall] = []
    prev = None
    for i, (tool_name, args_builder) in enumerate(calls_builder, start=1):
        args = args_builder(prev)
        out = runtime.execute_tool(tool_name, args)
        executed.append(
            ExecutedCall(call_id=f"m{i}", tool_name=tool_name, arguments=args, output=out)
        )
        prev = out

    verification = verify_prediction(ex, executed, final_answer, None, runtime)
    issues: list[str] = []
    if ex["required_clarification_slots"] and clarify is None:
        issues.append("missing_required_clarification")
    if ex.get("interaction_verifier", {}).get("require_rationale_followup", False):
        if rationale_answer is None:
            issues.append("missing_rationale_followup_answer")
        elif not rationale_followup_ok(ex, rationale_answer):
            issues.append("invalid_rationale_followup_answer")
    if evidence_answer is None:
        issues.append("missing_evidence_followup_answer")
    elif not evidence_followup_ok(ex, evidence_answer, executed):
        issues.append("invalid_evidence_followup_answer")

    return {
        "scenario_id": sid,
        "interaction_mode": ex["interaction_mode"],
        "task_family": ex["task_family"],
        "why": why,
        "clarify": clarify,
        "executed_calls": [c.as_dict() for c in executed],
        "final_answer": final_answer,
        "rationale_answer": rationale_answer,
        "evidence_answer": evidence_answer,
        "verification": verification.as_dict(),
        "interaction_issues": issues,
        "label": finalize_label(verification.label, issues),
    }


def main() -> None:
    rows = load_rows()
    runtime = ToolStoreRuntime(str(ROOT / "data" / "bts" / "tool_store" / "tool_store.duckdb"))

    results = []
    results.append(
        run_case(
            rows,
            runtime,
            "dev_point_disambiguation_00007",
            "No clarification needed; resolve the mode-state point on FCU 082 and report the stream.",
            None,
            [("resolve_point", lambda prev: {"site_id": "BTS_A", "point_class": "Mode_Status", "equipment_label": "BTS_A Fcu 082"})],
            "The stream behind the mode state on FCU 082 in BTS_A is 037a4fda_cd15_428e_be78_e9fa1f5f70e7.",
            "I based that on stream 037a4fda_cd15_428e_be78_e9fa1f5f70e7.",
        )
    )
    results.append(
        run_case(
            rows,
            runtime,
            "dev_day_mean_lookup_00014",
            "A day-average needs a date, so clarify once, then resolve the point and aggregate over that day.",
            "Which date should I use for that average?",
            [
                ("resolve_point", lambda prev: {"site_id": "BTS_B", "point_class": "Damper_Position_Sensor", "equipment_label": "BTS_B Outside Damper 002"}),
                ("aggregate_window", lambda prev: {"stream_id": prev["stream_id"], "metric": "mean_value", "window_start": "2021-04-01 00:00:00+00:00", "window_end": "2021-04-02 00:00:00+00:00", "period": "day"}),
            ],
            "On April 1, 2021, the average damper position reading was 53.1912.",
            "I used stream 00fc1fb0_41ba_4bb7_a570_9028d0bd451f.",
        )
    )
    results.append(
        run_case(
            rows,
            runtime,
            "dev_timestamp_nearest_lookup_00006",
            "The question already provides the time and is clearly a nearest-reading query, so resolve then do nearest lookup.",
            None,
            [
                ("resolve_point", lambda prev: {"site_id": "BTS_A", "point_class": "Air_Flow_Sensor", "equipment_label": "BTS_A Exhaust Fan 074"}),
                ("lookup_observation", lambda prev: {"stream_id": prev["stream_id"], "timestamp": "2021-01-01T00:05:14.845600+00:00", "mode": "nearest"}),
            ],
            "There was no exact sample at 00:05 UTC on January 1, 2021. The nearest reading was at 2021-01-01T00:01:09.486000+00:00 and the value was 102.415.",
            "I based that on stream 0b62ca90_6ea9_490e_b227_ef21430a1aaa.",
        )
    )
    results.append(
        run_case(
            rows,
            runtime,
            "dev_quality_gate_00010",
            "This is a quality-gate question. Resolve the point, inspect quality, then answer rather than abstain because coverage is high.",
            None,
            [
                ("resolve_point", lambda prev: {"site_id": "BTS_A", "point_class": "Static_Pressure_Sensor", "equipment_label": "BTS_A Exhaust Fan 075"}),
                ("inspect_quality", lambda prev: {"stream_id": prev["stream_id"]}),
            ],
            "The signal looks reliable enough, so I can answer a typical weekly trend question.",
            "I based that on stream 824f614b_1be8_4699_af7a_92233150a7f7.",
            "I would answer because the signal looks reliable: the observed fraction is 0.9788 and the gap ratio is 235.5054.",
        )
    )
    results.append(
        run_case(
            rows,
            runtime,
            "dev_quality_gate_00015",
            "This is an abstention case. Resolve the point, inspect quality, then abstain because coverage is too low for a weekly trend question.",
            None,
            [
                ("resolve_point", lambda prev: {"site_id": "BTS_A", "point_class": "Demand_Sensor", "equipment_label": "BTS_A Electrical Meter 060"}),
                ("inspect_quality", lambda prev: {"stream_id": prev["stream_id"]}),
            ],
            "I would abstain because the signal is not reliable enough for a typical weekly trend question.",
            "I based that on stream 9114549b_d556_4c35_bcfc_830fb8798031.",
            "I would abstain because the signal is not reliable enough: the observed fraction is 0.6875 and the gap ratio is 234.5395.",
        )
    )

    outdir = ROOT / "runs" / "bts_e2e_manual_spotcheck"
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "manual_spotcheck.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    summary = {
        "scenario_count": len(results),
        "accomplished": sum(r["label"] == "accomplished" for r in results),
        "partial": sum(r["label"] == "partially_accomplished" for r in results),
        "not_accomplished": sum(r["label"] == "not_accomplished" for r in results),
        "mean_process_score": round(sum(r["verification"]["process_score"] for r in results) / len(results), 4),
        "mean_final_score": round(sum(r["verification"]["final_score"] for r in results) / len(results), 4),
        "mean_evidence_score": round(sum(r["verification"]["evidence_score"] for r in results) / len(results), 4),
    }
    (outdir / "manual_spotcheck_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    for r in results:
        print("---", r["scenario_id"], r["label"], r["verification"]["issues"], r["interaction_issues"])


if __name__ == "__main__":
    main()
