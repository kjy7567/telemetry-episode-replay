#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.llm_audit import (
    JudgeConfig,
    judge_scenario,
    scenario_rows,
    summarize_judgments,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-summary", type=Path, required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--base-url", required=True, help="OpenAI-compatible base URL ending in /v1")
    parser.add_argument("--api-key-env", default="OPENAI_API_KEY")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--max-tokens", type=int, default=1200)
    parser.add_argument("--timeout-seconds", type=int, default=120)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    import os

    api_key = os.getenv(args.api_key_env, "").strip()
    if not api_key:
        raise SystemExit(f"Missing API key in environment variable {args.api_key_env}")

    config = JudgeConfig(
        model=args.model,
        base_url=args.base_url,
        api_key=api_key,
        temperature=args.temperature,
        max_tokens=args.max_tokens,
        timeout_seconds=args.timeout_seconds,
    )

    rows = scenario_rows(args.benchmark_dir)
    if args.limit is not None:
        rows = rows[: args.limit]

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    judgments = []
    with args.out_jsonl.open("w", encoding="utf-8") as handle:
        for row in rows:
            judgment, raw_content = judge_scenario(config, row)
            record = {
                "scenario_id": row["scenario_id"],
                "split": row["split"],
                "task_family": row["task_family"],
                "site_id": row["site_id"],
                "judge_model": args.model,
                "judge_base_url": args.base_url,
                "judgment": judgment,
                "raw_judge_content": raw_content,
            }
            judgments.append(judgment)
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    summary = summarize_judgments(judgments)
    summary.update(
        {
            "judge_model": args.model,
            "judge_base_url": args.base_url,
            "temperature": args.temperature,
            "max_tokens": args.max_tokens,
            "timeout_seconds": args.timeout_seconds,
        }
    )
    args.out_summary.parent.mkdir(parents=True, exist_ok=True)
    args.out_summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
