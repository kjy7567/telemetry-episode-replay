#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

from bts_agentbench.prob_accomplishment import (
    compact_record,
    load_jsonl,
    rollout_utility,
    save_bundle,
    summarize_rollouts,
    train_prob_model,
)
from bts_agentbench.runtime import ToolStoreRuntime


PROJECT_ROOT = Path("/workspace/BTS-AgentBench")

TRAIN_ROLLOUTS = {
    "bts": PROJECT_ROOT / "runs" / "current_surface" / "trainwide_repair_protocol" / "bts_train_rollouts.jsonl",
    "xai4heat": PROJECT_ROOT / "runs" / "current_surface" / "trainwide_repair_protocol" / "xai4heat_train_rollouts.jsonl",
    "pleia": PROJECT_ROOT / "runs" / "current_surface" / "trainwide_repair_protocol" / "pleia_train_rollouts.jsonl",
}

TOOL_STORES = {
    "bts": PROJECT_ROOT / "data" / "bts" / "tool_store" / "tool_store.duckdb",
    "xai4heat": PROJECT_ROOT / "data" / "xai4heat" / "tool_store" / "tool_store.duckdb",
    "pleia": PROJECT_ROOT / "data" / "pleia" / "tool_store" / "tool_store.duckdb",
}


def site_runtime_map(rows: list[dict], runtime: ToolStoreRuntime) -> dict[str, ToolStoreRuntime]:
    return {row["site_id"]: runtime for row in rows}


def choose_best(candidates: list[dict]) -> tuple[dict, dict]:
    ranked = sorted(
        candidates,
        key=lambda item: (float(item["predicted_accomplishment_prob"]), item["candidate_index"] == 0),
        reverse=True,
    )
    chosen = ranked[0]
    oracle = max(candidates, key=rollout_utility)
    return chosen, oracle


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", choices=["bts", "xai4heat", "pleia"], required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--run-tag", default="pilot")
    parser.add_argument(
        "--source-run",
        type=Path,
        default=PROJECT_ROOT / "runs" / "current_surface" / "prob_accomplishment_e1_pilot",
    )
    args = parser.parse_args()

    run_root = PROJECT_ROOT / "runs" / "current_surface" / f"prob_accomplishment_{args.corpus}_e{args.epochs}_{args.run_tag}"
    run_root.mkdir(parents=True, exist_ok=True)

    runtime = ToolStoreRuntime(TOOL_STORES[args.corpus])
    try:
        train_rows = load_jsonl(str(TRAIN_ROLLOUTS[args.corpus]))
        bundle, train_metrics = train_prob_model(
            train_rows,
            site_runtime_map(train_rows, runtime),
            epochs=args.epochs,
            batch_size=64,
            learning_rate=1e-3,
        )
        bundle_path = run_root / "prob_accomplishment_bundle.pt"
        save_bundle(bundle, str(bundle_path))

        results_summary = {
            "prob_model": {
                "bundle_path": str(bundle_path),
                "train_corpus": args.corpus,
                "train_example_count": len(train_rows),
                "train_metrics": train_metrics,
                "source_run": str(args.source_run),
            }
        }

        for split in ["dev", "test"]:
            trace_path = args.source_run / f"{args.corpus}_{split}" / "candidate_traces.jsonl"
            traces = load_jsonl(str(trace_path))

            greedy_rows: list[dict] = []
            reranked_rows: list[dict] = []
            oracle_rows: list[dict] = []
            updated_traces: list[dict] = []

            for trace in traces:
                candidates = trace["candidates"]
                probs = bundle.predict_proba(candidates, site_runtime_map(candidates, runtime)).tolist()
                rescored: list[dict] = []
                for candidate, prob in zip(candidates, probs):
                    item = dict(candidate)
                    item["predicted_accomplishment_prob"] = round(float(prob), 6)
                    rescored.append(item)

                chosen, oracle = choose_best(rescored)
                greedy = next(item for item in rescored if item["candidate_index"] == 0)

                greedy_rows.append(greedy)
                reranked_rows.append(chosen)
                oracle_rows.append(oracle)
                updated_traces.append(
                    {
                        "scenario_id": trace["scenario_id"],
                        "task_family": trace["task_family"],
                        "query": trace["query"],
                        "chosen_candidate_index": chosen["candidate_index"],
                        "oracle_candidate_index": oracle["candidate_index"],
                        "candidates": [compact_record(item) | {"candidate_index": item["candidate_index"], "predicted_accomplishment_prob": item["predicted_accomplishment_prob"]} for item in rescored],
                    }
                )

            summary = {
                "greedy": summarize_rollouts(greedy_rows),
                "reranked": summarize_rollouts(reranked_rows),
                "oracle_best_of_3": summarize_rollouts(oracle_rows),
                "split": split,
                "corpus": args.corpus,
            }
            results_summary[f"{args.corpus}_{split}"] = summary

            out_dir = run_root / f"{args.corpus}_{split}"
            write_jsonl(out_dir / "greedy.jsonl", greedy_rows)
            write_jsonl(out_dir / "reranked.jsonl", reranked_rows)
            write_jsonl(out_dir / "oracle.jsonl", oracle_rows)
            write_jsonl(out_dir / "candidate_traces.jsonl", updated_traces)
            (out_dir / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

        (run_root / "combined_summary.json").write_text(json.dumps(results_summary, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps(results_summary, indent=2, ensure_ascii=False))
    finally:
        runtime.close()


if __name__ == "__main__":
    main()
