#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Any

import pandas as pd
from bts_agentbench.bts_e2e import (
    FOLLOWUP_PROMPT,
    RATIONALE_FOLLOWUP_PROMPT,
    STOP_ACK,
    DeterministicBtsUserSimulator,
    evidence_followup_prompt,
    load_jsonl,
)
from bts_agentbench.evaluator import verify_prediction
from bts_agentbench.operator_answer import (
    check_evidence_followup,
    check_operator_answer,
    check_rationale_followup,
)
from bts_agentbench.runtime import ExecutedCall, ToolStoreRuntime
from run_local_agent_eval import LocalChatModel, extract_json_payload


SYSTEM_PROMPT = """You are a building-operations agent in a multi-turn conversation with an operator.

You may do exactly one of the following at each assistant turn:
1. Ask the operator a short clarification question if a required site, date, week, month, or timestamp is missing.
2. Return exactly one compact JSON tool action and nothing else:
   {"tool_name":"...", "arguments":{...}}
3. Answer the operator in concise natural language once you have enough information.

Additional rules:
- Tool results will appear as later user messages prefixed with "Tool result:".
- Do not wrap the final operator answer in JSON.
- When a prior tool result already contains a `stream_id` or `stream_ids`, you may refer to it in later tool calls as `$e1.stream_id` or `$e1.stream_ids` instead of copying long values.
- Use the exact tool schemas below. Do not invent alias argument names such as `date_range_start` or `date_range_end`.
- If the operator has already supplied a required site, date, week, month, or timestamp in the conversation, do not ask for that same clarification again.
- For any tool argument named `timestamp`, `window_start`, or `window_end`, include an explicit UTC offset such as `Z` or `+00:00`.
- resolve_point arguments: `site_id`, `point_class`, `equipment_label`, optional `location_label`
- list_points arguments: `site_id`, `point_class`, `location_type`
- aggregate_window arguments: `stream_id`, `metric`, `window_start`, `window_end`, `period`
- compare_window arguments: `left_stream_id`, `right_stream_id`, `metric`, `window_start`, `window_end`, `period`
- rank_window arguments: `stream_ids`, `metric`, `window_start`, `window_end`, `period`, `order`, `topk`
- lookup_observation arguments: `stream_id`, `timestamp`, `mode`
- inspect_quality arguments: `stream_id`
- inspect_quality_window arguments: `stream_id`, `window_start`, `window_end`, `period`
- After `aggregate_window`, answer with the returned `mean_value`.
- Calendar windows are half-open. For a month, use the first day of that month as `window_start` and the first day of the next month as `window_end`; do not use the last day of the month as `window_end`.
- For ranking questions, first call `list_points`, then call `rank_window` with the returned `stream_ids`; never answer from `list_points` alone.
- After `rank_window`, answer with `ranked_streams[0]` and include the exact winning `stream_id` and its `mean_value` when the operator asks which stream is top.
- For `list_points`, `location_type` is a category such as `Location`, `Room`, or `Conference_Room`; never use a site id such as `BTS_A`, `BTS_B`, or `BTS_C` as `location_type`.
- For timestamp questions, first try `lookup_observation` with `mode: "exact"` unless the operator explicitly asks for a nearby reading.
- After `lookup_observation` with `mode: "exact"`, report the exact returned value. Preserve fractional seconds in timestamps. If the tool result says `exact_match_found` is false and the task still asks for the requested reading, you may call `lookup_observation` again with `mode: "nearest"` and report the nearest logged reading together with the fallback reason.
- For nearby-reading tasks, report the returned nearby timestamp and value and make it explicit that there was no exact logged reading at the requested time.
- `inspect_quality` is a stream-level quality summary. `inspect_quality_window` is the time-bounded quality tool for a specific day, week, or month.
- For any day-, week-, or month-bounded quality comparison, use `inspect_quality_window`; do not substitute `inspect_quality`.
- For quality-gate questions, call `inspect_quality_window` for the requested week after resolving the point. Use its `quality_reference`: abstain if `observed_fraction` is below `abstain_observed_fraction_below` or `gap_ratio` is above `abstain_gap_ratio_above`; answer only if the metrics satisfy the answer thresholds. Explicitly say either "I would answer" or "I would abstain" and cite observed coverage and gap ratio.
- If the operator asks which stream or point you used, answer directly in natural language and include the exact stream_id you actually used.
- If the operator asks why you would answer or abstain, explain the quality-based reason directly in natural language.
- If a time reference is missing, ask for the specific missing unit the task needs, such as a date, week, month, time window, or exact timestamp. For timestamp tasks, ask for the exact timestamp including fractional seconds if available.
- After a tool call, if the current operator question is now answerable, answer it immediately before doing anything else.
- Do not invent stream_ids, timestamps, or values.
"""

def select_subset(rows: list[dict[str, Any]], max_per_mode: int, max_scenarios: int) -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    counts: dict[str, int] = {}
    for row in rows:
        mode = row["interaction_mode"]
        if counts.get(mode, 0) >= max_per_mode:
            continue
        selected.append(row)
        counts[mode] = counts.get(mode, 0) + 1
        if len(selected) >= max_scenarios:
            break
    return selected


def evidence_followup_ok(
    example: dict[str, Any],
    answer_text: str,
    executed_calls: list[ExecutedCall],
    runtime: ToolStoreRuntime | None = None,
) -> bool:
    return check_evidence_followup(example, answer_text, executed_calls, runtime)


def minimum_turn_budget(example: dict[str, Any]) -> int:
    phase_count = len(example.get("phase_examples") or [])
    if phase_count == 0:
        phase_count = 1 + len(example.get("goal_revision_turns", []))
    canonical_tool_calls = len(example.get("canonical_tool_calls", []))
    clarification_turns = len(example.get("required_clarification_slots", []))
    evidence_turns = 1 if example.get("post_answer_user_turns") else 0
    rationale_turns = 1 if example.get("interaction_verifier", {}).get("require_rationale_followup", False) else 0
    return canonical_tool_calls + phase_count + clarification_turns + evidence_turns + rationale_turns + 1


def _normalize_utc_argument(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    try:
        ts = pd.Timestamp(value)
    except Exception:
        return value
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    else:
        ts = ts.tz_convert("UTC")
    return ts.isoformat()


def normalize_tool_arguments(arguments: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(arguments)
    for key in ("timestamp", "window_start", "window_end"):
        if key in normalized:
            normalized[key] = _normalize_utc_argument(normalized[key])
    return normalized


def rationale_followup_ok(
    example: dict[str, Any],
    answer_text: str,
    runtime: ToolStoreRuntime | None = None,
) -> bool:
    return check_rationale_followup(example, answer_text, runtime)


def run_e2e_example(
    model: LocalChatModel,
    runtime: ToolStoreRuntime,
    example: dict[str, Any],
    max_turns: int,
) -> dict[str, Any]:
    simulator = DeterministicBtsUserSimulator(example)
    messages: list[dict[str, str]] = [{"role": "system", "content": SYSTEM_PROMPT}]
    user_message = simulator.reset()
    messages.append({"role": "user", "content": user_message})

    executed_calls: list[ExecutedCall] = []
    raw_responses: list[str] = []
    final_answer_text: str | None = None
    phase_answer_texts: list[str] = []
    evidence_answer_text: str | None = None
    rationale_answer_text: str | None = None
    parse_error: str | None = None
    required_slots = set(example.get("required_clarification_slots", []))
    answered_slots: set[str] = set()
    pretermination_issues: list[str] = []
    effective_max_turns = max(max_turns, minimum_turn_budget(example))

    def all_required_clarifications_answered() -> bool:
        return required_slots.issubset(answered_slots)

    for turn in range(effective_max_turns):
        try:
            text = model.generate(messages)
        except Exception as exc:
            parse_error = f"generation_error:{exc}"
            break
        raw_responses.append(text)
        stripped = text.strip()
        if not stripped:
            parse_error = "empty_assistant_message"
            break

        try:
            payload = extract_json_payload(text)
        except Exception:
            payload = None

        if payload is not None and isinstance(payload, dict) and "tool_name" in payload:
            if required_slots and not all_required_clarifications_answered():
                pretermination_issues.append("premature_tool_before_required_clarification")
            tool_name = payload.get("tool_name")
            arguments = payload.get("arguments", {})
            if not tool_name or not isinstance(arguments, dict):
                parse_error = "invalid_tool_call_payload"
                break
            try:
                call_outputs = {call.call_id: call.output for call in executed_calls}
                resolved_arguments = runtime._replace_refs(arguments, call_outputs)
                resolved_arguments = normalize_tool_arguments(resolved_arguments)
                output = runtime.execute_tool(tool_name, resolved_arguments)
            except Exception as exc:
                parse_error = f"tool_execution_error:{tool_name}:{type(exc).__name__}"
                break
            call = ExecutedCall(
                call_id=f"e{len(executed_calls)+1}",
                tool_name=tool_name,
                arguments=resolved_arguments,
                output=output,
            )
            executed_calls.append(call)
            messages.append({"role": "assistant", "content": stripped})
            messages.append({"role": "user", "content": f"Tool result: {ToolStoreRuntime.compact_observation(call)}"})
            continue

        current_user = messages[-1]["content"]
        expected_followup = example.get("followup_prompt", evidence_followup_prompt(example))
        if DeterministicBtsUserSimulator._looks_like_question(stripped):
            if not required_slots and not executed_calls and final_answer_text is None:
                pretermination_issues.append("unnecessary_clarification")
            elif required_slots and all_required_clarifications_answered() and not executed_calls and final_answer_text is None:
                pretermination_issues.append("redundant_clarification")
        if current_user == expected_followup:
            evidence_answer_text = stripped
        elif current_user == RATIONALE_FOLLOWUP_PROMPT:
            rationale_answer_text = stripped
        else:
            final_answer_text = stripped
            if not DeterministicBtsUserSimulator._looks_like_question(stripped):
                phase_answer_texts.append(stripped)

        messages.append({"role": "assistant", "content": stripped})
        reply = simulator.step(stripped)
        if reply is None:
            break
        messages.append({"role": "user", "content": reply})

        if reply == STOP_ACK:
            break
        for slot, answer in example.get("clarification_answers", {}).items():
            if reply == answer:
                answered_slots.add(slot)

    verification = verify_prediction(
        example,
        executed_calls,
        final_answer_text,
        None,
        runtime,
        phase_answers=phase_answer_texts,
    )

    interaction_issues: list[str] = []
    interaction_issues.extend(pretermination_issues)
    if required_slots and not all_required_clarifications_answered():
        for slot in sorted(required_slots - answered_slots):
            interaction_issues.append(f"missing_required_clarification:{slot}")
    if example.get("interaction_verifier", {}).get("require_rationale_followup", False):
        if rationale_answer_text is None:
            interaction_issues.append("missing_rationale_followup_answer")
        elif not rationale_followup_ok(example, rationale_answer_text, runtime):
            interaction_issues.append("invalid_rationale_followup_answer")
    if example.get("interaction_verifier", {}).get("require_goal_revision_answer", False):
        expected_phase_answers = 1 + len(example.get("goal_revision_turns", []))
        if len(phase_answer_texts) < expected_phase_answers:
            interaction_issues.append("missing_goal_revision_answer")
    if evidence_answer_text is None:
        interaction_issues.append("missing_evidence_followup_answer")
    elif not evidence_followup_ok(example, evidence_answer_text, executed_calls, runtime):
        interaction_issues.append("invalid_evidence_followup_answer")
    if messages[-1]["content"] != STOP_ACK:
        interaction_issues.append("conversation_not_terminated")
    if parse_error:
        interaction_issues.append(parse_error)

    protocol_ok = not interaction_issues
    accomplished = verification.task_ok and protocol_ok
    strict_accomplished = verification.process_ok and verification.task_ok and protocol_ok
    if accomplished:
        e2e_label = "accomplished"
    elif verification.task_score > 0.0 or interaction_issues:
        e2e_label = "partially_accomplished"
    else:
        e2e_label = "not_accomplished"
    if strict_accomplished:
        strict_label = "accomplished"
    elif verification.strict_label != "not_accomplished" or interaction_issues:
        strict_label = "partially_accomplished"
    else:
        strict_label = "not_accomplished"

    return {
        "scenario_id": example["scenario_id"],
        "task_family": example["task_family"],
        "interaction_mode": example["interaction_mode"],
        "messages": messages,
        "raw_responses": raw_responses,
        "executed_calls": [call.as_dict() for call in executed_calls],
        "final_answer_text": final_answer_text,
        "phase_answer_texts": phase_answer_texts,
        "rationale_answer_text": rationale_answer_text,
        "evidence_answer_text": evidence_answer_text,
        "static_verification": verification.as_dict(),
        "interaction_issues": interaction_issues,
        "protocol_ok": protocol_ok,
        "strict_label": strict_label,
        "label": e2e_label,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--split", type=str, choices=["dev", "test"], default="dev")
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-summary", type=Path, required=True)
    parser.add_argument("--max-turns", type=int, default=12)
    parser.add_argument("--max-new-tokens", type=int, default=256)
    parser.add_argument("--max-per-mode", type=int, default=2)
    parser.add_argument("--max-scenarios", type=int, default=20)
    args = parser.parse_args()

    rows = load_jsonl(args.benchmark_dir / f"{args.split}.jsonl")
    selected = select_subset(rows, max_per_mode=args.max_per_mode, max_scenarios=args.max_scenarios)

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    model = LocalChatModel(args.model, max_new_tokens=args.max_new_tokens, do_sample=False)
    runtime = ToolStoreRuntime(args.tool_store_db)
    predictions: list[dict[str, Any]] = []
    try:
        with args.out_jsonl.open("w", encoding="utf-8") as handle:
            total = len(selected)
            for idx, row in enumerate(selected, start=1):
                prediction = run_e2e_example(model, runtime, row, args.max_turns)
                predictions.append(prediction)
                handle.write(json.dumps(prediction, ensure_ascii=False) + "\n")
                handle.flush()
                print(f"[progress] {idx}/{total} {row['scenario_id']} {prediction['label']}", flush=True)
    finally:
        runtime.close()

    labels = Counter(row["label"] for row in predictions)
    summary = {
        "model": args.model,
        "split": args.split,
        "scenario_count": len(predictions),
        "counts": dict(labels),
        "strict_counts": dict(Counter(row["strict_label"] for row in predictions)),
        "mean_process_score": round(mean(row["static_verification"]["process_score"] for row in predictions), 4),
        "mean_final_score": round(mean(row["static_verification"]["final_score"] for row in predictions), 4),
        "mean_evidence_score": round(mean(row["static_verification"]["evidence_score"] for row in predictions), 4),
        "mean_core_score": round(mean(row["static_verification"]["core_score"] for row in predictions), 4),
        "mean_reporting_score": round(mean(row["static_verification"]["reporting_score"] for row in predictions), 4),
        "mean_grounding_score": round(mean(row["static_verification"]["grounding_score"] for row in predictions), 4),
        "mean_temporal_score": round(mean(row["static_verification"]["temporal_score"] for row in predictions), 4),
        "mean_phase_score": round(mean(row["static_verification"]["phase_score"] for row in predictions), 4),
        "mean_task_score": round(mean(row["static_verification"]["task_score"] for row in predictions), 4),
        "protocol_success_count": sum(1 for row in predictions if row["protocol_ok"]),
        "task_success_count": sum(1 for row in predictions if row["static_verification"]["task_ok"]),
        "static_strict_success_count": sum(1 for row in predictions if row["static_verification"]["strict_label"] == "accomplished"),
        "interaction_issue_counts": dict(Counter(issue for row in predictions for issue in row["interaction_issues"])),
        "by_mode": {
            mode: {
                "count": sum(1 for row in predictions if row["interaction_mode"] == mode),
                "accomplished": sum(1 for row in predictions if row["interaction_mode"] == mode and row["label"] == "accomplished"),
                "strict_accomplished": sum(1 for row in predictions if row["interaction_mode"] == mode and row["strict_label"] == "accomplished"),
            }
            for mode in sorted({row["interaction_mode"] for row in predictions})
        },
    }
    args.out_summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
