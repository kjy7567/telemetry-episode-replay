#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from statistics import mean
from typing import Any

import torch
from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer
from peft import AutoPeftModelForCausalLM, PeftConfig

from bts_agentbench.evaluator import verify_prediction
from bts_agentbench.runtime import ExecutedCall, ToolStoreRuntime


SYSTEM_PROMPT = """You are a building-operations tool-using agent.

Solve each scenario by choosing one tool action at a time, or by answering the operator directly once you have enough information.

Available tools:
- resolve_point(site_id, point_class, equipment_label, location_label?)
- list_points(site_id, point_class?, equipment_type?, location_type?)
- aggregate_window(stream_id, metric, window_start, window_end, period)
- compare_window(left_stream_id, right_stream_id, metric, window_start, window_end, period)
- rank_window(stream_ids, metric, window_start, window_end, period, order, topk)
- lookup_observation(stream_id, timestamp, mode)
- inspect_quality(stream_id)
- inspect_quality_window(stream_id, window_start, window_end, period)

Rules:
1. If you still need a tool, return exactly one compact JSON action and nothing else:
   {"tool_name":"...", "arguments":{...}}
2. Once you have enough information, answer in concise natural language for the operator.
3. Do not return the final operator answer as JSON.
4. Reuse exact stream_id values from observations when available.
5. Do not invent stream_ids, timestamps, or values.
6. If there is no exact timestamp match, use lookup_observation with mode "nearest".
7. Prefer resolve_point when the question already names a concrete equipment_label or location_label.
8. Use list_points mainly when the question asks over a group, such as "among ... points located in Room".
9. Questions may paraphrase point classes and compress equipment names. Map natural phrases like "temperature reading", "weekly average", or "FCU 003" back to canonical tool arguments before calling a tool.
10. For weekly quality-decision questions, use inspect_quality_window with the requested week rather than inspect_quality.
"""


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def extract_json_payload(text: str) -> dict[str, Any]:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.DOTALL)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        if start == -1:
            raise
        depth = 0
        in_string = False
        escape = False
        for idx, char in enumerate(text[start:], start=start):
            if in_string:
                if escape:
                    escape = False
                elif char == "\\":
                    escape = True
                elif char == "\"":
                    in_string = False
                continue
            if char == "\"":
                in_string = True
                continue
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(text[start : idx + 1])
        raise


class LocalChatModel:
    def __init__(
        self,
        model_id: str,
        max_new_tokens: int = 384,
        do_sample: bool = False,
        temperature: float = 0.7,
        top_p: float = 0.9,
    ):
        self.model_id = model_id
        self.max_new_tokens = max_new_tokens
        self.do_sample = do_sample
        self.temperature = temperature
        self.top_p = top_p
        model_path = Path(model_id)
        if (model_path / "adapter_config.json").exists():
            peft_config = PeftConfig.from_pretrained(model_id)
            self.tokenizer = AutoTokenizer.from_pretrained(peft_config.base_model_name_or_path)
            self.model = AutoPeftModelForCausalLM.from_pretrained(
                model_id,
                torch_dtype=torch.float16,
                device_map="auto",
            )
        else:
            self.tokenizer = AutoTokenizer.from_pretrained(model_id)
            config = AutoConfig.from_pretrained(model_id)
            self.max_context_tokens = getattr(config, "max_position_embeddings", None)
            quantization_config = getattr(config, "quantization_config", None) or {}
            torch_dtype: str | torch.dtype
            if isinstance(quantization_config, dict) and quantization_config.get("quant_method") == "fp8":
                torch_dtype = "auto"
            else:
                torch_dtype = torch.bfloat16
            self.model = AutoModelForCausalLM.from_pretrained(
                model_id,
                torch_dtype=torch_dtype,
                device_map="auto",
            )
        if not hasattr(self, "max_context_tokens"):
            self.max_context_tokens = getattr(self.model.config, "max_position_embeddings", None)
        self.model.eval()
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model.generation_config.do_sample = False
        self.model.generation_config.temperature = None
        self.model.generation_config.top_p = None
        self.model.generation_config.top_k = None

    @torch.inference_mode()
    def generate(
        self,
        messages: list[dict[str, str]],
        do_sample: bool | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        seed: int | None = None,
    ) -> str:
        use_sample = self.do_sample if do_sample is None else do_sample
        use_temperature = self.temperature if temperature is None else temperature
        use_top_p = self.top_p if top_p is None else top_p
        if seed is not None:
            torch.manual_seed(seed)
        model_inputs = self.tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
            enable_thinking=False,
        )
        if self.max_context_tokens is not None:
            input_len = int(model_inputs["input_ids"].shape[-1])
            if input_len > int(self.max_context_tokens):
                raise ValueError(f"context_overflow:{input_len}>{self.max_context_tokens}")
        model_inputs = {key: value.to(self.model.device) for key, value in model_inputs.items()}
        outputs = self.model.generate(
            **model_inputs,
            max_new_tokens=self.max_new_tokens,
            do_sample=use_sample,
            temperature=use_temperature if use_sample else None,
            top_p=use_top_p if use_sample else None,
            pad_token_id=self.tokenizer.eos_token_id,
        )
        generated = outputs[0][model_inputs["input_ids"].shape[-1] :]
        return self.tokenizer.decode(generated, skip_special_tokens=True)


def select_subset(rows: list[dict], max_scenarios: int, family_limit: int | None) -> list[dict]:
    if family_limit is None or family_limit <= 0:
        return rows[:max_scenarios]
    by_family: dict[str, list[dict]] = {}
    for row in rows:
        by_family.setdefault(row["task_family"], []).append(row)
    selected: list[dict] = []
    for family in sorted(by_family):
        selected.extend(by_family[family][:family_limit])
    return selected[:max_scenarios]


def scenario_messages(example: dict, observations: list[str]) -> list[dict[str, str]]:
    obs_block = "\n".join(f"- {obs}" for obs in observations) if observations else "- none yet"
    user_payload = (
        f"Operator request: {example['query']}\n"
        f"Observed tool results so far:\n{obs_block}"
    )
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_payload},
    ]


def run_agent_on_example(
    model: LocalChatModel,
    runtime: ToolStoreRuntime,
    example: dict,
    max_steps: int,
    generation_kwargs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    executed_calls: list[ExecutedCall] = []
    observations: list[str] = []
    final_answer: dict[str, Any] | str | None = None
    evidence: dict[str, Any] | None = None
    raw_responses: list[str] = []
    parse_error: str | None = None

    for step in range(max_steps):
        text = model.generate(scenario_messages(example, observations), **(generation_kwargs or {}))
        raw_responses.append(text)
        try:
            payload = extract_json_payload(text)
        except Exception as exc:
            stripped = text.strip()
            if stripped and not stripped.startswith("{") and not stripped.startswith("```"):
                final_answer = stripped
                break
            parse_error = f"json_parse_error:{type(exc).__name__}"
            break

        if isinstance(payload.get("tool_calls"), list):
            try:
                for raw_call in payload["tool_calls"]:
                    tool_name = raw_call.get("tool_name")
                    arguments = raw_call.get("arguments", {})
                    if not tool_name or not isinstance(arguments, dict):
                        raise ValueError("invalid_tool_calls_payload")
                    output = runtime.execute_tool(tool_name, arguments)
                    call = ExecutedCall(
                        call_id=f"p{len(executed_calls)+1}",
                        tool_name=tool_name,
                        arguments=arguments,
                        output=output,
                    )
                    executed_calls.append(call)
                    observations.append(ToolStoreRuntime.compact_observation(call))
            except Exception as exc:
                parse_error = f"tool_execution_error:tool_calls:{type(exc).__name__}"
                break
            final_answer = payload.get("final_answer")
            evidence = payload.get("evidence", {})
            break

        if "final_answer" in payload:
            final_answer = payload.get("final_answer")
            evidence = payload.get("evidence", {})
            break

        tool_call = payload.get("tool_call") if isinstance(payload.get("tool_call"), dict) else payload
        if not isinstance(tool_call, dict) or "tool_name" not in tool_call:
            parse_error = "missing_tool_call_or_final_answer"
            break
        tool_name = tool_call.get("tool_name")
        arguments = tool_call.get("arguments", {})
        if not tool_name or not isinstance(arguments, dict):
            parse_error = "invalid_tool_call_payload"
            break

        try:
            output = runtime.execute_tool(tool_name, arguments)
        except Exception as exc:
            parse_error = f"tool_execution_error:{tool_name}:{type(exc).__name__}"
            break

        call = ExecutedCall(
            call_id=f"p{len(executed_calls)+1}",
            tool_name=tool_name,
            arguments=arguments,
            output=output,
        )
        executed_calls.append(call)
        observations.append(ToolStoreRuntime.compact_observation(call))

    verification = verify_prediction(example, executed_calls, final_answer, evidence, runtime)
    if parse_error:
        verification.issues.append(parse_error)
        if verification.strict_label == "accomplished":
            verification.strict_label = "partially_accomplished"

    return {
        "scenario_id": example["scenario_id"],
        "task_family": example["task_family"],
        "site_id": example["site_id"],
        "query": example["query"],
        "executed_calls": [call.as_dict() for call in executed_calls],
        "final_answer": final_answer,
        "evidence": evidence,
        "raw_model_responses": raw_responses,
        "parse_error": parse_error,
        "verification": verification.as_dict(),
    }


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    labels: dict[str, int] = {}
    for row in rows:
        label = row["verification"]["label"]
        labels[label] = labels.get(label, 0) + 1
    return {
        "scenario_count": len(rows),
        "label_counts": labels,
        "strict_label_counts": {label: sum(1 for row in rows if row["verification"].get("strict_label") == label) for label in ["accomplished", "partially_accomplished", "not_accomplished"]},
        "mean_process_score": round(mean(row["verification"]["process_score"] for row in rows), 4) if rows else 0.0,
        "mean_final_score": round(mean(row["verification"]["final_score"] for row in rows), 4) if rows else 0.0,
        "mean_evidence_score": round(mean(row["verification"]["evidence_score"] for row in rows), 4) if rows else 0.0,
        "mean_core_score": round(mean(row["verification"]["core_score"] for row in rows), 4) if rows else 0.0,
        "mean_reporting_score": round(mean(row["verification"]["reporting_score"] for row in rows), 4) if rows else 0.0,
        "mean_grounding_score": round(mean(row["verification"]["grounding_score"] for row in rows), 4) if rows else 0.0,
        "mean_temporal_score": round(mean(row["verification"]["temporal_score"] for row in rows), 4) if rows else 0.0,
        "mean_task_score": round(mean(row["verification"]["task_score"] for row in rows), 4) if rows else 0.0,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--benchmark-dir", type=Path, required=True)
    parser.add_argument("--split", choices=["train", "dev", "test"], default="dev")
    parser.add_argument("--model", required=True)
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-summary", type=Path, required=True)
    parser.add_argument("--max-scenarios", type=int, default=18)
    parser.add_argument("--family-limit", type=int, default=2, help="Per-family cap. Use 0 to disable family balancing.")
    parser.add_argument("--max-steps", type=int, default=4)
    parser.add_argument("--max-new-tokens", type=int, default=256)
    args = parser.parse_args()

    rows = load_jsonl(args.benchmark_dir / f"{args.split}.jsonl")
    subset = select_subset(rows, args.max_scenarios, args.family_limit)
    runtime = ToolStoreRuntime(args.tool_store_db)
    model = LocalChatModel(args.model, max_new_tokens=args.max_new_tokens)

    results: list[dict[str, Any]] = []
    total = len(subset)
    for idx, example in enumerate(subset, start=1):
        results.append(run_agent_on_example(model, runtime, example, args.max_steps))
        if idx == 1 or idx == total or idx % 10 == 0:
            print(f"[progress] {idx}/{total} {example['scenario_id']}", flush=True)
    summary = summarize(results)
    summary["model"] = args.model
    summary["split"] = args.split

    args.out_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with args.out_jsonl.open("w", encoding="utf-8") as handle:
        for row in results:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    args.out_summary.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
