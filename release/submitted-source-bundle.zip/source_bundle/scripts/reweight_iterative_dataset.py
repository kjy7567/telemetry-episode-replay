#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Any


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def parse_stage_weights(values: list[str]) -> dict[str, float]:
    weights: dict[str, float] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"stage weights must use STAGE=WEIGHT, got {value!r}")
        stage, raw_weight = value.split("=", 1)
        stage = stage.strip()
        if not stage:
            raise ValueError(f"empty stage in {value!r}")
        weight = float(raw_weight)
        if weight <= 0:
            raise ValueError(f"stage weight must be positive, got {value!r}")
        weights[stage] = weight
    return weights


def reweight_rows(
    rows: list[dict[str, Any]],
    hard_families: set[str],
    hard_family_weight: float,
    stage_weights: dict[str, float],
) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in rows:
        weight = float(row.get("sample_weight", 1.0))
        if row.get("task_family") in hard_families:
            weight *= hard_family_weight
        weight *= stage_weights.get(str(row.get("stage")), 1.0)
        new_row = dict(row)
        new_row["sample_weight"] = round(weight, 6)
        out.append(new_row)
    return out


def split_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    weights = [float(row.get("sample_weight", 1.0)) for row in rows]
    return {
        "examples": len(rows),
        "sample_weight_mean": round(mean(weights), 4) if weights else 0.0,
        "sample_weight_max": max(weights) if weights else 0.0,
        "stage_counts": dict(Counter(row.get("stage") for row in rows)),
        "family_counts": dict(Counter(row.get("task_family") for row in rows)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--hard-family", action="append", default=[])
    parser.add_argument("--hard-family-weight", type=float, default=1.0)
    parser.add_argument("--stage-weight", action="append", default=[])
    args = parser.parse_args()

    if args.hard_family_weight <= 0:
        raise ValueError("--hard-family-weight must be positive")
    hard_families = set(args.hard_family)
    stage_weights = parse_stage_weights(args.stage_weight)

    train_rows = reweight_rows(
        load_jsonl(args.input_dir / "train.jsonl"),
        hard_families,
        args.hard_family_weight,
        stage_weights,
    )
    dev_rows = reweight_rows(
        load_jsonl(args.input_dir / "dev.jsonl"),
        hard_families,
        args.hard_family_weight,
        stage_weights,
    )

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.out_dir / "train.jsonl", train_rows)
    write_jsonl(args.out_dir / "dev.jsonl", dev_rows)

    manifest = {
        "source": "reweighted_iterative_dataset",
        "input_dir": str(args.input_dir),
        "hard_families": sorted(hard_families),
        "hard_family_weight": args.hard_family_weight,
        "stage_weights": stage_weights,
        "train": split_summary(train_rows),
        "dev": split_summary(dev_rows),
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
