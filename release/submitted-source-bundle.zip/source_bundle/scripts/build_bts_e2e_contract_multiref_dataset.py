#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


STAGE_WEIGHT_DEFAULTS = {
    "tool_call": 1.0,
    "clarification_question": 1.0,
    "final_answer": 1.0,
    "evidence_followup_answer": 1.35,
    "rationale_followup_answer": 1.35,
}


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_call(call: dict[str, Any]) -> dict[str, Any]:
    return {
        "tool_name": call["tool_name"],
        "arguments": call.get("arguments", {}),
    }


def call_key(call: dict[str, Any]) -> str:
    return json.dumps(normalize_call(call), sort_keys=True, ensure_ascii=False)


def tool_call_text(call: dict[str, Any]) -> str:
    return json.dumps(normalize_call(call), ensure_ascii=False, sort_keys=True)


def stage_weights_from_args(args: argparse.Namespace) -> dict[str, float]:
    weights = dict(STAGE_WEIGHT_DEFAULTS)
    if args.tool_weight is not None:
        weights["tool_call"] = args.tool_weight
    if args.clarify_weight is not None:
        weights["clarification_question"] = args.clarify_weight
    if args.final_weight is not None:
        weights["final_answer"] = args.final_weight
    if args.evidence_weight is not None:
        weights["evidence_followup_answer"] = args.evidence_weight
    if args.rationale_weight is not None:
        weights["rationale_followup_answer"] = args.rationale_weight
    return weights


def compute_tool_positions(rows: list[dict[str, Any]]) -> dict[tuple[str, int], int]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["scenario_id"]].append(row)

    result: dict[tuple[str, int], int] = {}
    for scenario_id, scenario_rows in grouped.items():
        tool_pos = 0
        for row in sorted(scenario_rows, key=lambda item: int(item["step_index"])):
            if row["stage"] != "tool_call":
                continue
            result[(scenario_id, int(row["step_index"]))] = tool_pos
            tool_pos += 1
    return result


def compatible_alternative_calls(scenario: dict[str, Any], tool_pos: int) -> list[dict[str, Any]]:
    canonical = [normalize_call(call) for call in scenario.get("canonical_tool_calls", [])]
    acceptable_sets = scenario.get("acceptable_tool_call_sets", [])
    if tool_pos >= len(canonical):
        return []

    prefix = canonical[:tool_pos]
    admissible: list[dict[str, Any]] = []
    seen: set[str] = set()
    for call_set in acceptable_sets:
        normalized_set = [normalize_call(call) for call in call_set]
        if len(normalized_set) <= tool_pos:
            continue
        if normalized_set[:tool_pos] != prefix:
            continue
        current = normalized_set[tool_pos]
        key = call_key(current)
        if key in seen:
            continue
        admissible.append(current)
        seen.add(key)

    if not admissible:
        admissible.append(canonical[tool_pos])
    return admissible


def transform_rows(
    iterative_rows: list[dict[str, Any]],
    scenarios: dict[str, dict[str, Any]],
    stage_weights: dict[str, float],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    tool_positions = compute_tool_positions(iterative_rows)
    transformed: list[dict[str, Any]] = []
    alt_stats = Counter()

    for row in iterative_rows:
        out_row = dict(row)
        stage = row["stage"]
        out_row["sample_weight"] = float(row.get("sample_weight", 1.0)) * stage_weights.get(stage, 1.0)
        out_row["contract_method"] = "contract_multiref_weighted"

        if stage == "tool_call":
            scenario = scenarios.get(row["scenario_id"])
            if scenario is not None:
                tool_pos = tool_positions[(row["scenario_id"], int(row["step_index"]))]
                admissible = compatible_alternative_calls(scenario, tool_pos)
                out_row["alternative_contents"] = [tool_call_text(call) for call in admissible]
                alt_stats[len(admissible)] += 1
            else:
                out_row["alternative_contents"] = [row["messages"][-1]["content"]]
                alt_stats["missing_scenario"] += 1
        transformed.append(out_row)

    manifest = {
        "method": "contract_multiref_weighted",
        "input_rows": len(iterative_rows),
        "output_rows": len(transformed),
        "stage_weights": stage_weights,
        "tool_alternative_count_histogram": dict(alt_stats),
    }
    return transformed, manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--iterative-jsonl", type=Path, required=True)
    parser.add_argument("--scenario-jsonl", type=Path, required=True)
    parser.add_argument("--out-jsonl", type=Path, required=True)
    parser.add_argument("--out-manifest", type=Path, required=True)
    parser.add_argument("--tool-weight", type=float, default=None)
    parser.add_argument("--clarify-weight", type=float, default=None)
    parser.add_argument("--final-weight", type=float, default=None)
    parser.add_argument("--evidence-weight", type=float, default=None)
    parser.add_argument("--rationale-weight", type=float, default=None)
    args = parser.parse_args()

    iterative_rows = load_jsonl(args.iterative_jsonl)
    scenarios = {row["scenario_id"]: row for row in load_jsonl(args.scenario_jsonl)}
    stage_weights = stage_weights_from_args(args)

    transformed, manifest = transform_rows(iterative_rows, scenarios, stage_weights)
    manifest.update(
        {
            "iterative_jsonl": str(args.iterative_jsonl),
            "scenario_jsonl": str(args.scenario_jsonl),
            "out_jsonl": str(args.out_jsonl),
        }
    )

    write_jsonl(args.out_jsonl, transformed)
    args.out_manifest.parent.mkdir(parents=True, exist_ok=True)
    args.out_manifest.write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
