#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

from bts_agentbench.taskbench_export import convert_example, load_jsonl


def build_anchor_rows(benchmark_dirs: list[Path]) -> list[dict]:
    rows = []
    for benchmark_dir in benchmark_dirs:
        corpus = benchmark_dir.parent.name if benchmark_dir.parent.name != "data" else "bts"
        for example in load_jsonl(benchmark_dir / "train.jsonl"):
            row = convert_example(example, "full_agent")
            row["source"] = "anchor_control"
            row["corpus"] = corpus
            rows.append(row)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark-dir", type=Path, action="append", required=True)
    parser.add_argument("--target-count", type=int, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    anchor_rows = build_anchor_rows(args.benchmark_dir)
    dev_rows = []
    for benchmark_dir in args.benchmark_dir:
        corpus = benchmark_dir.parent.name if benchmark_dir.parent.name != "data" else "bts"
        for example in load_jsonl(benchmark_dir / "dev.jsonl"):
            row = convert_example(example, "full_agent")
            row["source"] = "anchor_control"
            row["corpus"] = corpus
            dev_rows.append(row)

    buckets: dict[tuple[str, str, str], list[dict]] = defaultdict(list)
    for row in anchor_rows:
        buckets[(row["corpus"], row["task_family"], row["site_id"])].append(row)

    ordered_keys = sorted(buckets)
    cursor = {key: 0 for key in ordered_keys}
    sampled: list[dict] = []
    while len(sampled) < args.target_count:
        for key in ordered_keys:
            if len(sampled) >= args.target_count:
                break
            bucket = buckets[key]
            row = bucket[cursor[key] % len(bucket)]
            cursor[key] += 1
            sampled.append(row)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    with (args.out_dir / "train.jsonl").open("w", encoding="utf-8") as handle:
        for row in sampled:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    with (args.out_dir / "dev.jsonl").open("w", encoding="utf-8") as handle:
        for row in dev_rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")

    manifest = {
        "target_count": args.target_count,
        "actual_count": len(sampled),
        "bucket_count": len(ordered_keys),
        "benchmark_dirs": [str(path) for path in args.benchmark_dir],
    }
    (args.out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
