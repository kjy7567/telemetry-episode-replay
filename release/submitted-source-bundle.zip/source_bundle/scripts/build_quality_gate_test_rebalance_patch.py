#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from collections import Counter
from pathlib import Path
from types import ModuleType
from typing import Any

from bts_agentbench.bts_e2e import audit_bts_e2e, build_bts_e2e, load_jsonl, write_jsonl


REPO_ROOT = Path(__file__).resolve().parents[1]
SPLITS = ("train", "dev", "test")
QUALITY_FAMILY = "quality_gate"


def load_module(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"could not load module from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def quarter_bucket(value: str) -> str:
    month = int(str(value)[5:7])
    quarter = ((month - 1) // 3) + 1
    return f"Q{quarter}"


def pick_diverse_healthy(rows: list[dict[str, Any]], count: int) -> list[dict[str, Any]]:
    chosen: list[dict[str, Any]] = []
    seen_keys: set[tuple[str, str]] = set()
    for row in sorted(rows, key=lambda item: item["scenario_id"]):
        key = (str(row["metadata"].get("point_class")), quarter_bucket(str(row["metadata"].get("window_start"))))
        if key in seen_keys:
            continue
        chosen.append(copy.deepcopy(row))
        seen_keys.add(key)
        if len(chosen) == count:
            return chosen
    for row in sorted(rows, key=lambda item: item["scenario_id"]):
        if len(chosen) == count:
            return chosen
        if row["scenario_id"] in {item["scenario_id"] for item in chosen}:
            continue
        chosen.append(copy.deepcopy(row))
    if len(chosen) != count:
        raise ValueError(f"expected {count} healthy rows, found {len(chosen)}")
    return chosen


def patch_static_quality_rows(source_static_dir: Path, out_static_dir: Path) -> dict[str, Any]:
    split_rows = {split: load_jsonl(source_static_dir / f"{split}.jsonl") for split in SPLITS}
    train_quality = [row for row in split_rows["train"] if row["task_family"] == QUALITY_FAMILY]
    test_quality = [row for row in split_rows["test"] if row["task_family"] == QUALITY_FAMILY]

    healthy_train = [row for row in train_quality if row["gold_final_answer"]["decision"] == "answer"]
    abstain_test = [row for row in test_quality if row["gold_final_answer"]["decision"] == "abstain"]
    low_coverage_test = [row for row in abstain_test if row["gold_final_answer"].get("reason") == "low_coverage"]
    swap_count = 4
    if len(healthy_train) < swap_count or len(low_coverage_test) < swap_count:
        raise ValueError("insufficient rows for quality-gate rebalance")

    incoming_test_rows = pick_diverse_healthy(healthy_train, swap_count)
    outgoing_test_rows = [copy.deepcopy(row) for row in sorted(low_coverage_test, key=lambda item: item["scenario_id"])[:swap_count]]
    target_test_ids = [row["scenario_id"] for row in outgoing_test_rows]
    source_train_ids = [row["scenario_id"] for row in incoming_test_rows]

    remap_to_test: dict[str, dict[str, Any]] = {}
    for target_id, src_row in zip(target_test_ids, incoming_test_rows):
        patched = copy.deepcopy(src_row)
        patched["scenario_id"] = target_id
        patched["split"] = "test"
        remap_to_test[target_id] = patched

    remap_to_train: dict[str, dict[str, Any]] = {}
    for target_id, src_row in zip(source_train_ids, outgoing_test_rows):
        patched = copy.deepcopy(src_row)
        patched["scenario_id"] = target_id
        patched["split"] = "train"
        remap_to_train[target_id] = patched

    out_static_dir.mkdir(parents=True, exist_ok=True)
    for split in SPLITS:
        patched_rows: list[dict[str, Any]] = []
        for row in split_rows[split]:
            if row["task_family"] != QUALITY_FAMILY:
                patched_rows.append(copy.deepcopy(row))
                continue
            if split == "test" and row["scenario_id"] in remap_to_test:
                patched_rows.append(copy.deepcopy(remap_to_test[row["scenario_id"]]))
            elif split == "train" and row["scenario_id"] in remap_to_train:
                patched_rows.append(copy.deepcopy(remap_to_train[row["scenario_id"]]))
            else:
                patched_rows.append(copy.deepcopy(row))
        write_jsonl(out_static_dir / f"{split}.jsonl", patched_rows)

    registry = source_static_dir / "scenario_tool_registry.json"
    if registry.exists():
        (out_static_dir / "scenario_tool_registry.json").write_text(registry.read_text(encoding="utf-8"), encoding="utf-8")

    report = {
        "swap_count": swap_count,
        "train_source_ids_to_test": source_train_ids,
        "test_source_ids_to_train": target_test_ids,
        "before": {
            "train": dict(Counter(row["gold_final_answer"]["decision"] for row in train_quality)),
            "test": dict(Counter(row["gold_final_answer"]["decision"] for row in test_quality)),
        },
    }
    after = {}
    for split in SPLITS:
        qrows = [row for row in load_jsonl(out_static_dir / f"{split}.jsonl") if row["task_family"] == QUALITY_FAMILY]
        after[split] = {
            "decision_counts": dict(Counter(row["gold_final_answer"]["decision"] for row in qrows)),
            "reason_counts": dict(Counter(row["gold_final_answer"].get("reason") for row in qrows)),
            "site_counts": dict(Counter(row["site_id"] for row in qrows)),
        }
    report["after"] = after

    manifest = json.loads((source_static_dir / "manifest.json").read_text(encoding="utf-8"))
    manifest["quality_gate_test_rebalance"] = {
        "enabled": True,
        "swap_count": swap_count,
        "motivation": "avoid single-class quality_gate test split when the heldout site contains only abstain windows",
        "report": after,
    }
    write_json(out_static_dir / "manifest.json", manifest)
    write_json(out_static_dir / "quality_gate_test_rebalance_report.json", report)
    return report


def build_final_with_replacements(
    *,
    source_final_dir: Path,
    patched_agentic_dir: Path,
    out_final_dir: Path,
    tool_store_db: Path,
) -> dict[str, Any]:
    qg_module = load_module(
        "build_quality_gate_week_conditioned_patch_module",
        REPO_ROOT / "scripts" / "build_quality_gate_week_conditioned_patch.py",
    )
    temporal_module = load_module(
        "build_temporal_clarify_policy_patch_module",
        REPO_ROOT / "scripts" / "build_temporal_clarify_policy_patch.py",
    )
    adv_module = load_module(
        "build_bts_e2e_adversarial_from_solver_module_runtime",
        REPO_ROOT / "scripts" / "build_bts_e2e_adversarial_from_solver.py",
    )
    transformed_quality_rows = qg_module.build_quality_transformed_rows(patched_agentic_dir, tool_store_db)

    out_final_dir.mkdir(parents=True, exist_ok=True)
    split_reports: dict[str, dict[str, int]] = {}
    for split in SPLITS:
        stats: Counter[str] = Counter()
        out_rows: list[dict[str, Any]] = []
        for row in load_jsonl(source_final_dir / f"{split}.jsonl"):
            working = copy.deepcopy(row)
            if working["task_family"] == QUALITY_FAMILY:
                replacement = transformed_quality_rows[split].get(working["scenario_id"])
                if replacement is None:
                    raise KeyError(f"missing transformed quality row for {working['scenario_id']}")
                working = copy.deepcopy(replacement)
                stats["quality_rows_replaced"] += 1
            patched, row_stats = temporal_module.patch_final_row(working, adv_module)
            out_rows.append(patched)
            stats.update(row_stats)
        write_jsonl(out_final_dir / f"{split}.jsonl", out_rows)
        split_reports[split] = dict(stats)

    registry = patched_agentic_dir / "scenario_tool_registry.json"
    if registry.exists():
        (out_final_dir / "scenario_tool_registry.json").write_text(registry.read_text(encoding="utf-8"), encoding="utf-8")

    manifest = {
        "track": "bts_e2e_agentic",
        "variant": "v7_adv7_qgpatch_tcaudit_balanced",
        "source_final_dir": str(source_final_dir),
        "patched_agentic_dir": str(patched_agentic_dir),
        "quality_gate_test_rebalance": True,
        "procedural_target_answers_stripped": True,
        "split_reports": split_reports,
    }
    write_json(out_final_dir / "manifest.json", manifest)
    write_json(out_final_dir / "e2e_audit.json", audit_bts_e2e(out_final_dir))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-static-dir", type=Path, required=True)
    parser.add_argument("--source-final-dir", type=Path, required=True)
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--out-static-dir", type=Path, required=True)
    parser.add_argument("--out-e2e-dir", type=Path, required=True)
    parser.add_argument("--out-agentic-dir", type=Path, required=True)
    parser.add_argument("--out-final-dir", type=Path, required=True)
    args = parser.parse_args()

    rebalance_report = patch_static_quality_rows(args.source_static_dir, args.out_static_dir)
    build_bts_e2e(args.out_static_dir, args.out_e2e_dir)
    write_json(args.out_e2e_dir / "e2e_audit.json", audit_bts_e2e(args.out_e2e_dir))

    agentic_module = load_module("build_bts_e2e_agentic_module", REPO_ROOT / "scripts" / "build_bts_e2e_agentic.py")
    agentic_manifest = agentic_module.build_agentic_bts_e2e(args.out_static_dir, args.out_agentic_dir)
    write_json(args.out_agentic_dir / "manifest.json", agentic_manifest)
    write_json(args.out_agentic_dir / "e2e_audit.json", audit_bts_e2e(args.out_agentic_dir))

    final_manifest = build_final_with_replacements(
        source_final_dir=args.source_final_dir,
        patched_agentic_dir=args.out_agentic_dir,
        out_final_dir=args.out_final_dir,
        tool_store_db=args.tool_store_db,
    )
    print(json.dumps({
        "rebalance_report": rebalance_report,
        "agentic_manifest": agentic_manifest,
        "final_manifest": final_manifest,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
