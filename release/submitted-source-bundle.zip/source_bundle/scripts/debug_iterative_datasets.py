#!/usr/bin/env python
from __future__ import annotations

import json
import sys

sys.path.insert(0, "/workspace/BTS-AgentBench/scripts")
import train_qwen3_messages_lora as tq  # noqa: E402
from transformers import AutoTokenizer  # noqa: E402


def main() -> None:
    tokenizer = AutoTokenizer.from_pretrained("/workspace/model-cache/Qwen3-8B")
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    configs = [
        ("plain_dev", "/workspace/BTS-AgentBench/data/current_surface_multicorpus_fullagent_operator/dev.jsonl", 1152),
        ("iter_anchor_dev", "/workspace/BTS-AgentBench/data/current_surface_multicorpus_iterative_anchor_operator/dev.jsonl", 768),
        ("iter_repair_dev", "/workspace/BTS-AgentBench/data/current_surface_multicorpus_iterative_repair_operator_subset/dev.jsonl", 768),
        ("iter_anchor_train", "/workspace/BTS-AgentBench/data/current_surface_multicorpus_iterative_anchor_operator/train.jsonl", 768),
        ("iter_repair_train", "/workspace/BTS-AgentBench/data/current_surface_multicorpus_iterative_repair_operator_subset/train.jsonl", 768),
    ]

    for name, path, max_len in configs:
        rows = [json.loads(line) for line in open(path)]
        zero_examples = []
        stats: dict[tuple[str | None, str], list[int]] = {}
        for idx, row in enumerate(rows):
            enc = tq.encode_chat_example(row, tokenizer, max_len)
            supervised = sum(1 for value in enc["labels"] if value != -100)
            key = (row.get("stage"), row.get("source", "?"))
            total, zero = stats.get(key, [0, 0])
            total += 1
            if supervised == 0:
                zero += 1
                if len(zero_examples) < 10:
                    zero_examples.append(
                        {
                            "idx": idx,
                            "scenario_id": row.get("scenario_id"),
                            "stage": row.get("stage"),
                            "source": row.get("source"),
                            "task_family": row.get("task_family"),
                        }
                    )
            stats[key] = [total, zero]
        print(f"\n## {name} rows={len(rows)} zero_supervised={sum(v[1] for v in stats.values())}")
        print(json.dumps(zero_examples, indent=2))
        print(json.dumps({f"{k[0]}::{k[1]}": {"total": v[0], "zero": v[1]} for k, v in stats.items()}, indent=2))


if __name__ == "__main__":
    main()
