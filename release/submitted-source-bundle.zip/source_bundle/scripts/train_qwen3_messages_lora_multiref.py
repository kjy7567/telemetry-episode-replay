#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from datasets import Dataset
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments


IGNORE_INDEX = -100


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _truncate_prompt_and_responses(
    prompt_ids: list[int],
    response_options: list[list[int]],
    max_length: int,
) -> tuple[list[int], list[list[int]]]:
    truncated_responses = [response_ids[-max_length:] if len(response_ids) >= max_length else response_ids for response_ids in response_options]
    max_resp_len = max(len(response_ids) for response_ids in truncated_responses)
    kept_prompt_len = max(max_length - max_resp_len, 0)
    kept_prompt = prompt_ids[-kept_prompt_len:] if kept_prompt_len > 0 else []
    response_keep = max_length - len(kept_prompt)
    return kept_prompt, [response_ids[:response_keep] for response_ids in truncated_responses]


def encode_chat_example(example: dict[str, Any], tokenizer: AutoTokenizer, max_length: int) -> dict[str, Any]:
    prompt_text = tokenizer.apply_chat_template(
        example["messages"][:-1],
        tokenize=False,
        add_generation_prompt=True,
    )
    prompt_ids = tokenizer(prompt_text, add_special_tokens=False).input_ids

    primary_text = example["messages"][-1]["content"]
    alternative_texts = list(dict.fromkeys(example.get("alternative_contents") or [primary_text]))
    if primary_text not in alternative_texts:
        alternative_texts.append(primary_text)
    alternative_response_ids = [
        tokenizer(text, add_special_tokens=False).input_ids for text in alternative_texts
    ]
    prompt_ids, alternative_response_ids = _truncate_prompt_and_responses(prompt_ids, alternative_response_ids, max_length)

    primary_response_ids = tokenizer(primary_text, add_special_tokens=False).input_ids
    _, [primary_response_ids] = _truncate_prompt_and_responses(prompt_ids, [primary_response_ids], max_length)
    input_ids = prompt_ids + primary_response_ids
    labels = [IGNORE_INDEX] * len(prompt_ids) + primary_response_ids
    supervised_token_count = len(primary_response_ids)

    return {
        "input_ids": input_ids,
        "attention_mask": [1] * len(input_ids),
        "labels": labels,
        "sample_weight": float(example.get("sample_weight", 1.0)),
        "prompt_ids": prompt_ids,
        "alternative_response_ids": alternative_response_ids,
        "scenario_id": example.get("scenario_id"),
        "task_family": example.get("task_family"),
        "site_id": example.get("site_id"),
        "source": example.get("source", "unknown"),
        "query": example.get("query"),
        "stage": example.get("stage"),
        "supervised_token_count": supervised_token_count,
        "alternative_count": len(alternative_response_ids),
    }


class PackedDataCollator:
    def __init__(self, tokenizer: AutoTokenizer):
        self.pad_id = tokenizer.pad_token_id

    def __call__(self, features: list[dict[str, Any]]) -> dict[str, Any]:
        max_len = max(len(feature["input_ids"]) for feature in features)
        input_ids = []
        attention_mask = []
        labels = []
        sample_weight = []
        prompt_ids = []
        alternative_response_ids = []
        for feature in features:
            pad = max_len - len(feature["input_ids"])
            input_ids.append(feature["input_ids"] + [self.pad_id] * pad)
            attention_mask.append(feature["attention_mask"] + [0] * pad)
            labels.append(feature["labels"] + [IGNORE_INDEX] * pad)
            sample_weight.append(float(feature.get("sample_weight", 1.0)))
            prompt_ids.append(feature["prompt_ids"])
            alternative_response_ids.append(feature["alternative_response_ids"])
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "sample_weight": torch.tensor(sample_weight, dtype=torch.float32),
            "prompt_ids_list": prompt_ids,
            "alternative_response_ids_list": alternative_response_ids,
        }


class MultiRefWeightedSFTTrainer(Trainer):
    def _sequence_avg_logprob(
        self,
        model,
        prompt_ids: list[int],
        response_ids: list[int],
        device: torch.device,
    ) -> torch.Tensor:
        if not response_ids:
            return torch.tensor(-100.0, device=device)
        sequence = torch.tensor(prompt_ids + response_ids, dtype=torch.long, device=device).unsqueeze(0)
        attention_mask = torch.ones_like(sequence)
        labels = torch.tensor([IGNORE_INDEX] * len(prompt_ids) + response_ids, dtype=torch.long, device=device).unsqueeze(0)
        outputs = model(input_ids=sequence, attention_mask=attention_mask)
        logits = outputs.logits
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()
        token_loss = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
            reduction="none",
            ignore_index=IGNORE_INDEX,
        ).view(shift_labels.size())
        valid_mask = (shift_labels != IGNORE_INDEX).float()
        valid_count = valid_mask.sum().clamp(min=1.0)
        avg_nll = (token_loss * valid_mask).sum() / valid_count
        return -avg_nll

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        sample_weight = inputs.pop("sample_weight")
        prompt_ids_list = inputs.pop("prompt_ids_list")
        alternative_response_ids_list = inputs.pop("alternative_response_ids_list")
        # Keep the default fields out of the model forward path. Loss is
        # recomputed from prompt/alternative sequences so multi-reference tool
        # supervision preserves a single row per scenario stage.
        inputs.pop("labels", None)
        inputs.pop("input_ids", None)
        inputs.pop("attention_mask", None)

        device = model.device
        per_example_losses = []
        for prompt_ids, alternatives in zip(prompt_ids_list, alternative_response_ids_list):
            alt_logprobs = [
                self._sequence_avg_logprob(model, prompt_ids, response_ids, device) for response_ids in alternatives
            ]
            alt_logprobs_tensor = torch.stack(alt_logprobs)
            loss = -(torch.logsumexp(alt_logprobs_tensor, dim=0) - math.log(len(alt_logprobs)))
            per_example_losses.append(loss)

        per_example_loss = torch.stack(per_example_losses)
        weight = sample_weight.to(per_example_loss.device)
        loss = (per_example_loss * weight).sum() / weight.sum().clamp(min=1e-6)
        return (loss, {"loss": loss.detach()}) if return_outputs else loss


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--train-jsonl", type=Path, required=True)
    parser.add_argument("--dev-jsonl", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-length", type=int, default=1152)
    parser.add_argument("--num-train-epochs", type=float, default=1.0)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--per-device-train-batch-size", type=int, default=1)
    parser.add_argument("--per-device-eval-batch-size", type=int, default=1)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=8)
    parser.add_argument("--lora-r", type=int, default=16)
    parser.add_argument("--lora-alpha", type=int, default=32)
    parser.add_argument("--lora-dropout", type=float, default=0.05)
    parser.add_argument("--logging-steps", type=int, default=10)
    args = parser.parse_args()

    if args.per_device_train_batch_size != 1 or args.per_device_eval_batch_size != 1:
        raise ValueError("train_qwen3_messages_lora_multiref.py currently requires batch size 1.")

    args.out_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(str(args.model))
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_rows = load_jsonl(args.train_jsonl)
    dev_rows = load_jsonl(args.dev_jsonl)

    raw_train_records = [encode_chat_example(row, tokenizer, args.max_length) for row in train_rows]
    raw_dev_records = [encode_chat_example(row, tokenizer, args.max_length) for row in dev_rows]

    train_dropped = sum(1 for record in raw_train_records if record["supervised_token_count"] == 0)
    dev_dropped = sum(1 for record in raw_dev_records if record["supervised_token_count"] == 0)
    train_records = [record for record in raw_train_records if record["supervised_token_count"] > 0]
    dev_records = [record for record in raw_dev_records if record["supervised_token_count"] > 0]

    train_dataset = Dataset.from_list(train_records)
    dev_dataset = Dataset.from_list(dev_records)

    model = AutoModelForCausalLM.from_pretrained(
        str(args.model),
        torch_dtype=torch.bfloat16,
    )
    model.config.use_cache = False
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

    lora_config = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora_config)
    model.enable_input_require_grads()
    model.print_trainable_parameters()

    training_args = TrainingArguments(
        output_dir=str(args.out_dir),
        overwrite_output_dir=True,
        num_train_epochs=args.num_train_epochs,
        learning_rate=args.learning_rate,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        bf16=True,
        eval_strategy="no",
        save_strategy="epoch",
        save_total_limit=2,
        logging_steps=args.logging_steps,
        report_to=[],
        remove_unused_columns=False,
        dataloader_pin_memory=False,
        optim="adamw_torch",
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
    )

    trainer = MultiRefWeightedSFTTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=dev_dataset,
        data_collator=PackedDataCollator(tokenizer),
    )

    manifest = {
        "base_model": str(args.model),
        "train_jsonl": str(args.train_jsonl),
        "dev_jsonl": str(args.dev_jsonl),
        "train_examples": len(train_records),
        "dev_examples": len(dev_records),
        "train_examples_raw": len(raw_train_records),
        "dev_examples_raw": len(raw_dev_records),
        "train_examples_dropped_zero_supervision": train_dropped,
        "dev_examples_dropped_zero_supervision": dev_dropped,
        "train_sample_weight_mean": sum(record["sample_weight"] for record in train_records) / len(train_records) if train_records else 0.0,
        "dev_sample_weight_mean": sum(record["sample_weight"] for record in dev_records) / len(dev_records) if dev_records else 0.0,
        "train_alternative_count_mean": sum(record["alternative_count"] for record in train_records) / len(train_records) if train_records else 0.0,
        "dev_alternative_count_mean": sum(record["alternative_count"] for record in dev_records) / len(dev_records) if dev_records else 0.0,
        "max_length": args.max_length,
        "num_train_epochs": args.num_train_epochs,
        "learning_rate": args.learning_rate,
        "gradient_accumulation_steps": args.gradient_accumulation_steps,
        "per_device_train_batch_size": args.per_device_train_batch_size,
        "objective": "multiref_logmeanexp_sft",
        "lora": {
            "r": args.lora_r,
            "alpha": args.lora_alpha,
            "dropout": args.lora_dropout,
            "target_modules": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        },
    }
    (args.out_dir / "training_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    trainer.train()
    trainer.save_model()
    final_metrics = trainer.evaluate()
    (args.out_dir / "final_eval_metrics.json").write_text(json.dumps(final_metrics, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
