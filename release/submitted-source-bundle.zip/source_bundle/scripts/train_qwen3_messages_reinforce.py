#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import math
import random
import re
from collections import Counter
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer


TOOL_CALL_REWARD = 1.0
ANSWER_REWARD = 1.0
IGNORE_INDEX = -100
STREAM_ID_RE = re.compile(r"[0-9a-f]{8}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{12}", re.IGNORECASE)
TOKEN_RE = re.compile(r"[a-z0-9_:.+-]+")


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def normalize_text(text: str) -> str:
    return " ".join(text.lower().strip().split())


def tokenize_text(text: str) -> list[str]:
    return TOKEN_RE.findall(normalize_text(text))


def token_f1(pred: str, gold: str) -> float:
    pred_tokens = tokenize_text(pred)
    gold_tokens = tokenize_text(gold)
    if not pred_tokens or not gold_tokens:
        return 0.0
    pred_counts = Counter(pred_tokens)
    gold_counts = Counter(gold_tokens)
    overlap = sum(min(pred_counts[token], gold_counts[token]) for token in pred_counts.keys() & gold_counts.keys())
    if overlap == 0:
        return 0.0
    precision = overlap / len(pred_tokens)
    recall = overlap / len(gold_tokens)
    return 2 * precision * recall / max(precision + recall, 1e-8)


def try_parse_json(text: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?\s*|\s*```$", "", stripped, flags=re.DOTALL)
    try:
        parsed = json.loads(stripped)
        return parsed if isinstance(parsed, dict) else None
    except Exception:
        pass

    start = stripped.find("{")
    if start == -1:
        return None
    depth = 0
    in_string = False
    escape = False
    for idx, char in enumerate(stripped[start:], start=start):
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == "\"":
                in_string = False
            continue
        if char == "\"":
            in_string = True
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                try:
                    parsed = json.loads(stripped[start : idx + 1])
                    return parsed if isinstance(parsed, dict) else None
                except Exception:
                    return None
    return None


def _normalize_value(value: Any) -> Any:
    if isinstance(value, str):
        return normalize_text(value)
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, list):
        return [_normalize_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalize_value(item) for key, item in value.items()}
    return str(value)


def structured_tool_reward(pred_text: str, gold_text: str) -> float:
    pred = try_parse_json(pred_text)
    gold = try_parse_json(gold_text)
    if pred is None or gold is None:
        return 0.0

    pred_tool = normalize_text(str(pred.get("tool_name", "")))
    gold_tool = normalize_text(str(gold.get("tool_name", "")))
    pred_args = _normalize_value(pred.get("arguments", {}))
    gold_args = _normalize_value(gold.get("arguments", {}))
    if not isinstance(pred_args, dict) or not isinstance(gold_args, dict):
        return 0.0

    if pred_tool == gold_tool and pred_args == gold_args:
        return TOOL_CALL_REWARD

    reward = 0.0
    if pred_tool == gold_tool:
        reward += 0.4

    if gold_args:
        match_count = 0.0
        for key, gold_value in gold_args.items():
            if key not in pred_args:
                continue
            pred_value = pred_args[key]
            if pred_value == gold_value:
                match_count += 1.0
            elif isinstance(pred_value, str) and isinstance(gold_value, str):
                match_count += token_f1(pred_value, gold_value)
        reward += 0.6 * (match_count / len(gold_args))

    extra_keys = set(pred_args) - set(gold_args)
    reward -= 0.05 * len(extra_keys)
    return max(0.0, min(TOOL_CALL_REWARD, reward))


def clarification_reward(pred_text: str, gold_text: str) -> float:
    pred_norm = normalize_text(pred_text)
    gold_norm = normalize_text(gold_text)
    if pred_norm == gold_norm:
        return 1.0

    reward = 0.5 * token_f1(pred_text, gold_text)
    if "?" in pred_text:
        reward += 0.1

    gold_tokens = set(tokenize_text(gold_text))
    pred_tokens = set(tokenize_text(pred_text))
    for keyword in ["date", "day", "week", "month", "window", "timestamp", "time", "average"]:
        if keyword in gold_tokens and keyword in pred_tokens:
            reward += 0.1
    return max(0.0, min(1.0, reward))


def answer_reward(pred_text: str, gold_text: str, stage: str) -> float:
    pred_norm = normalize_text(pred_text)
    gold_norm = normalize_text(gold_text)
    if pred_norm == gold_norm:
        return ANSWER_REWARD

    reward = 0.5 * token_f1(pred_text, gold_text)

    gold_stream_ids = STREAM_ID_RE.findall(gold_text)
    if gold_stream_ids:
        hits = sum(1 for stream_id in gold_stream_ids if normalize_text(stream_id) in pred_norm)
        reward += 0.5 * (hits / len(gold_stream_ids))
    else:
        numbers = re.findall(r"\d+(?:\.\d+)?", gold_text)
        if numbers:
            hits = sum(1 for number in numbers if number in pred_text)
            reward += 0.35 * (hits / len(numbers))

        if stage == "rationale_followup_answer":
            for cue in ["answer", "abstain", "healthy", "reliable", "coverage", "gap"]:
                if cue in gold_norm and cue in pred_norm:
                    reward += 0.05

    return max(0.0, min(ANSWER_REWARD, reward))


def compute_reward(row: dict[str, Any], pred_text: str) -> float:
    gold_text = row["messages"][-1]["content"]
    stage = row["stage"]
    if stage == "tool_call":
        return structured_tool_reward(pred_text, gold_text)
    if stage == "clarification_question":
        return clarification_reward(pred_text, gold_text)
    return answer_reward(pred_text, gold_text, stage)


def stage_max_new_tokens(stage: str) -> int:
    if stage == "tool_call":
        return 96
    if stage == "clarification_question":
        return 40
    return 80


def build_prompt_ids(row: dict[str, Any], tokenizer: AutoTokenizer, max_prompt_length: int) -> torch.Tensor:
    model_inputs = tokenizer.apply_chat_template(
        row["messages"][:-1],
        add_generation_prompt=True,
        return_tensors="pt",
        return_dict=True,
        enable_thinking=False,
    )
    input_ids = model_inputs["input_ids"][0]
    if input_ids.numel() > max_prompt_length:
        input_ids = input_ids[-max_prompt_length:]
    return input_ids


def _left_pad_batch(sequences: list[torch.Tensor], pad_id: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    max_len = max(seq.numel() for seq in sequences)
    input_ids = []
    attention_masks = []
    for seq in sequences:
        pad_len = max_len - seq.numel()
        input_ids.append(torch.cat([torch.full((pad_len,), pad_id, dtype=torch.long), seq], dim=0))
        attention_masks.append(torch.cat([torch.zeros(pad_len, dtype=torch.long), torch.ones(seq.numel(), dtype=torch.long)], dim=0))
    return torch.stack(input_ids).to(device), torch.stack(attention_masks).to(device)


def _right_pad_batch(sequences: list[torch.Tensor], pad_id: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    max_len = max(seq.numel() for seq in sequences)
    input_ids = []
    attention_masks = []
    for seq in sequences:
        pad_len = max_len - seq.numel()
        input_ids.append(torch.cat([seq, torch.full((pad_len,), pad_id, dtype=torch.long)], dim=0))
        attention_masks.append(torch.cat([torch.ones(seq.numel(), dtype=torch.long), torch.zeros(pad_len, dtype=torch.long)], dim=0))
    return torch.stack(input_ids).to(device), torch.stack(attention_masks).to(device)


@torch.no_grad()
def batch_sample_response_ids(
    model: AutoModelForCausalLM,
    prompt_ids_batch: list[torch.Tensor],
    stages: list[str],
    tokenizer: AutoTokenizer,
    temperature: float,
    top_p: float,
) -> list[torch.Tensor]:
    device = next(model.parameters()).device
    input_ids, attention_mask = _left_pad_batch(prompt_ids_batch, tokenizer.pad_token_id, device)
    prompt_batch_len = input_ids.shape[1]
    outputs = model.generate(
        input_ids=input_ids,
        attention_mask=attention_mask,
        max_new_tokens=max(stage_max_new_tokens(stage) for stage in stages),
        do_sample=True,
        temperature=temperature,
        top_p=top_p,
        pad_token_id=tokenizer.pad_token_id,
        eos_token_id=tokenizer.eos_token_id,
    )
    response_batch: list[torch.Tensor] = []
    for row in outputs:
        response_ids = row[prompt_batch_len:].detach().cpu()
        while response_ids.numel() > 0 and response_ids[-1].item() == tokenizer.pad_token_id:
            response_ids = response_ids[:-1]
        response_batch.append(response_ids)
    return response_batch


def batch_sequence_logprobs(
    model: AutoModelForCausalLM,
    prompt_ids_batch: list[torch.Tensor],
    response_ids_batch: list[torch.Tensor],
    tokenizer: AutoTokenizer,
) -> torch.Tensor:
    device = next(model.parameters()).device
    full_sequences = [torch.cat([prompt_ids, response_ids], dim=0) for prompt_ids, response_ids in zip(prompt_ids_batch, response_ids_batch)]
    input_ids, attention_mask = _right_pad_batch(full_sequences, tokenizer.pad_token_id, device)
    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    shift_logits = outputs.logits[:, :-1, :]
    shift_targets = input_ids[:, 1:]
    log_probs = F.log_softmax(shift_logits.float(), dim=-1)
    selected = log_probs.gather(2, shift_targets.unsqueeze(-1)).squeeze(-1)

    loss_mask = torch.zeros_like(shift_targets, dtype=torch.float32, device=device)
    for idx, (prompt_ids, response_ids) in enumerate(zip(prompt_ids_batch, response_ids_batch)):
        prompt_len = prompt_ids.numel()
        response_len = response_ids.numel()
        if response_len == 0:
            continue
        start = max(prompt_len - 1, 0)
        end = start + response_len
        loss_mask[idx, start:end] = 1.0
    return (selected * loss_mask).sum(dim=1)


def run_epoch(
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    rows: list[dict[str, Any]],
    optimizer: torch.optim.Optimizer,
    args: argparse.Namespace,
) -> dict[str, Any]:
    random.shuffle(rows)
    model.train()

    batch_rows: list[dict[str, Any]] = []
    reward_sum = 0.0
    reward_count = 0
    step_metrics: list[dict[str, float]] = []
    optimizer.zero_grad(set_to_none=True)

    for row_idx, row in enumerate(rows, start=1):
        batch_rows.append(row)
        if len(batch_rows) < args.rl_batch_size and row_idx != len(rows):
            continue

        prompt_ids_batch = [
            build_prompt_ids(batch_row, tokenizer, max_prompt_length=args.max_length - stage_max_new_tokens(batch_row["stage"]))
            for batch_row in batch_rows
        ]
        stages = [batch_row["stage"] for batch_row in batch_rows]

        model.eval()
        response_ids_batch = batch_sample_response_ids(
            model,
            prompt_ids_batch,
            stages,
            tokenizer,
            temperature=args.temperature,
            top_p=args.top_p,
        )
        model.train()

        rewards_list: list[float] = []
        pred_texts: list[str] = []
        for batch_row, response_ids in zip(batch_rows, response_ids_batch):
            pred_text = tokenizer.decode(response_ids, skip_special_tokens=True).strip()
            pred_texts.append(pred_text)
            reward = compute_reward(batch_row, pred_text) * float(batch_row.get("sample_weight", 1.0))
            rewards_list.append(reward)
            reward_sum += reward
            reward_count += 1

        rewards = torch.tensor(rewards_list, dtype=torch.float32)
        baseline = rewards.mean().item()
        logprobs = batch_sequence_logprobs(model, prompt_ids_batch, response_ids_batch, tokenizer)
        advantages = (rewards.to(logprobs.device) - baseline)
        loss = -(advantages * logprobs).mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
        step_metrics.append(
            {
                "step": len(step_metrics) + 1,
                "row_idx": row_idx,
                "batch_reward_mean": float(rewards.mean().item()),
                "batch_reward_max": float(rewards.max().item()),
                "batch_reward_min": float(rewards.min().item()),
                "baseline": baseline,
                "loss": float(loss.detach().cpu()),
                "logprob_mean": float(logprobs.detach().mean().cpu()),
            }
        )
        if args.logging_steps > 0 and len(step_metrics) % args.logging_steps == 0:
            metric = step_metrics[-1]
            print(json.dumps(metric, ensure_ascii=False))

        batch_rows = []

    return {
        "mean_reward": reward_sum / max(reward_count, 1),
        "num_rows": reward_count,
        "optimizer_steps": len(step_metrics),
        "last_step": step_metrics[-1] if step_metrics else None,
        "step_metrics_tail": step_metrics[-10:],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--train-jsonl", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-length", type=int, default=1536)
    parser.add_argument("--num-train-epochs", type=int, default=1)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--rl-batch-size", type=int, default=4)
    parser.add_argument("--temperature", type=float, default=0.8)
    parser.add_argument("--top-p", type=float, default=0.95)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--lora-r", type=int, default=16)
    parser.add_argument("--lora-alpha", type=int, default=32)
    parser.add_argument("--lora-dropout", type=float, default=0.05)
    parser.add_argument("--max-grad-norm", type=float, default=1.0)
    parser.add_argument("--logging-steps", type=int, default=20)
    args = parser.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    args.out_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(str(args.model))
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_rows = load_jsonl(args.train_jsonl)

    model = AutoModelForCausalLM.from_pretrained(
        str(args.model),
        torch_dtype=torch.bfloat16,
    )
    model.config.use_cache = True
    model.generation_config.do_sample = True
    model.generation_config.temperature = args.temperature
    model.generation_config.top_p = args.top_p

    lora_config = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora_config)
    model.enable_input_require_grads()
    model.print_trainable_parameters()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    optimizer = torch.optim.AdamW((param for param in model.parameters() if param.requires_grad), lr=args.learning_rate)

    training_manifest = {
        "base_model": str(args.model),
        "train_jsonl": str(args.train_jsonl),
        "train_rows": len(train_rows),
        "max_length": args.max_length,
        "num_train_epochs": args.num_train_epochs,
        "learning_rate": args.learning_rate,
        "rl_batch_size": args.rl_batch_size,
        "temperature": args.temperature,
        "top_p": args.top_p,
        "seed": args.seed,
        "algorithm": "row_level_reinforce",
        "initial_policy": "base_model_with_fresh_lora",
        "lora": {
            "r": args.lora_r,
            "alpha": args.lora_alpha,
            "dropout": args.lora_dropout,
        },
    }
    (args.out_dir / "training_manifest.json").write_text(json.dumps(training_manifest, indent=2), encoding="utf-8")

    epoch_summaries = []
    for epoch in range(args.num_train_epochs):
        summary = run_epoch(model, tokenizer, train_rows, optimizer, args)
        summary["epoch"] = epoch + 1
        epoch_summaries.append(summary)
        print(json.dumps({"epoch_summary": summary}, ensure_ascii=False))

    model.save_pretrained(args.out_dir)
    tokenizer.save_pretrained(args.out_dir)
    (args.out_dir / "rl_train_metrics.json").write_text(json.dumps(epoch_summaries, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
