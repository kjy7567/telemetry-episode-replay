#!/usr/bin/env python
from __future__ import annotations

import argparse
import math
import subprocess
import sys
import time
from pathlib import Path
from zipfile import BadZipFile, ZipFile

import requests


def remote_size(url: str) -> int:
    with requests.get(url, stream=True, timeout=(30, 120)) as response:
        response.raise_for_status()
        value = response.headers.get("Content-Length")
        if not value or not value.isdigit():
            raise RuntimeError("Missing Content-Length")
        return int(value)


def spawn_range_download(url: str, path: Path, start: int, end: int) -> subprocess.Popen[str]:
    cmd = [
        "curl",
        "-L",
        "--fail",
        "--retry",
        "8",
        "--retry-all-errors",
        "--retry-delay",
        "2",
        "-r",
        f"{start}-{end}",
        "-o",
        str(path),
        url,
    ]
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True)


def part_complete(path: Path, expected_size: int) -> bool:
    return path.exists() and path.stat().st_size == expected_size


def concatenate_parts(part_paths: list[Path], output_path: Path) -> None:
    tmp = output_path.with_suffix(output_path.suffix + ".assembled")
    with tmp.open("wb") as out:
        for part in part_paths:
            with part.open("rb") as handle:
                while True:
                    chunk = handle.read(1024 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
    tmp.replace(output_path)


def validate_zip(path: Path) -> None:
    try:
        with ZipFile(path) as archive:
            bad = archive.testzip()
    except BadZipFile as exc:  # pragma: no cover - exercised in runtime
        raise RuntimeError(f"Invalid ZIP file: {path}") from exc
    if bad is not None:
        raise RuntimeError(f"ZIP validation failed at member {bad}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--parts", type=int, default=4)
    parser.add_argument("--validate-zip", action="store_true")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        print(f"already_exists {args.output} {args.output.stat().st_size}")
        if args.validate_zip and args.output.suffix == ".zip":
            validate_zip(args.output)
            print("zip_validated")
        return

    size = remote_size(args.url)
    print(f"remote_size {size}", flush=True)
    chunk = math.ceil(size / args.parts)

    part_specs = []
    for idx in range(args.parts):
        start = idx * chunk
        end = min(size - 1, (idx + 1) * chunk - 1)
        expected = end - start + 1
        part_path = args.output.parent / f"{args.output.name}.part{idx:02d}"
        part_specs.append((part_path, start, end, expected))

    processes: list[subprocess.Popen[str]] = []
    for part_path, start, end, expected in part_specs:
        if part_complete(part_path, expected):
            print(f"skip_part {part_path.name} {expected}", flush=True)
            continue
        if part_path.exists():
            part_path.unlink()
        print(f"start_part {part_path.name} {start} {end}", flush=True)
        processes.append(spawn_range_download(args.url, part_path, start, end))

    while processes:
        alive = []
        total = 0
        for part_path, _, _, _ in part_specs:
            if part_path.exists():
                total += part_path.stat().st_size
        print(f"downloaded_bytes {total}", flush=True)
        for proc in processes:
            code = proc.poll()
            if code is None:
                alive.append(proc)
            elif code != 0:
                raise RuntimeError(f"curl exited with code {code}")
        processes = alive
        if processes:
            time.sleep(5)

    for part_path, _, _, expected in part_specs:
        if not part_complete(part_path, expected):
            raise RuntimeError(f"Incomplete part {part_path.name}: expected {expected}, got {part_path.stat().st_size if part_path.exists() else 0}")

    concatenate_parts([spec[0] for spec in part_specs], args.output)
    print(f"assembled {args.output} {args.output.stat().st_size}", flush=True)

    if args.validate_zip and args.output.suffix == ".zip":
        validate_zip(args.output)
        print("zip_validated", flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"error {exc}", file=sys.stderr)
        raise
