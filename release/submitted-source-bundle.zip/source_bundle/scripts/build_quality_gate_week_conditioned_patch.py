#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
from collections import Counter
from pathlib import Path
from types import ModuleType
from typing import Any

import duckdb

from bts_agentbench.bts_e2e import audit_bts_e2e, build_bts_e2e, load_jsonl, write_jsonl
from bts_agentbench.evaluator import verify_prediction
from bts_agentbench.runtime import ToolStoreRuntime
from bts_agentbench.scenario_benchmark import generate_scenario_benchmark


REPO_ROOT = Path(__file__).resolve().parents[1]
SPLITS = ("train", "dev", "test")
QUALITY_FAMILY = "quality_gate"
TOOL_REGISTRY_VERSION = "scenario-canonical-v2"


def load_module(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"could not load module from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def patch_non_quality_row(row: dict[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(row)
    if "tool_registry_version" in out:
        out["tool_registry_version"] = TOOL_REGISTRY_VERSION
    return out


def select_quality_subset(rows: list[dict[str, Any]], target_count: int) -> tuple[list[dict[str, Any]], list[str]]:
    ordered = sorted(rows, key=lambda row: row["scenario_id"])
    if len(ordered) < target_count:
        raise ValueError(f"quality-gate probe has {len(ordered)} rows but target requires {target_count}")
    selected = ordered[:target_count]
    dropped = [row["scenario_id"] for row in ordered[target_count:]]
    return selected, dropped


def remap_quality_rows(
    *,
    split: str,
    old_rows: list[dict[str, Any]],
    probe_rows: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    old_quality_ids = [row["scenario_id"] for row in old_rows if row["task_family"] == QUALITY_FAMILY]
    probe_quality_rows = [copy.deepcopy(row) for row in probe_rows if row["task_family"] == QUALITY_FAMILY]
    selected_rows, dropped_probe_ids = select_quality_subset(probe_quality_rows, len(old_quality_ids))
    if len(selected_rows) != len(old_quality_ids):
        raise ValueError(f"quality-gate remap mismatch on {split}: {len(selected_rows)} vs {len(old_quality_ids)}")

    remapped_rows: dict[str, dict[str, Any]] = {}
    id_mapping: dict[str, str] = {}
    for old_id, new_row in zip(old_quality_ids, selected_rows):
        new_id = new_row["scenario_id"]
        patched = copy.deepcopy(new_row)
        patched["scenario_id"] = old_id
        patched["split"] = split
        if "tool_registry_version" in patched:
            patched["tool_registry_version"] = TOOL_REGISTRY_VERSION
        remapped_rows[old_id] = patched
        id_mapping[old_id] = new_id

    out_rows: list[dict[str, Any]] = []
    for row in old_rows:
        if row["task_family"] == QUALITY_FAMILY:
            out_rows.append(remapped_rows[row["scenario_id"]])
        else:
            out_rows.append(patch_non_quality_row(row))

    return out_rows, {
        "target_count": len(old_quality_ids),
        "probe_count": len(probe_quality_rows),
        "selected_probe_ids": [id_mapping[old_id] for old_id in old_quality_ids],
        "dropped_probe_ids": dropped_probe_ids,
        "id_mapping": id_mapping,
        "decision_counts": dict(Counter(row["gold_final_answer"]["decision"] for row in remapped_rows.values())),
        "reason_counts": dict(Counter(row["gold_final_answer"]["reason"] for row in remapped_rows.values())),
    }


def build_patched_static(
    *,
    old_static_dir: Path,
    probe_static_dir: Path,
    out_dir: Path,
) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    old_manifest = load_json(old_static_dir / "manifest.json")
    patch_report: dict[str, Any] = {"split_reports": {}}

    for split in SPLITS:
        old_rows = load_jsonl(old_static_dir / f"{split}.jsonl")
        probe_rows = load_jsonl(probe_static_dir / f"{split}.jsonl")
        patched_rows, split_report = remap_quality_rows(split=split, old_rows=old_rows, probe_rows=probe_rows)
        write_jsonl(out_dir / f"{split}.jsonl", patched_rows)
        patch_report["split_reports"][split] = split_report

    probe_registry = probe_static_dir / "scenario_tool_registry.json"
    if probe_registry.exists():
        (out_dir / "scenario_tool_registry.json").write_text(
            probe_registry.read_text(encoding="utf-8"),
            encoding="utf-8",
        )

    manifest = dict(old_manifest)
    manifest["source_static_dir"] = str(old_static_dir)
    manifest["quality_gate_patch"] = {
        "week_conditioned_quality_gate": True,
        "tool_registry_version": TOOL_REGISTRY_VERSION,
        "probe_static_dir": str(probe_static_dir),
        "split_reports": {
            split: {
                "target_count": report["target_count"],
                "probe_count": report["probe_count"],
                "dropped_probe_ids": report["dropped_probe_ids"],
                "decision_counts": report["decision_counts"],
                "reason_counts": report["reason_counts"],
            }
            for split, report in patch_report["split_reports"].items()
        },
    }
    write_json(out_dir / "manifest.json", manifest)
    write_json(out_dir / "quality_gate_patch_report.json", patch_report)
    return patch_report


def build_patched_e2e(static_dir: Path, out_dir: Path) -> None:
    manifest = build_bts_e2e(static_dir, out_dir)
    manifest["quality_gate_patch"] = {
        "week_conditioned_quality_gate": True,
        "source_static_dir": str(static_dir),
    }
    write_json(out_dir / "manifest.json", manifest)
    write_json(out_dir / "e2e_audit.json", audit_bts_e2e(out_dir))


def build_patched_agentic(static_dir: Path, out_dir: Path) -> None:
    module = load_module("build_bts_e2e_agentic_module", REPO_ROOT / "scripts" / "build_bts_e2e_agentic.py")
    manifest = module.build_agentic_bts_e2e(static_dir, out_dir)
    manifest["quality_gate_patch"] = {
        "week_conditioned_quality_gate": True,
        "source_static_dir": str(static_dir),
    }
    write_json(out_dir / "manifest.json", manifest)
    write_json(out_dir / "e2e_audit.json", audit_bts_e2e(out_dir))


def build_quality_transformed_rows(agentic_dir: Path, tool_store_db: Path) -> dict[str, dict[str, dict[str, Any]]]:
    module = load_module(
        "build_bts_e2e_adversarial_from_solver_module",
        REPO_ROOT / "scripts" / "build_bts_e2e_adversarial_from_solver.py",
    )
    transformed_by_split: dict[str, dict[str, dict[str, Any]]] = {}
    tool_con = duckdb.connect(str(tool_store_db))
    try:
        solved_ids = {
            row["scenario_id"]
            for split in SPLITS
            for row in load_jsonl(agentic_dir / f"{split}.jsonl")
            if row["task_family"] == QUALITY_FAMILY
        }
        for split in SPLITS:
            rows = load_jsonl(agentic_dir / f"{split}.jsonl")
            transformed_rows, _ = module.transform_split(rows, solved_ids, "adv7", tool_con=tool_con)
            transformed_by_split[split] = {
                row["scenario_id"]: row for row in transformed_rows if row["task_family"] == QUALITY_FAMILY
            }
    finally:
        tool_con.close()
    return transformed_by_split


def build_patched_final(
    *,
    old_final_dir: Path,
    patched_agentic_dir: Path,
    out_dir: Path,
    tool_store_db: Path,
    static_patch_report: dict[str, Any],
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    transformed_quality_rows = build_quality_transformed_rows(patched_agentic_dir, tool_store_db)

    for split in SPLITS:
        old_rows = load_jsonl(old_final_dir / f"{split}.jsonl")
        out_rows: list[dict[str, Any]] = []
        for row in old_rows:
            if row["task_family"] == QUALITY_FAMILY:
                replacement = transformed_quality_rows[split].get(row["scenario_id"])
                if replacement is None:
                    raise KeyError(f"missing patched quality-gate row for {row['scenario_id']}")
                out_rows.append(replacement)
            else:
                out_rows.append(copy.deepcopy(row))
        write_jsonl(out_dir / f"{split}.jsonl", out_rows)

    tool_registry = patched_agentic_dir / "scenario_tool_registry.json"
    if tool_registry.exists():
        (out_dir / "scenario_tool_registry.json").write_text(tool_registry.read_text(encoding="utf-8"), encoding="utf-8")

    manifest = {
        "track": "bts_e2e_agentic",
        "variant": "v7_adv7_qgpatch",
        "source_final_dir": str(old_final_dir),
        "quality_gate_patch_source_agentic_dir": str(patched_agentic_dir),
        "quality_gate_week_conditioned": True,
        "semantic_change": {
            "quality_tool": "inspect_quality_window",
            "quality_conditioning": "week-conditioned",
            "explicit_week_in_prompt": True,
        },
        "split_reports": {
            split: {
                "replaced_rows": len(transformed_quality_rows[split]),
                "decision_counts": dict(Counter(row["gold_final_answer"]["decision"] for row in transformed_quality_rows[split].values())),
                "reason_counts": dict(Counter(row["gold_final_answer"]["reason"] for row in transformed_quality_rows[split].values())),
            }
            for split in SPLITS
        },
        "static_quality_gate_patch_report": static_patch_report,
    }
    write_json(out_dir / "manifest.json", manifest)
    write_json(out_dir / "e2e_audit.json", audit_bts_e2e(out_dir))


def validate_quality_gate_rows(benchmark_dir: Path, tool_store_db: Path, *, require_hidden_week: bool) -> dict[str, Any]:
    runtime = ToolStoreRuntime(tool_store_db)
    try:
        checked = 0
        failed: list[dict[str, Any]] = []
        for split in SPLITS:
            for row in load_jsonl(benchmark_dir / f"{split}.jsonl"):
                if row["task_family"] != QUALITY_FAMILY:
                    continue
                quality_calls = [call for call in row.get("canonical_tool_calls", []) if call.get("tool_name") == "inspect_quality_window"]
                if len(quality_calls) != 1:
                    failed.append({"scenario_id": row["scenario_id"], "issue": "missing_or_duplicate_inspect_quality_window"})
                    continue
                prompt_field = "hidden_user_instruction" if require_hidden_week else "query"
                prompt_text = str(row.get(prompt_field, "")).lower()
                week_prompt = "week beginning" in prompt_text or "week of" in prompt_text
                if not week_prompt:
                    failed.append({"scenario_id": row["scenario_id"], "issue": f"{prompt_field}_missing_week"})
                    continue
                executed = runtime.execute_call_sequence(row["canonical_tool_calls"])
                verification = verify_prediction(
                    row,
                    executed,
                    row["gold_final_answer"],
                    row.get("evidence"),
                    runtime,
                )
                checked += 1
                if verification.label != "accomplished" or verification.strict_label != "accomplished":
                    failed.append(
                        {
                            "scenario_id": row["scenario_id"],
                            "label": verification.label,
                            "strict_label": verification.strict_label,
                            "issues": verification.issues,
                        }
                    )
        return {"checked_quality_gate_rows": checked, "failed": failed, "passed": checked - len(failed)}
    finally:
        runtime.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tool-store-db", type=Path, default=REPO_ROOT / "data" / "bts" / "tool_store" / "tool_store.duckdb")
    parser.add_argument("--old-static-dir", type=Path, default=REPO_ROOT / "data" / "scenario_benchmark")
    parser.add_argument("--old-final-dir", type=Path, default=REPO_ROOT / "data" / "bts_e2e_agentic_v7_adv7")
    parser.add_argument("--probe-static-dir", type=Path, default=REPO_ROOT / "tmp" / "scenario_benchmark_qgpatch_probe")
    parser.add_argument("--out-static-dir", type=Path, default=REPO_ROOT / "data" / "scenario_benchmark_qgpatch")
    parser.add_argument("--out-e2e-dir", type=Path, default=REPO_ROOT / "data" / "bts_e2e_qgpatch")
    parser.add_argument("--out-agentic-dir", type=Path, default=REPO_ROOT / "data" / "bts_e2e_agentic_qgpatch")
    parser.add_argument("--out-final-dir", type=Path, default=REPO_ROOT / "data" / "bts_e2e_agentic_v7_adv7_qgpatch")
    args = parser.parse_args()

    heldout_site_ids = load_json(args.old_static_dir / "manifest.json").get("heldout_site_ids", [])
    probe_manifest = generate_scenario_benchmark(
        args.tool_store_db,
        args.probe_static_dir,
        heldout_site_ids=heldout_site_ids or None,
    )
    static_patch_report = build_patched_static(
        old_static_dir=args.old_static_dir,
        probe_static_dir=args.probe_static_dir,
        out_dir=args.out_static_dir,
    )
    build_patched_e2e(args.out_static_dir, args.out_e2e_dir)
    build_patched_agentic(args.out_static_dir, args.out_agentic_dir)
    build_patched_final(
        old_final_dir=args.old_final_dir,
        patched_agentic_dir=args.out_agentic_dir,
        out_dir=args.out_final_dir,
        tool_store_db=args.tool_store_db,
        static_patch_report=static_patch_report,
    )
    validation = {
        "probe_manifest": probe_manifest,
        "patched_agentic_final_validation": validate_quality_gate_rows(
            args.out_final_dir,
            args.tool_store_db,
            require_hidden_week=True,
        ),
        "patched_static_validation": validate_quality_gate_rows(
            args.out_static_dir,
            args.tool_store_db,
            require_hidden_week=False,
        ),
    }
    write_json(args.out_final_dir / "quality_gate_patch_validation.json", validation)
    print(json.dumps(
        {
            "out_static_dir": str(args.out_static_dir),
            "out_e2e_dir": str(args.out_e2e_dir),
            "out_agentic_dir": str(args.out_agentic_dir),
            "out_final_dir": str(args.out_final_dir),
            "validation": validation,
        },
        indent=2,
        ensure_ascii=False,
    ))


if __name__ == "__main__":
    main()
