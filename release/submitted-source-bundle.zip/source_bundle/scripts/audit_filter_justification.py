#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import duckdb


AGGREGATION_COMPATIBILITY_REGEX = r"(_Sensor|_Setpoint|_Limit)$"
AGGREGATION_BLACKLIST_REGEX = r"(^Time_|^Duration_Sensor$|_Energy_Sensor$|^Chilled_Water_Supply_Flow_Sensor$|_Parameter$)"
TIMESTAMP_COMPATIBILITY_REGEX = r"(_Sensor|_Setpoint|_Limit)$"
TIMESTAMP_BLACKLIST_REGEX = r"(_Parameter$)"
QUALITY_COMPATIBILITY_REGEX = r"(_Sensor|_Setpoint|_Limit)$"
QUALITY_BLACKLIST_REGEX = r"(^Time_|^Duration_Sensor$|_Energy_Sensor$|_Parameter$|^Min_Limit$|^Max_Limit$)"
VALID_POINT_CLASS_REGEX = r"^[A-Z][A-Za-z0-9_]*$"


def one(con: duckdb.DuckDBPyConnection, query: str):
    return con.execute(query).fetchone()[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tool-store-db", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    args = parser.parse_args()

    con = duckdb.connect(str(args.tool_store_db), read_only=True)

    compat = AGGREGATION_COMPATIBILITY_REGEX
    timestamp_compat = TIMESTAMP_COMPATIBILITY_REGEX
    quality_compat = QUALITY_COMPATIBILITY_REGEX
    valid = VALID_POINT_CLASS_REGEX

    report = {
        "global_funnel": {
            "metadata_streams": one(con, "select count(*) from point_inventory"),
            "tool_ready_points": one(con, "select count(*) from tool_ready_points"),
            "metadata_only_streams": one(
                con,
                """
                select count(*)
                from point_inventory p
                where not exists (
                    select 1
                    from tool_ready_points t
                    where t.site_id = p.site_id and t.stream_id = p.stream_id
                )
                """,
            ),
            "generic_point_class": one(con, "select count(*) from tool_ready_points where point_class = 'Point'"),
            "missing_equipment_label": one(con, "select count(*) from tool_ready_points where equipment_label is null"),
            "missing_location_type": one(con, "select count(*) from tool_ready_points where location_type is null"),
        },
        "derived_cutoffs": {
            "daily_window_coverage_q10": one(
                con,
                """
                with daily_window_quality as (
                    select least(
                        1.0,
                        d.count / greatest(
                            1.0,
                            floor((epoch(d.window_end) - epoch(d.window_start)) / q.median_step_seconds) + 1.0
                        )
                    ) as window_coverage
                    from daily_aggregates d
                    join quality_metrics q using (site_id, stream_id)
                    where q.median_step_seconds is not null and q.median_step_seconds > 0
                )
                select quantile_cont(window_coverage, 0.10) from daily_window_quality
                """,
            ),
            "weekly_window_coverage_q10": one(
                con,
                """
                with weekly_window_quality as (
                    select least(
                        1.0,
                        w.count / greatest(
                            1.0,
                            floor((epoch(w.window_end) - epoch(w.window_start)) / q.median_step_seconds) + 1.0
                        )
                    ) as window_coverage
                    from weekly_aggregates w
                    join quality_metrics q using (site_id, stream_id)
                    where q.median_step_seconds is not null and q.median_step_seconds > 0
                )
                select quantile_cont(window_coverage, 0.10) from weekly_window_quality
                """,
            ),
            "monthly_window_coverage_q10": one(
                con,
                """
                with monthly_window_quality as (
                    select least(
                        1.0,
                        m.count / greatest(
                            1.0,
                            floor((epoch(m.window_end) - epoch(m.window_start)) / q.median_step_seconds) + 1.0
                        )
                    ) as window_coverage
                    from monthly_aggregates m
                    join quality_metrics q using (site_id, stream_id)
                    where q.median_step_seconds is not null and q.median_step_seconds > 0
                )
                select quantile_cont(window_coverage, 0.10) from monthly_window_quality
                """,
            ),
            "quality_observed_fraction_q10": one(con, "select quantile_cont(observed_fraction, 0.10) from quality_metrics"),
            "quality_observed_fraction_q75": one(con, "select quantile_cont(observed_fraction, 0.75) from quality_metrics"),
            "quality_gap_ratio_q50": one(
                con,
                """
                select quantile_cont(longest_gap_seconds / nullif(median_step_seconds, 0), 0.50)
                from quality_metrics
                where median_step_seconds is not null and median_step_seconds > 0
                """,
            ),
            "quality_gap_ratio_q95": one(
                con,
                """
                select quantile_cont(longest_gap_seconds / nullif(median_step_seconds, 0), 0.95)
                from quality_metrics
                where median_step_seconds is not null and median_step_seconds > 0
                """,
            ),
        },
        "distribution_stats": {
            "daily_window_coverage": con.execute(
                """
                with daily_window_quality as (
                    select least(
                        1.0,
                        d.count / greatest(
                            1.0,
                            floor((epoch(d.window_end) - epoch(d.window_start)) / q.median_step_seconds) + 1.0
                        )
                    ) as window_coverage
                    from daily_aggregates d
                    join quality_metrics q using (site_id, stream_id)
                    where q.median_step_seconds is not null and q.median_step_seconds > 0
                ),
                c as (
                    select
                        quantile_cont(window_coverage, 0.01) as q01,
                        quantile_cont(window_coverage, 0.05) as q05,
                        quantile_cont(window_coverage, 0.10) as q10,
                        quantile_cont(window_coverage, 0.50) as q50
                    from daily_window_quality
                )
                select
                    q01,
                    q05,
                    q10,
                    q50,
                    avg(case when window_coverage >= q10 then 1.0 else 0.0 end) as share_ge_q10
                from daily_window_quality, c
                group by q01, q05, q10, q50
                """
            ).fetchone(),
            "weekly_window_coverage": con.execute(
                """
                with weekly_window_quality as (
                    select least(
                        1.0,
                        w.count / greatest(
                            1.0,
                            floor((epoch(w.window_end) - epoch(w.window_start)) / q.median_step_seconds) + 1.0
                        )
                    ) as window_coverage
                    from weekly_aggregates w
                    join quality_metrics q using (site_id, stream_id)
                    where q.median_step_seconds is not null and q.median_step_seconds > 0
                ),
                c as (
                    select
                        quantile_cont(window_coverage, 0.01) as q01,
                        quantile_cont(window_coverage, 0.05) as q05,
                        quantile_cont(window_coverage, 0.10) as q10,
                        quantile_cont(window_coverage, 0.50) as q50
                    from weekly_window_quality
                )
                select
                    q01,
                    q05,
                    q10,
                    q50,
                    avg(case when window_coverage >= q10 then 1.0 else 0.0 end) as share_ge_q10
                from weekly_window_quality, c
                group by q01, q05, q10, q50
                """
            ).fetchone(),
            "monthly_window_coverage": con.execute(
                """
                with monthly_window_quality as (
                    select least(
                        1.0,
                        m.count / greatest(
                            1.0,
                            floor((epoch(m.window_end) - epoch(m.window_start)) / q.median_step_seconds) + 1.0
                        )
                    ) as window_coverage
                    from monthly_aggregates m
                    join quality_metrics q using (site_id, stream_id)
                    where q.median_step_seconds is not null and q.median_step_seconds > 0
                ),
                c as (
                    select
                        quantile_cont(window_coverage, 0.01) as q01,
                        quantile_cont(window_coverage, 0.05) as q05,
                        quantile_cont(window_coverage, 0.10) as q10,
                        quantile_cont(window_coverage, 0.50) as q50
                    from monthly_window_quality
                )
                select
                    q01,
                    q05,
                    q10,
                    q50,
                    avg(case when window_coverage >= q10 then 1.0 else 0.0 end) as share_ge_q10
                from monthly_window_quality, c
                group by q01, q05, q10, q50
                """
            ).fetchone(),
            "site_class_cap_groups": con.execute(
                """
                with weekly_caps as (
                    select site_id, point_class, count(*) as n
                    from tool_ready_points t
                    join weekly_aggregates w using (site_id, stream_id)
                    where
                        t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, ?)
                        and regexp_matches(t.point_class, ?)
                    group by 1, 2
                )
                select
                    count(*) as total_groups,
                    avg(case when n >= 100 then 1.0 else 0.0 end) as share_ge_100
                from weekly_caps
                """,
                [valid, compat],
            ).fetchone(),
        },
        "family_candidate_funnel": {
            "point_disambiguation": {
                "grounded_non_generic": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points
                    where
                        point_class is not null
                        and point_class <> 'Point'
                        and regexp_matches(point_class, '{valid}')
                        and equipment_label is not null
                    """,
                ),
                "resolvable": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points
                    where
                        point_class is not null
                        and point_class <> 'Point'
                        and regexp_matches(point_class, '{valid}')
                        and equipment_label is not null
                        and candidate_ambiguity = 1
                    """,
                ),
                "class_group_rows": one(
                    con,
                    f"""
                    with class_counts as (
                        select site_id, point_class, count(*) as class_size
                        from tool_ready_points
                        where
                            point_class is not null
                            and point_class <> 'Point'
                            and regexp_matches(point_class, '{valid}')
                            and equipment_label is not null
                            and candidate_ambiguity = 1
                        group by 1, 2
                        having count(*) >= 2
                    )
                    select count(*)
                    from tool_ready_points t
                    join class_counts c using (site_id, point_class)
                    where t.candidate_ambiguity = 1
                    """,
                ),
            },
            "day_mean_lookup": {
                "grounded_compatible": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points
                    where
                        candidate_ambiguity = 1
                        and point_class is not null
                        and point_class <> 'Point'
                        and regexp_matches(point_class, '{valid}')
                        and regexp_matches(point_class, '{compat}')
                        and equipment_label is not null
                    """,
                ),
                "support_filtered": one(
                    con,
                    f"""
                    with daily_window_quality as (
                        select
                            d.site_id,
                            d.stream_id,
                            d.window_start,
                            d.window_end,
                            least(
                                1.0,
                                d.count / greatest(
                                    1.0,
                                    floor((epoch(d.window_end) - epoch(d.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from daily_aggregates d
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from daily_window_quality
                    )
                    select count(*)
                    from tool_ready_points t
                    join daily_window_quality q using (site_id, stream_id)
                    join support_cutoff s on true
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{quality_compat}')
                        and t.equipment_label is not null
                        and q.window_coverage >= s.min_window_coverage
                    """,
                ),
                "site_class_cap_filtered": one(
                    con,
                    f"""
                    with daily_window_quality as (
                        select
                            d.site_id,
                            d.stream_id,
                            d.window_start,
                            d.window_end,
                            d.mean_value,
                            least(
                                1.0,
                                d.count / greatest(
                                    1.0,
                                    floor((epoch(d.window_end) - epoch(d.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from daily_aggregates d
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from daily_window_quality
                    ),
                    class_caps as (
                        select
                            t.site_id,
                            t.point_class,
                            quantile_cont(abs(q.mean_value), 0.995) as max_abs_mean
                        from tool_ready_points t
                        join daily_window_quality q using (site_id, stream_id)
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and q.mean_value is not null
                        group by 1, 2
                        having count(*) >= 100
                    )
                    select count(*)
                    from tool_ready_points t
                    join daily_window_quality q using (site_id, stream_id)
                    join support_cutoff s on true
                    join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{quality_compat}')
                        and t.equipment_label is not null
                        and q.window_coverage >= s.min_window_coverage
                        and abs(q.mean_value) <= c.max_abs_mean
                    """,
                ),
            },
            "relative_24h_mean_lookup": {
                "grounded_compatible": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points
                    where
                        candidate_ambiguity = 1
                        and point_class is not null
                        and point_class <> 'Point'
                        and regexp_matches(point_class, '{valid}')
                        and regexp_matches(point_class, '{compat}')
                        and equipment_label is not null
                    """,
                ),
                "support_filtered": one(
                    con,
                    f"""
                    with daily_window_quality as (
                        select
                            d.site_id,
                            d.stream_id,
                            d.window_start,
                            d.window_end,
                            least(
                                1.0,
                                d.count / greatest(
                                    1.0,
                                    floor((epoch(d.window_end) - epoch(d.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from daily_aggregates d
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from daily_window_quality
                    )
                    select count(*)
                    from tool_ready_points t
                    join daily_window_quality q using (site_id, stream_id)
                    join support_cutoff s on true
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{quality_compat}')
                        and t.equipment_label is not null
                        and q.window_coverage >= s.min_window_coverage
                    """,
                ),
                "site_class_cap_filtered": one(
                    con,
                    f"""
                    with daily_window_quality as (
                        select
                            d.site_id,
                            d.stream_id,
                            d.window_start,
                            d.window_end,
                            d.mean_value,
                            least(
                                1.0,
                                d.count / greatest(
                                    1.0,
                                    floor((epoch(d.window_end) - epoch(d.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from daily_aggregates d
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from daily_window_quality
                    ),
                    class_caps as (
                        select
                            t.site_id,
                            t.point_class,
                            quantile_cont(abs(q.mean_value), 0.995) as max_abs_mean
                        from tool_ready_points t
                        join daily_window_quality q using (site_id, stream_id)
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and q.mean_value is not null
                        group by 1, 2
                        having count(*) >= 100
                    )
                    select count(*)
                    from tool_ready_points t
                    join daily_window_quality q using (site_id, stream_id)
                    join support_cutoff s on true
                    join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{compat}')
                        and t.equipment_label is not null
                        and q.window_coverage >= s.min_window_coverage
                        and abs(q.mean_value) <= c.max_abs_mean
                    """,
                ),
            },
            "window_mean_lookup": {
                "grounded_compatible": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points
                    where
                        candidate_ambiguity = 1
                        and point_class is not null
                        and point_class <> 'Point'
                        and regexp_matches(point_class, '{valid}')
                        and regexp_matches(point_class, '{compat}')
                        and equipment_label is not null
                    """,
                ),
                "support_filtered": one(
                    con,
                    f"""
                    with weekly_window_quality as (
                        select
                            w.site_id,
                            w.stream_id,
                            w.window_start,
                            w.window_end,
                            least(
                                1.0,
                                w.count / greatest(
                                    1.0,
                                    floor((epoch(w.window_end) - epoch(w.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from weekly_aggregates w
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from weekly_window_quality
                    )
                    select count(*)
                    from tool_ready_points t
                    join weekly_window_quality q using (site_id, stream_id)
                    join support_cutoff s on true
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{compat}')
                        and t.equipment_label is not null
                        and q.window_coverage >= s.min_window_coverage
                    """,
                ),
                "site_class_cap_filtered": one(
                    con,
                    f"""
                    with weekly_window_quality as (
                        select
                            w.site_id,
                            w.stream_id,
                            w.window_start,
                            w.window_end,
                            w.mean_value,
                            least(
                                1.0,
                                w.count / greatest(
                                    1.0,
                                    floor((epoch(w.window_end) - epoch(w.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from weekly_aggregates w
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from weekly_window_quality
                    ),
                    class_caps as (
                        select
                            t.site_id,
                            t.point_class,
                            quantile_cont(abs(q.mean_value), 0.995) as max_abs_mean
                        from tool_ready_points t
                        join weekly_window_quality q using (site_id, stream_id)
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and q.mean_value is not null
                        group by 1, 2
                        having count(*) >= 100
                    )
                    select count(*)
                    from tool_ready_points t
                    join weekly_window_quality q using (site_id, stream_id)
                    join support_cutoff s on true
                    join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{compat}')
                        and t.equipment_label is not null
                        and q.window_coverage >= s.min_window_coverage
                        and abs(q.mean_value) <= c.max_abs_mean
                    """,
                ),
            },
            "window_pairwise_compare": {
                "candidate_pairs": one(
                    con,
                    f"""
                    with weekly_window_quality as (
                        select
                            w.site_id,
                            w.stream_id,
                            w.window_start,
                            w.window_end,
                            w.mean_value,
                            least(
                                1.0,
                                w.count / greatest(
                                    1.0,
                                    floor((epoch(w.window_end) - epoch(w.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from weekly_aggregates w
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from weekly_window_quality
                    ),
                    class_caps as (
                        select
                            t.site_id,
                            t.point_class,
                            quantile_cont(abs(q.mean_value), 0.995) as max_abs_mean
                        from tool_ready_points t
                        join weekly_window_quality q using (site_id, stream_id)
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and q.mean_value is not null
                        group by 1, 2
                        having count(*) >= 100
                    ),
                    candidates as (
                        select
                            t.site_id,
                            t.point_class,
                            t.stream_id,
                            t.equipment_label,
                            q.window_start,
                            q.mean_value
                        from tool_ready_points t
                        join weekly_window_quality q using (site_id, stream_id)
                        join support_cutoff s on true
                        join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
                        where
                            t.candidate_ambiguity = 1
                            and t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and t.equipment_label is not null
                            and q.window_coverage >= s.min_window_coverage
                            and abs(q.mean_value) <= c.max_abs_mean
                    )
                    select count(*)
                    from candidates a
                    join candidates b
                      on a.site_id = b.site_id
                     and a.point_class = b.point_class
                     and a.window_start = b.window_start
                     and a.stream_id < b.stream_id
                     and a.equipment_label <> b.equipment_label
                    """,
                ),
                "separable_pairs": one(
                    con,
                    f"""
                    with weekly_window_quality as (
                        select
                            w.site_id,
                            w.stream_id,
                            w.window_start,
                            w.mean_value,
                            least(
                                1.0,
                                w.count / greatest(
                                    1.0,
                                    floor((epoch(w.window_end) - epoch(w.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from weekly_aggregates w
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from weekly_window_quality
                    ),
                    class_caps as (
                        select
                            t.site_id,
                            t.point_class,
                            quantile_cont(abs(q.mean_value), 0.995) as max_abs_mean
                        from tool_ready_points t
                        join weekly_window_quality q using (site_id, stream_id)
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and q.mean_value is not null
                        group by 1, 2
                        having count(*) >= 100
                    ),
                    candidates as (
                        select
                            t.site_id,
                            t.point_class,
                            t.stream_id,
                            t.equipment_label,
                            q.window_start,
                            q.mean_value
                        from tool_ready_points t
                        join weekly_window_quality q using (site_id, stream_id)
                        join support_cutoff s on true
                        join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
                        where
                            t.candidate_ambiguity = 1
                            and t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and t.equipment_label is not null
                            and q.window_coverage >= s.min_window_coverage
                            and abs(q.mean_value) <= c.max_abs_mean
                    ),
                    pairs as (
                        select
                            a.site_id,
                            a.point_class,
                            abs(a.mean_value - b.mean_value) as diff_value
                        from candidates a
                        join candidates b
                          on a.site_id = b.site_id
                         and a.point_class = b.point_class
                         and a.window_start = b.window_start
                         and a.stream_id < b.stream_id
                         and a.equipment_label <> b.equipment_label
                    ),
                    pair_cutoffs as (
                        select site_id, point_class, quantile_cont(diff_value, 0.50) as min_gap
                        from pairs
                        group by 1, 2
                    )
                    select count(*)
                    from pairs p
                    join pair_cutoffs c using (site_id, point_class)
                    where p.diff_value > 0 and p.diff_value >= c.min_gap
                    """,
                ),
            },
            "window_rank": {
                "grouped_contexts": one(
                    con,
                    f"""
                    with monthly_window_quality as (
                        select
                            m.site_id,
                            m.stream_id,
                            m.window_start,
                            m.window_end,
                            m.mean_value,
                            least(
                                1.0,
                                m.count / greatest(
                                    1.0,
                                    floor((epoch(m.window_end) - epoch(m.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from monthly_aggregates m
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from monthly_window_quality
                    ),
                    class_caps as (
                        select
                            t.site_id,
                            t.point_class,
                            quantile_cont(abs(q.mean_value), 0.995) as max_abs_mean
                        from tool_ready_points t
                        join monthly_window_quality q using (site_id, stream_id)
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and q.mean_value is not null
                        group by 1, 2
                        having count(*) >= 100
                    ),
                    candidates as (
                        select
                            t.site_id,
                            t.point_class,
                            t.location_type,
                            t.stream_id,
                            q.window_start,
                            q.window_end,
                            q.mean_value
                        from tool_ready_points t
                        join monthly_window_quality q using (site_id, stream_id)
                        join support_cutoff s on true
                        join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and t.location_type is not null
                            and q.window_coverage >= s.min_window_coverage
                            and abs(q.mean_value) <= c.max_abs_mean
                    )
                    select count(*)
                    from (
                        select site_id, location_type, point_class, window_start, window_end
                        from candidates
                        group by 1, 2, 3, 4, 5
                        having count(distinct stream_id) >= 3
                    )
                    """,
                ),
                "separable_contexts": one(
                    con,
                    f"""
                    with monthly_window_quality as (
                        select
                            m.site_id,
                            m.stream_id,
                            m.window_start,
                            m.window_end,
                            m.mean_value,
                            least(
                                1.0,
                                m.count / greatest(
                                    1.0,
                                    floor((epoch(m.window_end) - epoch(m.window_start)) / q.median_step_seconds) + 1.0
                                )
                            ) as window_coverage
                        from monthly_aggregates m
                        join quality_metrics q using (site_id, stream_id)
                        where q.median_step_seconds is not null and q.median_step_seconds > 0
                    ),
                    support_cutoff as (
                        select quantile_cont(window_coverage, 0.10) as min_window_coverage
                        from monthly_window_quality
                    ),
                    class_caps as (
                        select
                            t.site_id,
                            t.point_class,
                            quantile_cont(abs(q.mean_value), 0.995) as max_abs_mean
                        from tool_ready_points t
                        join monthly_window_quality q using (site_id, stream_id)
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and q.mean_value is not null
                        group by 1, 2
                        having count(*) >= 100
                    ),
                    candidates as (
                        select
                            t.site_id,
                            t.point_class,
                            t.location_type,
                            t.stream_id,
                            q.window_start,
                            q.window_end,
                            q.mean_value
                        from tool_ready_points t
                        join monthly_window_quality q using (site_id, stream_id)
                        join support_cutoff s on true
                        join class_caps c on t.site_id = c.site_id and t.point_class = c.point_class
                        where
                            t.point_class is not null
                            and t.point_class <> 'Point'
                            and regexp_matches(t.point_class, '{valid}')
                            and regexp_matches(t.point_class, '{compat}')
                            and t.location_type is not null
                            and q.window_coverage >= s.min_window_coverage
                            and abs(q.mean_value) <= c.max_abs_mean
                    ),
                    grouped as (
                        select
                            site_id,
                            location_type,
                            point_class,
                            window_start,
                            window_end,
                            count(distinct stream_id) as n_streams
                        from candidates
                        group by 1, 2, 3, 4, 5
                        having count(distinct stream_id) >= 3
                    ),
                    ranked as (
                        select
                            c.*,
                            g.n_streams,
                            row_number() over (
                                partition by c.site_id, c.location_type, c.point_class, c.window_start
                                order by c.mean_value desc, c.stream_id
                            ) as pos
                        from candidates c
                        join grouped g using (site_id, location_type, point_class, window_start, window_end)
                    ),
                    final as (
                        select
                            a.site_id,
                            a.location_type,
                            a.point_class,
                            abs(a.mean_value - b.mean_value) as margin_value
                        from ranked a
                        join ranked b
                          on a.site_id = b.site_id
                         and a.location_type = b.location_type
                         and a.point_class = b.point_class
                         and a.window_start = b.window_start
                         and a.pos = 1
                         and b.pos = 2
                    ),
                    margin_cutoffs as (
                        select
                            site_id,
                            location_type,
                            point_class,
                            quantile_cont(margin_value, 0.50) as min_margin
                        from final
                        group by 1, 2, 3
                    )
                    select count(*)
                    from final f
                    join margin_cutoffs c using (site_id, location_type, point_class)
                    where f.margin_value > 0 and f.margin_value >= c.min_margin
                    """,
                ),
            },
            "quality_gate": {
                "grounded_compatible": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points t
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{compat}')
                        and t.equipment_label is not null
                    """,
                ),
                "flagged_candidates": one(
                    con,
                    f"""
                    with quality_cutoffs as (
                        select
                            quantile_cont(observed_fraction, 0.10) as low_observed_fraction,
                            quantile_cont(longest_gap_seconds / nullif(median_step_seconds, 0), 0.95) as high_gap_ratio
                        from quality_metrics
                        where median_step_seconds is not null and median_step_seconds > 0
                    )
                    select count(*)
                    from quality_metrics q
                    join tool_ready_points t using (site_id, stream_id)
                    join quality_cutoffs c on true
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{compat}')
                        and t.equipment_label is not null
                        and q.median_step_seconds is not null
                        and q.median_step_seconds > 0
                        and (
                            q.observed_fraction < c.low_observed_fraction
                            or q.longest_gap_seconds / nullif(q.median_step_seconds, 0) > c.high_gap_ratio
                        )
                    """,
                ),
                "healthy_candidates": one(
                    con,
                    f"""
                    with quality_cutoffs as (
                        select
                            quantile_cont(observed_fraction, 0.75) as high_observed_fraction,
                            quantile_cont(longest_gap_seconds / nullif(median_step_seconds, 0), 0.50) as low_gap_ratio
                        from quality_metrics
                        where median_step_seconds is not null and median_step_seconds > 0
                    )
                    select count(*)
                    from quality_metrics q
                    join tool_ready_points t using (site_id, stream_id)
                    join quality_cutoffs c on true
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{compat}')
                        and t.equipment_label is not null
                        and q.median_step_seconds is not null
                        and q.median_step_seconds > 0
                        and q.observed_fraction >= c.high_observed_fraction
                        and q.longest_gap_seconds / nullif(q.median_step_seconds, 0) <= c.low_gap_ratio
                        and coalesce(q.duplicate_timestamp_fraction, 0.0) = 0.0
                        and coalesce(q.nan_fraction, 0.0) = 0.0
                    """,
                ),
            },
            "timestamp_value_lookup": {
                "exact_eligible_streams": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points t
                    join quality_metrics q using (site_id, stream_id)
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{timestamp_compat}')
                        and t.equipment_label is not null
                        and t.raw_zip_path is not null
                        and t.raw_member_name is not null
                        and coalesce(q.duplicate_timestamp_fraction, 0.0) = 0.0
                    """,
                ),
            },
            "timestamp_nearest_lookup": {
                "nearest_eligible_streams": one(
                    con,
                    f"""
                    select count(*)
                    from tool_ready_points t
                    join quality_metrics q using (site_id, stream_id)
                    where
                        t.candidate_ambiguity = 1
                        and t.point_class is not null
                        and t.point_class <> 'Point'
                        and regexp_matches(t.point_class, '{valid}')
                        and regexp_matches(t.point_class, '{timestamp_compat}')
                        and t.equipment_label is not null
                        and t.raw_zip_path is not null
                        and t.raw_member_name is not null
                        and q.median_step_seconds is not null
                        and q.median_step_seconds > 0
                        and coalesce(q.duplicate_timestamp_fraction, 0.0) = 0.0
                    """,
                ),
            },
        },
    }

    def row_tuple_to_dict(row, keys):
        return {key: value for key, value in zip(keys, row)}

    report["distribution_stats"]["daily_window_coverage"] = row_tuple_to_dict(
        report["distribution_stats"]["daily_window_coverage"],
        ["q01", "q05", "q10", "q50", "share_ge_q10"],
    )
    report["distribution_stats"]["weekly_window_coverage"] = row_tuple_to_dict(
        report["distribution_stats"]["weekly_window_coverage"],
        ["q01", "q05", "q10", "q50", "share_ge_q10"],
    )
    report["distribution_stats"]["monthly_window_coverage"] = row_tuple_to_dict(
        report["distribution_stats"]["monthly_window_coverage"],
        ["q01", "q05", "q10", "q50", "share_ge_q10"],
    )
    report["distribution_stats"]["site_class_cap_groups"] = row_tuple_to_dict(
        report["distribution_stats"]["site_class_cap_groups"],
        ["total_groups", "share_ge_100"],
    )

    args.out_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
